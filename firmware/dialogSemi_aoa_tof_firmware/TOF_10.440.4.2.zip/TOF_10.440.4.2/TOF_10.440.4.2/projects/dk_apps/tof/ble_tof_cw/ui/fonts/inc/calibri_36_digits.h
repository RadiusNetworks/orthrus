/**
 * \addtogroup UI
 * \{
 * \addtogroup FONTS
 *
 * \brief Basic font data types
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file calibri_36_digits.h
 *
 * @brief Calibri 36px digits only Font definition
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef CALIBRI_36_DIGITS_H_
#define CALIBRI_36_DIGITS_H_

#include "fonts.h"

/**
 ****************************************************************************************
 * \name                          Font data for Calibri 36pt
 ****************************************************************************************
 * \{ */
/**
 * \brief Character bitmaps for Calibri 36pt
 */
extern const uint8_t calibri_36ptBitmaps[];

/**
 * \brief Font information for Calibri 36pt
 */
extern const font_info_t calibri_36ptFontInfo;

/**
 * \brief Character descriptors for Calibri 36pt
 */
extern const font_char_info_t calibri_36ptDescriptors[];
/** \} */

#endif /* CALIBRI_36_DIGITS_H_ */

/**
 * \}
 * \}
 */
