/**
 ****************************************************************************************
 *
 * @file tof_hw.h
 *
 * @brief ToF code related to hardware
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef TOF_HW_H_
#define TOF_HW_H_

void init_cw_dma(uint16_t length);
void start_cw_dma(void* dst, void * src);
void wait_cw_dma(void);

bool tof_hw_k1_button_pressed(void);
void tof_hw_rpi_set_antenna_switch(uint8_t ant);

void tof_lcd_init();
void tof_lcd_draw_string(const char *str);

void tof_dma_init(uint16_t length);

#endif /* TOF_HW_H_*/
