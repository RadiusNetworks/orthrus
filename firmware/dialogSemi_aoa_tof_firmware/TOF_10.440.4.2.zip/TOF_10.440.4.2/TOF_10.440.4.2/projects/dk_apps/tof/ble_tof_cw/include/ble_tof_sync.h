/**
 ****************************************************************************************
 *
 * @file ble_tof_sync.h
 *
 * @brief BLE ToF code for CW synchronization
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef BLE_TOF_SYNC_H_
#define BLE_TOF_SYNC_H_

/* Notification bits reservation
 * bit #5 is always assigned to ToF synchronization end notification
 */
#define TOF_SYNC_END_NOTIF       (1 << 5)

/* Synchronization settings for 32MHz*/
#define SYNC_TO_IN_MS                   (10)                    /* systick synchronization timeout after rf diagnostics sync */
#define SYNC_TO_DELAY_IN_TICKS          (32 * 20)              /* extra delay 150 us for irq latency */
#define SYNC_TX_RX_OFFSET_IN_US         (121)

/* if defined use sync timer free running mode for atoms sequence */
#define SYNC_TIMER_FREE_RUNNING

void radio_measurement(tof_role_t role);
void ble_tof_sync_init(tof_role_t role,  OS_TASK handle);
void ble_tof_sync_start(void);
void ble_tof_sync_stop(void);
bool ble_tof_sync_active(void);

void ble_tof_cw_start(void);
void ble_tof_cw_stop(void);
bool ble_tof_cw_active(void);

void delay_us(int us);

#endif /* BLE_TOF_SYNC_H_*/
