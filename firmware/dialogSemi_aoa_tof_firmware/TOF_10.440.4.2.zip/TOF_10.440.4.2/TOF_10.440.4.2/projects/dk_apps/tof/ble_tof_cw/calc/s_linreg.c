/**
 ****************************************************************************************
 *
 * @file s_linreg.c
 *
* @brief Simple linear fit implementation that fits y = mx + b to a given set
 *        of (x,y) data. Based on 5 different sums.
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <stdint.h>

int s_linreg(int n, float *x, float *y, float *m, float *b, int nele)
{
    /* y = mx + b */
    float sx = 0;       /* sum of x */
    float sy = 0;       /* sum of y */
    float sxx = 0;      /* sum of x*x */
    float sxy = 0;      /* sum of x*y */
    // float syy = 0;      /* sum of y*y */
    float denom;
    int i;

    for (i = 0; i < n; i++)
    {
        sx += x[i];
        sy += y[i * nele];
        sxx += x[i] * x[i];
        sxy += x[i] * y[i * nele];
        // syy += y[i * nele] * y[i * nele];
    }

    denom = n * sxx - sx * sx;
    if (denom == 0)
    {
        *m = 0;
        *b = 0;
        return 1;
    }

    *m = (n * sxy - sx * sy)/(denom);
    *b = (sy - *m * sx)/n;
    return 0;
}

