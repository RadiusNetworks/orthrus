/**
 * \addtogroup UI
 * \{
 * \addtogroup FONTS
 *
 * \brief Basic font data types
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file calibri_18_bold.h
 *
 * @brief Calibri 18px Bold Font definition
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef CALIBRI_18_BOLD_H_
#define CALIBRI_18_BOLD_H_

#include "fonts.h"

/**
 ****************************************************************************************
 * \name                          Font data for Calibri 18pt
 ****************************************************************************************
 * \{ */
/**
 * \brief Character bitmaps for Calibri 18pt
 */
extern const uint8_t calibri_18ptBitmaps[];

/**
 * \brief Font information for Calibri 18pt
 */
extern const font_info_t calibri_18ptFontInfo;

/**
 * \brief Character descriptors for Calibri 18pt
 */
extern const font_char_info_t calibri_18ptDescriptors[];
/** \} */

#endif /* CALIBRI_18_BOLD_H_ */

/**
 * \}
 * \}
 */
