/**
 ****************************************************************************************
 *
 * @file acquisition.h
 *
 * @brief ToF code for acquisition
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef ACQUISITION_H
#define ACQUISITION_H

#include <stdint.h>
#include <stdbool.h>

#define AGC_FREEZE_AUTO         (1)         /* use automatic AGC freeze */
#define AGC_FREEZE_LEVEL        (7)         /* manual AGC freeze level, from 0 ... 9 */

#define N_ATOM_MAX              (40)        /* max number of atoms */

/* parts of relevant data inside atom */
#define MEAS_START_INIT_US      (80)        /* start of meaningful data inside rfmon_sample_buffer */
#define MEAS_START_REFL_US      (190)
#define MEAS_LENGTH_US_NORMAL   (6*8)       /* length of meaningful data inside rfmon_sample_buffer */
#define MEAS_LENGTH_US_DIVERSITY  (9*8)     /* length of meaningful data inside rfmon_sample_buffer with diversity */

/* default frequency stepping */
#define MEAS_FREQ_START_MHZ     (2402)
#define MEAS_FREQ_STEP_MHZ      (2)
#define RFMON_CFG_LEN_SMPL      (US_TO_SAMPLES(MEAS_LENGTH_US_NORMAL * N_ATOM_MAX)) /* length of Matlab exchange buffer in samples */

#define ATOM_TIME_US            480
#define US_TO_SAMPLES(US_VAL)   (8 * US_VAL)                    /* 1msec equals 8000 samples */
#define US_TO_BYTES(US_VAL)     (US_TO_SAMPLES(US_VAL) * 4)     /* one sample consists of four bytes */
#define SAMPLES_PER_ATOM        (US_TO_SAMPLES(ATOM_TIME_US))

#define MAX_TOF_XTAL32M_TRIM    (0x2BF)

/* --- typedefs ------------------------------------------------------- */
typedef enum ping_pong_usage_type
{
  USE_PING,   /* responder device uses PING scheme */
  USE_PONG,   /* initiator device uses PONG scheme */
}
ping_pong_usage_t;

typedef struct phase_meas_config_params_type
{
  ping_pong_usage_t role;
  uint8_t agc_freeze_lvl;     /* value to use during the AGC freeze (0 ... 9) */
  uint16_t meas_start_us;     /* start of data section to copy from each atom in us */
  uint16_t meas_length_us;    /* length of data section to copy from each atom in us */
  uint16_t f_start_mhz;       /* first measurement frequency in MHz */
  uint8_t f_step_mhz;         /* difference between two measurement frequencies in MHz */
  uint16_t nb_atoms;          /* number of atoms to measure */
  uint32_t *dst_buffer;       /* pointer to destination buffer */
  uint16_t dst_buffer_size;   /* length of destination buffer in Bytes, at least 16000 */
  bool use_diversity;         /* increase PING and PONG length to support diversity */
  bool use_auto_xtal_trim;
  bool use_distance_average;
}
phase_meas_config_params_t;

extern uint32_t rfmon_sample_buffer[];

/**
 * Set all the measurement relevant parameters, do not yet configure the radio.
 *
 * \param [in]  measurement parameters, see typedef for more info
 */
void configure_acquisition(phase_meas_config_params_t parameters);

void prepare_acquisition(void);

uint8_t get_acquisition_agc_value(void);

/**
 * Run the acquisition for an atom and acquires the measurement data.
 * Both devices have to be synced before entering thisfunction.
 *
 * \return true if acquisition of last atom is completed.
 */
bool run_acquisition_atom_cb(void);

void set_xtal_trim(uint16_t xtal32m_trim_value);
uint16_t get_xtal_trim(void);
uint16_t tune_xtal_trim(float f_offset, float f_offset_thrs);
float calc_distance_average(float distance, uint8_t dqf);

bool rfmon_overflow();

void rf_system_init(void);
void rf_system_stop(void);

#endif /* ACQUISITION_H*/
