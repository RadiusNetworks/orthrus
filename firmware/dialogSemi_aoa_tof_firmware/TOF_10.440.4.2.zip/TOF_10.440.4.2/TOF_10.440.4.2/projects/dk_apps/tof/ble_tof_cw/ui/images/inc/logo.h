/**
 * \addtogroup UI
 * \{
 * \addtogroup IMAGES
 *
 * \brief Image definitions
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file logo.h
 *
 * @brief Logo image header file.
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */
#ifndef LOGO_H_
#define LOGO_H_

#include "stdint.h"

/**
 ****************************************************************************************
 * \name                          Image data for logo
 ****************************************************************************************
 * \{ */
/**
 * \brief Image width for logo
 */
#define logo_width          62

/**
 * \brief Image height for logo
 */
#define logo_height         78

#define logo_format         L1

/**
 * \brief Bitmap info for logo
 */
extern const uint8_t logo_bitmap[];
/** \} */

#endif /* LOGO_H_ */

/**
 * \}
 * \}
 */
