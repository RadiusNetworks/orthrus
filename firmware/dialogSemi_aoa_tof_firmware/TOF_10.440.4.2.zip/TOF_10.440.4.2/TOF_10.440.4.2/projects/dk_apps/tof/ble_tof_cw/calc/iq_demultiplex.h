/**
 ****************************************************************************************
 *
 * @file iq_demultiplex.h
 *
 * @brief Get IQ data from test bus data
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

/* Prevent double inclusion */
#ifndef IQ_MULTIPLEX_H
#define IQ_MULTIPLEX_H

typedef struct
{
    uint32_t * p_test_bus_data;
    size_t nb_elements;

}
iq_demux_parm_t;


void iq_demux_init(uint32_t * pTestBusData, size_t nb_elements);
void iq_demultiplex(void);

int16_t * iq_demux(uint32_t * pTestBusData, size_t nb_elements, int16_t *pIQData);

#endif /* IQ_MULTIPLEX_H */
