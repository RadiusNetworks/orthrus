/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup STATIC_LABEL
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file static_label.c
 *
 * @brief Static label widget implementation
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include "static_label.h"
#include "common.h"

void ui_draw_static_label(const ui_screen_item_t *item)
{
        ui_static_label_t *prop = (ui_static_label_t*) item->properties;
        uint8_t x;
        uint8_t y;
        uint8_t len;

        if (!UI_IS_FLAG_SET(item, UI_FLAG_VISIBLE)) {
                return;
        }

        switch (prop->align) {
        case UI_ALIGN_LEFT:
                x = item->x;
                break;

        case UI_ALIGN_CENTER:
                len = ui_measure_string(prop->font, prop->text, prop->scale);
                x = item->x + (item->width - len) / 2;
                break;

        case UI_ALIGN_RIGHT:
                len = ui_measure_string(prop->font, prop->text, prop->scale);
                x = item->x + item->width - len;
                break;

        default:
                return;
        }

        y = item->y + (item->height / 2) - (prop->font->height / 2) - 1;
        ui_draw_string(item->color, x, y, prop->font, prop->text, prop->scale);
}

/**
 * \}
 * \}
 * \}
 */
