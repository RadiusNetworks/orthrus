BLE Time of Flight Continuous Wave demo application {#ble_tof_cw}
===================================

## Overview

This application is a sample implementation that uses a CW measurement algorithm for distance calculation.
Detailed information about the application can be found at the ToF Demo user manual.

## Configuration

- The default role for the device can change from the configuration mode which is entered if button K1 is pressed during reset.
- Settings related to sychronization are defined in ble_tof_sync.h
- Definitions related to ble tof service are in ble_tof.h

## Synchronization

Based on the TX_EN signal for the master and the RX_SYNC_FOUND signal for the slave.
There is a constant TX_RX_OFFSET between the two about 121us. 
Each signal triggers the rf_diagnostics irq that sets the systick timer.
The sytick timer expires SYNC_TO_IN_MS after the  rx_sync_found irq for the salve and 
SYNC_TO_IN_MS + TX_RX_OFFSET us for the master.
Default value for SYNC_TO_IN_MS is 10ms.

##Limitations:

- Cortex-M33 must be acive before the synchronization IRQs are received
- RF_DIAG irq and Systick IRQ need the highest priority (0) to reduce IRQ latencies because of OS critical code.
- Raw DMA code is used  during the acquisition of IQ data instead of the SDK code.

## Installation procedure

The project is located in the \b `projects/dk_apps/tof/ble_tof_cw` folder.

To install the project follow the [General Installation and Debugging Procedure](@ref install_and_debug_procedure).
