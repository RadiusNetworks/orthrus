/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup TEXTBOX
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file textbox.c
 *
 * @brief Textbox widget implementation
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */
#include "string.h"
#include "textbox.h"
#include "common.h"
#include "stdarg.h"
#include "stdio.h"
#include "gdi.h"

void ui_draw_textbox(const ui_screen_item_t *item)
{
        ui_textbox_t *prop = (ui_textbox_t*) item->properties;
        char *text = (char *) item->status;
        uint8_t x;
        uint8_t y;
        uint8_t len;

        if (!UI_IS_FLAG_SET(item, UI_FLAG_VISIBLE)) {
                return;
        }

        if (prop->border) {
                gdi_draw_rect(item->color, item->x, item->y, item->width, item->height);
        }

        if (text[0] != 0 && UI_IS_FLAG_SET(item, UI_FLAG_VALID)) {
                len = ui_measure_string(prop->font, text, prop->scale);
        } else {
                len = ui_measure_string(prop->font, prop->text, prop->scale);
        }

        switch (prop->align) {
        case UI_ALIGN_LEFT:
                x = item->x + 2;
                break;

        case UI_ALIGN_CENTER:
                x = item->x + (item->width - len) / 2;
                break;

        case UI_ALIGN_RIGHT:
                x = item->x + item->width - len - 1;
                break;
        default:
                return;
        }

        y = item->y + (item->height - prop->font->height) / 2 + 1;

        if (text[0] != 0 && UI_IS_FLAG_SET(item, UI_FLAG_VALID)) {
                ui_draw_string(item->color, x, y, prop->font, text, prop->scale);
        } else {
                ui_draw_string(item->color, x, y, prop->font, prop->text, prop->scale);
        }
}

void ui_textbox_set_text(const ui_screen_item_t *item, const char *format, ...)
{
        char *text = (char *) item->status;
        int chars;
        const int prev_chars = strlen(text) + 1;;
        va_list ap;

        {
                char prev_text[prev_chars];
                memcpy(&prev_text, text, sizeof(prev_text));

                va_start(ap, format);
                chars = vsprintf(text, format, ap);
                va_end(ap);

                if(memcmp(&prev_text, text, chars > 0 ? chars + 1 : 0))
                        UI_SET_FLAG(item, UI_FLAG_REDRAW);
        }
}

/**
 * \}
 * \}
 * \}
 */
