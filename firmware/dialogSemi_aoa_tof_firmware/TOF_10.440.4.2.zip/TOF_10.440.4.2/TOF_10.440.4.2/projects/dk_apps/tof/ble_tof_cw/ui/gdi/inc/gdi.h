/**
 * \addtogroup UI
 * \{
 * \addtogroup GDI
 *
 * \brief Basic graphic functions
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file gdi.h
 *
 * @brief Basic graphic functions API
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef GDI_H_
#define GDI_H_

#include "stdint.h"
#include "stdlib.h"
#include "stdbool.h"
#include "fonts.h"

#define CF_NATIVE_RGB332        (3)
#define CF_NATIVE_RGBA8888      (5)

#if dg_configUSE_DT280QV10CT
#define USE_COLOR_FORMAT        (CF_NATIVE_RGB332)
#else
#define USE_COLOR_FORMAT        (CF_NATIVE_RGBA8888)
#endif

#if USE_COLOR_FORMAT == CF_NATIVE_RGB332

#define GDI_COLOR_BYTES         (1)
#define GDI_COLOR_FIELD         (0xFF)
#define GDI_RED_FIELD           (0xE0)
#define GDI_GREEN_FIELD         (0x1C)
#define GDI_BLUE_FIELD          (0x03)
#define GDI_ALPHA_FIELD         (0x00)

#define GDI_RED_POS             (5)
#define GDI_GREEN_POS           (2)
#define GDI_BLUE_POS            (0)
#define GDI_ALPHA_POS           (0)

#define GDI_RED_WIDTH           (3)
#define GDI_GREEN_WIDTH         (3)
#define GDI_BLUE_WIDTH          (2)
#define GDI_ALPHA_WIDTH         (0)

typedef enum { /* RGB332 */
        GDI_COLOR_BLACK   = 0x00,
        GDI_COLOR_RED     = 0xE0,
        GDI_COLOR_YELLOW  = 0xFC,
        GDI_COLOR_GREEN   = 0x1C,
        GDI_COLOR_CYAN    = 0x1F,
        GDI_COLOR_BLUE    = 0x03,
        GDI_COLOR_DBLUE   = 0x0F, //Dialog blue: 0, 172, 205 -> 0, 4, 2
        GDI_COLOR_MAGENTA = 0xE3,
        GDI_COLOR_WHITE   = 0xFF,
} gdi_color_t;

#elif USE_COLOR_FORMAT == CF_NATIVE_RGBA8888

#define GDI_COLOR_BYTES         (4)
#define GDI_COLOR_FIELD         (0x00FFFFFF)
#define GDI_RED_FIELD           (0x000000FF)
#define GDI_GREEN_FIELD         (0x0000FF00)
#define GDI_BLUE_FIELD          (0x00FF0000)
#define GDI_ALPHA_FIELD         (0xFF000000)

#define GDI_RED_POS             (0)
#define GDI_GREEN_POS           (8)
#define GDI_BLUE_POS            (16)
#define GDI_ALPHA_POS           (24)

#define GDI_RED_WIDTH           (8)
#define GDI_GREEN_WIDTH         (8)
#define GDI_BLUE_WIDTH          (8)
#define GDI_ALPHA_WIDTH         (8)

typedef enum { /* RGBA8888 */
        GDI_COLOR_BLACK   = 0xFF000000,
        GDI_COLOR_RED     = 0xFF0000FF,
        GDI_COLOR_YELLOW  = 0xFF00FFFF,
        GDI_COLOR_GREEN   = 0xFF00FF00,
        GDI_COLOR_CYAN    = 0xFFFFFF00,
        GDI_COLOR_BLUE    = 0xFFFF0000,
        GDI_COLOR_DBLUE   = 0xFFCDAC00, //Dialog blue: 0, 172, 205
        GDI_COLOR_MAGENTA = 0xFFFF00FF,
        GDI_COLOR_WHITE   = 0xFFFFFFFF,
} gdi_color_t;

#endif /* USE_COLOR_FORMAT */

typedef enum {
        GDI_FORMAT_L1,
        GDI_FORMAT_L4,
        GDI_FORMAT_L8,
        GDI_FORMAT_RGB332,
        GDI_FORMAT_RGB565,
        GDI_FORMAT_ABGR8888,
        GDI_FORMAT_RGBA8888,
} gdi_color_fmt_t;

typedef uint16_t gdi_coord_t;
typedef uint8_t gdi_scale_t;

#if dg_configUSE_LPM012M134B
#define GDI_DISP_RESX           (240)
#define GDI_DISP_RESY           (240)
#elif dg_configUSE_LPM013M091A
#define GDI_DISP_RESX           (320)
#define GDI_DISP_RESY           (300)
#elif dg_configUSE_PSP27801
#define GDI_DISP_RESX           (96)
#define GDI_DISP_RESY           (96)
#elif dg_configUSE_DT280QV10CT
#define GDI_DISP_RESX           (240)
#define GDI_DISP_RESY           (320)
#endif

/**
 * \brief GDI type definition
 */
typedef struct {
        int32_t stride;
        uint8_t active_buf;    /**< Active frame buffer */
        uint8_t bufs_num;      /**< Number of buffers available */
        gdi_coord_t width;
        gdi_coord_t height;
        gdi_color_t bg_color;  /**< Display background color */
        bool display_powered;  /**< Display power state */
        bool display_enabled;  /**< Display enabled state */
        gdi_color_fmt_t color_format; /**< Color format */
        uint8_t *buffer[];      /**< Frame buffers table */
} gdi_t;

/**
 * \brief GDI initialization
 *
 * Initializes the GDI instance � allocate memory and set default background color
 */
void gdi_init(void);

/**
 * \brief Enables buffer of the GDI
 */
void gdi_buffer_enable(void);

/**
 * \brief Disables buffer of the GDI
 */
void gdi_buffer_disable(void);

/**
 * \brief Power on the display
 */
void gdi_display_power_on(void);

/**
 * \brief Power off the display
 */
void gdi_display_power_off(void);

/**
 * \brief Checks if display is powered.
 *
 * \return True if display is powered, false otherwise.
 */
bool gdi_display_is_powered(void);

/**
 * \brief Enable the display
 */
void gdi_display_enable(void);

/**
 * \brief Disable the display
 */
void gdi_display_disable(void);

/**
 * \brief Checks if display is enabled.
 *
 * \return True if display is enabled, false otherwise.
 */
bool gdi_display_is_enabled(void);

/**
 * \brief Update display
 *
 * Move data from active frame buffer to the display memory
 */
void gdi_display_update(void);

/**
 * \brief Clear display
 *
 * Clear the display
 */
void gdi_display_clear(void);

/**
 * \brief Update display in left direction
 *
 * Display will be updated using data from two frame buffers with swipe animation
 */
void gdi_swipe_left(gdi_coord_t offsety);

/**
 * \brief Update display in right direction
 *
 * Display will be updated using data from two frame buffers with swipe animation
 */
void gdi_swipe_right(gdi_coord_t offsety);

/**
 * \brief Update display in up direction
 *
 * Display will be updated using data from two frame buffers with swipe animation
 */
void gdi_swipe_up(gdi_coord_t offsety);

/**
 * \brief Update display in down direction
 *
 * Display will be updated using data from two frame buffers with swipe animation
 */
void gdi_swipe_down(gdi_coord_t offsety);

/**
 * \brief Set display background color
 *
 * This function set the background color for all frame buffers. The existing frame buffer
 * content will be erased.
 *
 * \param [in] color background color: BLACK or WHITE
 */
void gdi_set_bg_color(gdi_color_t color);

/**
 * \brief Reset currently selected (active) frame buffer
 */
void gdi_flush_active_frame_buffer(void);

/**
 * \brief Clear all frame buffers
 */
void gdi_flush_frame_buffers(void);

/**
 * \brief Select next available frame buffer
 */
void gdi_set_next_frame_buffer(void);

/**
 * \brief Get number of current frame buffer
 *
 * \return Number of currently selected frame buffer
 */
uint8_t gdi_get_current_frame_buffer(void);

/**
 * \brief Set active frame buffer
 *
 * \param [in] frame number of frame buffer
 */
void gdi_set_frame_buffer(uint8_t frame);

/**
 * \brief Draw pixel
 *
 * \param [in] x pixel x coordinate
 * \param [in] y pixel y coordinate
 */
void gdi_draw_dot(gdi_color_t color, gdi_coord_t x, gdi_coord_t y);

/**
 * \brief Draw circle
 *
 * \param [in] x0 circle center point x coordinate
 * \param [in] y0 circle center point y coordinate
 * \param [in] diameter circle diameter
 */
void gdi_draw_circle(gdi_color_t color, gdi_coord_t x0, gdi_coord_t y0, gdi_coord_t diameter);

/**
 * \brief Draw filled circle
 *
 * \param [in] x0 circle center point x coordinate
 * \param [in] y0 circle center point y coordinate
 * \param [in] radius circle radius
 */
void gdi_draw_fill_circle(gdi_color_t color, gdi_coord_t x0, gdi_coord_t y0, gdi_coord_t radius);

/**
 * \brief Draw line
 *
 * \param [in] x0 start point x coordinate
 * \param [in] y0 start point y coordinate
 * \param [in] x1 end point x coordinate
 * \param [in] y1 end point y coordinate
 */
void gdi_draw_line(gdi_color_t color, gdi_coord_t x0, gdi_coord_t y0, gdi_coord_t x1,
        gdi_coord_t y1);

/**
 * \brief Draw a grayscale image by applying a provided color instead of black and white
 *
 * \param [in] x upper left corner x coordinate
 * \param [in] y upper left corner y coordinate
 * \param [in] image pointer to image bitmap
 * \param [in] src_format format of the source image
 * \param [in] width image width
 * \param [in] height image height
 * \param [in] color color to be applyed
 */
void gdi_draw_image_recolor(gdi_coord_t x, gdi_coord_t y, const uint8_t *image,
        gdi_color_fmt_t src_format, gdi_coord_t width, gdi_coord_t height, gdi_color_t color);

/**
 * \brief Draw image
 *
 * \param [in] x upper left corner x coordinate
 * \param [in] y upper left corner y coordinate
 * \param [in] image pointer to image bitmap
 * \param [in] width image width
 * \param [in] height image height
 */
void gdi_draw_image(gdi_coord_t x, gdi_coord_t y, const uint8_t *image, gdi_color_fmt_t src_format,
        gdi_coord_t width, gdi_coord_t height);

/**
 * \brief Draw a character of the provided font to the frame buffer.
 *
 * Scaling can also be applied using the provided scaling value.
 *
 * \param [in] character ascii value of the character
 * \param [in] color color of the character
 * \param [in] x upper left corner x coordinate
 * \param [in] y upper left corner y coordinate
 * \param [in] scale scaling value in tenths (10 value does not scale the character)
 * \param [in] font font type
 * \return
 */
uint8_t gdi_draw_font(char character, gdi_color_t color, gdi_coord_t x, gdi_coord_t y,
        gdi_scale_t scale, const font_info_t * font);

/**
 * \brief Draw rectangle
 *
 * \param [in] x upper left corner x coordinate
 * \param [in] y upper left corner y coordinate
 * \param [in] w rectangle width
 * \param [in] h rectangle height
 */
void gdi_draw_rect(gdi_color_t color, gdi_coord_t x, gdi_coord_t y, gdi_coord_t w, gdi_coord_t h);

/**
 * \brief Draw filled rectangle
 *
 * \param [in] x upper left corner x coordinate
 * \param [in] y upper left corner y coordinate
 * \param [in] w rectangle width
 * \param [in] h rectangle height
 */
void gdi_draw_fill_rect(gdi_color_t color, gdi_coord_t x, gdi_coord_t y, gdi_coord_t w,
        gdi_coord_t h);

/**
 * \brief Draw arc
 *
 * \param [in] x arc center point x coordinate
 * \param [in] y arc center point y coordinate
 * \param [in] r arc radius
 * \param [in] t line thickness
 * \param [in] start_angle arc start angle
 * \param [in] end_angle arc end angle
 */
void gdi_draw_arc(gdi_color_t color, gdi_coord_t x, gdi_coord_t y, gdi_coord_t r, gdi_coord_t t,
        int start_angle, int end_angle);

//
// Getting address of frame buffer
//
void * gdi_get_frame_buffer_addr(void);

#endif /* GDI_H_ */

/**
 * \}
 * \}
 */
