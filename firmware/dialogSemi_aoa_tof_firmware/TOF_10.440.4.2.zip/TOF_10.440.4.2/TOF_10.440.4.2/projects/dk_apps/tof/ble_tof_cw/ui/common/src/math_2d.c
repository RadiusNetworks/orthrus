/**
 * \addtogroup UI
 * \{
 * \addtogroup MATH_2D
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file math_2d.c
 *
 * @brief 2D fixed point math functions implementation
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include "math_2d.h"

#define IS_VALUE_BETWEEN(value, min, max)       ((value) >= (min) && (value) <= (max))

const int8_t sin_tab[64] = { 0x00, 0x03, 0x06, 0x09, 0x0D, 0x10, 0x13, 0x16, 0x19, 0x1C, 0x1F, 0x22,
                0x25, 0x28, 0x2B, 0x2E, 0x31, 0x34, 0x37, 0x3A, 0x3D, 0x40, 0x42, 0x45, 0x48, 0x4A,
                0x4D, 0x4F, 0x52, 0x54, 0x56, 0x59, 0x5B, 0x5D, 0x5F, 0x61, 0x63, 0x65, 0x67, 0x69,
                0x6B, 0x6C, 0x6E, 0x70, 0x71, 0x72, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7A, 0x7B,
                0x7C, 0x7C, 0x7D, 0x7D, 0x7E, 0x7E, 0x7E, 0x7E, 0x7F, 0x7F };

/**
 * \brief Division between two unsigned integers
 * @param num           Dividend (16-bit)
 * @param div           Divisor (8-bit)
 * @return              Quotient of the division (8-bit)
 */
static uint8_t math2d_divide_8(uint16_t num, uint8_t div)
{
        return (uint8_t) (num / div);
}

/**
 * \brief Division between two unsigned integers
 * @param num           Dividend (32-bit)
 * @param div           Divisor (16-bit)
 * @return              Quotient of the division (16-bit)
 */
static uint16_t math2d_divide_16(uint32_t num, uint16_t div)
{
        return (uint16_t) (num / div);
}

uint8_t math2d_mul_div_uu8(uint8_t u1, uint8_t u2, uint8_t d)
{
        uint16_t n;

        n = (uint16_t) (((uint16_t) u1 * (uint16_t) u2) + (d / 2));

        return math2d_divide_8(n, d);
}

int8_t math2d_mul_div_su8(int8_t s, uint8_t u, uint8_t d)
{
        uint16_t n;
        uint8_t r;

        if (s >= 0) {
                n = (uint16_t) (((uint8_t) s * (uint16_t) u) + (d / 2));
                r = math2d_divide_8(n, d);
                return (int8_t) ((r > (uint8_t) 127) ? 127 : r);
        } else {
                n = (uint16_t) ((((uint8_t) -s) * (uint16_t) u) + (d / 2));
                r = math2d_divide_8(n, d);
                return (int8_t) (r > 128 ? -128 : (int8_t) (-1 * ((int8_t) r)));
        }
}

uint16_t math2d_mul_div_uu16(uint16_t u1, uint16_t u2, uint16_t d)
{
        uint32_t n;

        n = (uint32_t) ((uint32_t) ((uint32_t) u1 * (uint32_t) u2) + (d / 2));

        return math2d_divide_16(n, d);
}

int16_t math2d_mul_div_su16(int16_t s, uint16_t u, uint16_t d)
{
        uint32_t n;
        uint16_t r;

        if (s >= 0) {
                n = (uint32_t) (((uint16_t) s * (uint32_t) u) + (d / 2));
                r = math2d_divide_16(n, d);
                return (int16_t) ((r > (uint16_t) 0x7FFF) ? 0x7FFF : r);
        } else {
                n = (uint32_t) ((((uint16_t) -s) * (uint32_t) u)) + (d / 2);
                r = math2d_divide_16(n, d);
                return (int16_t) (r > 0x8000 ? -32768 : (int16_t) (-1 * ((int16_t) r)));
        }
}

uint16_t math2d_abs_16(int16_t num)
{
        return num < 0 ? (uint16_t) (-num) : (uint16_t) num;
}

uint16_t math2d_limit_u16(uint16_t val, uint16_t min, uint16_t max)
{
        if (IS_VALUE_BETWEEN(val, min, max)) {
                return val;
        } else {
                return val > max ? max : min;
        }
}

int16_t math2d_limit_s16(int16_t val, int16_t min, int16_t max)
{
        if (IS_VALUE_BETWEEN(val, min, max)) {
                return val;
        } else {
                return val > max ? max : min;
        }
}

uint8_t math2d_limit_u8(uint8_t val, uint8_t min, uint8_t max)
{
        if (IS_VALUE_BETWEEN(val, min, max)) {
                return val;
        } else {
                return val > max ? max : min;
        }
}

int8_t math2d_limit_s8(int8_t val, int8_t min, int8_t max)
{
        if (IS_VALUE_BETWEEN(val, min, max)) {
                return val;
        } else {
                return val > max ? max : min;
        }
}

int8_t math2d_sin(uint8_t x)
{
        if (x < 0x80) {
                if (x <= 0x3F)
                        return sin_tab[x];
                else
                        return sin_tab[0x3F - (x - 0x40)];
        } else {
                if (x <= 0xBF)
                        return (int8_t) (-sin_tab[x - 0x80]);
                else
                        return (int8_t) (-sin_tab[0x3F - (x - 0xC0)]);
        }
}

int8_t math2d_cos(uint8_t x)
{
        if (x < 0x80) {
                if (x <= 0x3F) {
                        return sin_tab[0x3F - x];
                } else {
                        return (int8_t) (-sin_tab[x - 0x40]);
                }
        } else {
                if (x <= 0xBF) {
                        return (int8_t) (-sin_tab[0x3F - (x - 0x80)]);
                } else {
                        return sin_tab[x - 0xC0];
                }
        }
}

/**
 * \}
 * \}
 */
