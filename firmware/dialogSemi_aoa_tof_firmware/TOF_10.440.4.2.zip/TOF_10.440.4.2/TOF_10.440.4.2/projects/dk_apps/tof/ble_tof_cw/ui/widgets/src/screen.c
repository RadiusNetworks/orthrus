/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup SCREEN
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file screen.c
 *
 * @brief Screen widget implementation
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include "common.h"
#include "screen.h"
#include "status_bar.h"
#include "gdi.h"
#include "osal.h"
#include "stdbool.h"
#include "ui_widgets.h"

PRIVILEGED_DATA static const ui_screen_t *active_screen;
PRIVILEGED_DATA static const ui_status_bar_t *status_bar;

static uint8_t check_if_redraw_needed(const ui_screen_t * const screen)
{
        ui_screen_item_t **object = (ui_screen_item_t**) screen->items;

        if (UI_IS_FLAG_SET(screen, UI_FLAG_REDRAW)) {
                UI_CLEAR_FLAG(screen, UI_FLAG_REDRAW);
                return 1;
        }

        while (*object != NULL) {
                if (UI_IS_FLAG_SET(*object, UI_FLAG_REDRAW)) {
                        return 1;
                }
                object++;
        }

        return 0;
}

static uint8_t draw_screen(const ui_screen_t * const screen, bool force_redraw)
{
        ui_screen_item_t **item = (ui_screen_item_t**) screen->items;

        if (UI_IS_FLAG_SET(screen, UI_FLAG_STATUS_BAR) && ui_status_bar_redraw_needed(status_bar)) {
                force_redraw = true;
        }

        if (check_if_redraw_needed(screen) == 0 && force_redraw == false) {
                return 0;
        }

        gdi_flush_active_frame_buffer();

        if (screen->on_main) {
                screen->on_main(NULL);
        }

        while (*item != NULL) {
                switch ((*item)->type) {

                case UI_CIRCLE_PROGRESS_BAR:
                        ui_draw_circle_progress(*item);
                        break;

                case UI_IMAGE:
                        ui_draw_image(*item);
                        break;

                case UI_STATIC_LABEL:
                        ui_draw_static_label(*item);
                        break;

                case UI_TEXTBOX:
                        ui_draw_textbox(*item);
                        break;

                case UI_ANALOG_CLOCK:
                        ui_analog_clock_draw(*item);
                        break;

                default:
                        break;
                }

                UI_CLEAR_FLAG(*item, UI_FLAG_REDRAW);
                item++;
        }

        if (UI_IS_FLAG_SET(screen, UI_FLAG_STATUS_BAR)) {
                ui_draw_status_bar(status_bar);
        }

        return 1;
}

void ui_set_active_screen(const ui_screen_t * const screen)
{
        active_screen = screen;
        UI_SET_FLAG(screen, UI_FLAG_REDRAW);
}

void ui_draw_active_screen(bool force_redraw)
{
        bool redraw;

        gdi_buffer_enable();

        uint8_t frame = gdi_get_current_frame_buffer();

        gdi_set_next_frame_buffer();
        redraw = draw_screen(active_screen, force_redraw);

        if (!redraw) {
                gdi_set_frame_buffer(frame);
        } else {
                gdi_display_update();
        }

        gdi_buffer_disable();
}

/**
 * \brief Draw next screen in next available frame buffer
 *
 * \param [in] screen pointer to suitable screen
 */
static void ui_prepare_next_screen(const ui_screen_t *const screen)
{
        uint8_t frame = gdi_get_current_frame_buffer();
        gdi_set_next_frame_buffer();

        draw_screen(screen, true);

        gdi_set_frame_buffer(frame);
}

void ui_swipe_left(const ui_screen_t * const screen)
{
        gdi_buffer_enable();

        ui_prepare_next_screen(screen);

        gdi_swipe_left(UI_IS_FLAG_SET(screen, UI_FLAG_STATUS_BAR) ? status_bar->height : 0);

        active_screen = screen;

        gdi_buffer_disable();
}

void ui_swipe_right(const ui_screen_t * const screen)
{
        gdi_buffer_enable();

        ui_prepare_next_screen(screen);

        gdi_swipe_right(UI_IS_FLAG_SET(screen, UI_FLAG_STATUS_BAR) ? status_bar->height : 0);

        active_screen = screen;

        gdi_buffer_disable();
}

void ui_swipe_up(const ui_screen_t * const screen)
{
        gdi_buffer_enable();

        ui_prepare_next_screen(screen);

        gdi_swipe_up(UI_IS_FLAG_SET(screen, UI_FLAG_STATUS_BAR) ? status_bar->height : 0);

        active_screen = screen;

        gdi_buffer_disable();
}

void ui_swipe_down(const ui_screen_t * const screen)
{
        gdi_buffer_enable();

        ui_prepare_next_screen(screen);

        gdi_swipe_down(UI_IS_FLAG_SET(screen, UI_FLAG_STATUS_BAR) ? status_bar->height : 0);

        active_screen = screen;

        gdi_buffer_disable();
}

void ui_set_item_visibility(const ui_screen_item_t * const item, bool visibility)
{
        /* Check if redraw is needed */
        if(UI_IS_FLAG_SET(item, UI_FLAG_VISIBLE) != visibility){
                if (visibility) {
                        UI_SET_FLAG(item, UI_FLAG_VISIBLE);
                } else {
                        UI_CLEAR_FLAG(item, UI_FLAG_VISIBLE);
                }

                UI_SET_FLAG(item, UI_FLAG_REDRAW);
        }

        /* Reset blinking flag if visibility state is explicitly set */
        UI_CLEAR_FLAG(item, UI_FLAG_BLINKING);
}

void ui_toggle_item_visibility(const ui_screen_item_t * const item)
{
        if (UI_IS_FLAG_SET(item, UI_FLAG_VISIBLE)) {
                UI_CLEAR_FLAG(item, UI_FLAG_VISIBLE);
        } else {
                UI_SET_FLAG(item, UI_FLAG_VISIBLE);
        }

        UI_SET_FLAG(item, UI_FLAG_REDRAW);
}

bool ui_get_item_visibility(const ui_screen_item_t * const item)
{
        if (UI_IS_FLAG_SET(item, UI_FLAG_VISIBLE)) {
                return true;
        } else {
                return false;
        }
}

void ui_set_item_validity(const ui_screen_item_t * const item, bool validity)
{
        /* Check if redraw is needed */
        if(UI_IS_FLAG_SET(item, UI_FLAG_VALID) != validity){
                if (validity) {
                        UI_SET_FLAG(item, UI_FLAG_VALID);
                } else {
                        UI_CLEAR_FLAG(item, UI_FLAG_VALID);
                }

                UI_SET_FLAG(item, UI_FLAG_REDRAW);
        }
}

bool ui_get_item_validity(const ui_screen_item_t * const item)
{
        if (UI_IS_FLAG_SET(item, UI_FLAG_VALID)) {
                return true;
        } else {
                return false;
        }
}

void ui_set_item_blinking(const ui_screen_item_t * const item, bool blinking)
{
        if (blinking) {
                UI_SET_FLAG(item, UI_FLAG_BLINKING);
        } else {
                UI_CLEAR_FLAG(item, UI_FLAG_BLINKING);
        }
}

bool ui_get_item_blinking(const ui_screen_item_t *item)
{
        if (UI_IS_FLAG_SET(item, UI_FLAG_BLINKING)) {
                return true;
        } else {
                return false;
        }
}

void ui_register_status_bar(ui_status_bar_t * bar)
{
        status_bar = bar;
        bar->height = ui_status_bar_height(bar);
}

void ui_unregister_status_bar(void)
{
        status_bar = NULL;
}

/**
 * \}
 * \}
 * \}
 */
