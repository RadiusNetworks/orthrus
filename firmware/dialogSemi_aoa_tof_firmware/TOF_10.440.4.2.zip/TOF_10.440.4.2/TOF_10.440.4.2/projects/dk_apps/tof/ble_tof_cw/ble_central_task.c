/**
 ****************************************************************************************
 *
 * @file central_task.c
 *
 * @brief BLE central task
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "osal.h"
#include "sys_watchdog.h"
#include "sys_clock_mgr.h"
#include "ble_att.h"
#include "ble_gap.h"
#include "ble_gattc.h"
#include "ble_gattc_util.h"
#include "ble_service.h"
#include "sys_trng.h"

#include "sdk_queue.h"
#include "ble_mgr.h"

#include "ble_tof.h"
#include "ble_tof_sync.h"
#include "user_config_defs.h"
#include "ble_tof_cw_config.h"
#include "tof_interface.h"
#include "tof_cli.h"
#include "tof_hw.h"

#if TOF_ENABLE_CW_DIST_CALC
#include "iq_demultiplex.h"
#include "cw_distance.h"
#endif
#include "acquisition.h"

/*
 * Notification bits reservation
 * bit #0 is always assigned to BLE event queue notification
 * bit #5 is always assigned to ToF synchronization end notification
 */
#define DISCOVER_NOTIF                  (1 << 1)
#define CONNECT_NOTIF                   (1 << 2)
#define SCAN_START_NOTIF                (1 << 3)
#define CONNECT_TO_NOTIF                (1 << 4)
#define CLI_INPUT_NOTIF                 (1 << 6)

typedef struct {
        void *next;
        uint16_t start_h;
        uint16_t end_h;
} service_t;

typedef struct {
        void *next;
        uint16_t handle;
        uint16_t val_h;
} characteristic_t;


PRIVILEGED_DATA static queue_t services;
PRIVILEGED_DATA static queue_t characteristics;

PRIVILEGED_DATA static OS_TASK ble_central_task_handle;

/* Use 4 byte alignment to avoid the unpacking of phase values for calculations */
PRIVILEGED_DATA static tof_result_t i_result __ALIGNED(4);              // initiator result
PRIVILEGED_DATA static tof_result_t r_result __ALIGNED(4);              // responder result

INITIALISED_PRIVILEGED_DATA static uint16_t evt_counter = 0;            // next event counter after synchronization end
INITIALISED_PRIVILEGED_DATA static uint16_t cw_evt_counter = 0;         // event counter for cw measurement
INITIALISED_PRIVILEGED_DATA static uint16_t to_evt_counter = 0;         // timeout event counter for remote results

INITIALISED_PRIVILEGED_DATA static OS_TICK_TIME start_tick = 0;

#if CLI_MODE
/* Check if a stop command was received from cli */
bool stop_cmd = false;
/* Timeout for connection attempts */
PRIVILEGED_DATA static OS_TIMER con_tmo_timer;
#endif

extern float cw_distance_offset; /* in meters */

struct central_context {
        att_uuid_t      peripheral_service_uuid;
        bd_address_t    peripheral_bd_address;

        uint16_t conn_idx;

        uint16_t tof_status_val_h;
        uint16_t tof_status_ccc_h;
        uint16_t tof_i_result_val_h;
        uint16_t tof_r_result_val_h;
        uint16_t tof_r_result_ccc_h;
        uint16_t tof_value_val_h;

        tof_status_t tof_status;
        tof_error_t tof_err_code;
        uint16_t tof_value;

        OS_TIMER tof_tim;

        uint8_t conf_set_number;
};

INITIALISED_PRIVILEGED_DATA static struct central_context ctx = { {0} };

static void update_tof_status(tof_status_t status);
static void handle_tof_results_notification();
static void handle_tof_status_notification(tof_status_pdu_t *pdu);

const gap_conn_params_t cp = {
        .interval_min = BLE_CONN_INTERVAL_MIN,
        .interval_max = BLE_CONN_INTERVAL_MAX,
        .slave_latency = BLE_CONN_SLAVE_LATENCY,
        .sup_timeout = BLE_CONN_SUPERVISION_TO
};

const gap_conn_params_t cp_fast = {
        .interval_min = BLE_CONN_INTERVAL_FROM_MS(12),   // 12.00ms
        .interval_max = BLE_CONN_INTERVAL_FROM_MS(16),   // 16.00ms
        .slave_latency = 0,
        .sup_timeout = BLE_SUPERVISION_TMO_FROM_MS(210), // 210ms
};


#ifdef DEBUG_TOF
/* return static buffer with formatted UUID */
static const char *format_uuid(const att_uuid_t *uuid)
{
        static char buf[37];

        if (uuid->type == ATT_UUID_16) {
                sprintf(buf, "0x%04x", uuid->uuid16);
        } else {
                int i;
                int idx = 0;

                for (i = ATT_UUID_LENGTH; i > 0; i--) {
                        if (i == 12 || i == 10 || i == 8 || i == 6) {
                                buf[idx++] = '-';
                        }

                        idx += sprintf(&buf[idx], "%02x", uuid->uuid128[i - 1]);
                }
        }

        return buf;
}

/* return static buffer with characteristics properties mask */
static const char *format_properties(uint8_t properties)
{
        static const char props_str[] = "BRXWNISE"; // each letter corresponds to single property
        static char buf[9];
        int i;

        // copy full properties mask
        memcpy(buf, props_str, sizeof(props_str));

        for (i = 0; i < 8; i++) {
                // clear letter from mask if property not present
                if ((properties & (1 << i)) == 0) {
                        buf[i] = '-';
                }
        }

        return buf;
}
#endif

static void handle_evt_gap_adv_report(ble_evt_gap_adv_report_t *evt)
{
        uint8_t index = 0;

        /* process TLVs looking for peripheral device service UUID */
        while (index + 2 < evt->length) {
                /* TLV with service id and data */
                if (evt->data[index+1] == GAP_DATA_TYPE_UUID128_SVC_DATA) {
                        if (memcmp(&evt->data[index+2], ctx.peripheral_service_uuid.uuid128,
                                           ATT_UUID_LENGTH) == 0 &&
                                        evt->data[index+2 + ATT_UUID_LENGTH] == ctx.conf_set_number) {
                                printf("Peripheral device found: set_nb: %d\r\n", ctx.conf_set_number);
                                /* save BD address */
                                memcpy(&ctx.peripheral_bd_address, &evt->address,
                                                                             sizeof(bd_address_t));
                                /* stop the scan */
                                ble_gap_scan_stop();
                        }
                }
                index += (evt->data[index] + 1); // go to the next TLV
        }
}

static void handle_evt_gap_scan_completed(ble_evt_gap_scan_completed_t *evt)
{
        bd_address_t empty_addr = {0};

        printf("%s: status=%04x\r\n", __func__, evt->status);

        if (memcmp(&ctx.peripheral_bd_address, &empty_addr, sizeof(bd_address_t))) {
                OS_TASK_NOTIFY(ble_central_task_handle, CONNECT_NOTIF, eSetBits);
        } else {
                /* not found -> restart scan */
                printf("Peripheral device not found - restarting scan\r\n");
                OS_TASK_NOTIFY(ble_central_task_handle, SCAN_START_NOTIF, eSetBits);
        }
}

static void handle_evt_gattc_discover_svc(ble_evt_gattc_discover_svc_t *evt)
{
        service_t *service;

        dbg_printf("%s: conn_idx=%04x uuid=%s start_h=%04x end_h=%04x\r\n", __func__, evt->conn_idx,
                                                format_uuid(&evt->uuid), evt->start_h, evt->end_h);

        service = OS_MALLOC(sizeof(*service));
        service->start_h = evt->start_h;
        service->end_h = evt->end_h;

        queue_push_back(&services, service);
}

static void handle_evt_gattc_discover_char(ble_evt_gattc_discover_char_t *evt)
{
        characteristic_t *characteristic;
        att_uuid_t uuid;

        dbg_printf("%s: conn_idx=%04x uuid=%s handle=%04x value_handle=%04x properties=%02x (%s)\r\n",
                __func__, evt->conn_idx, format_uuid(&evt->uuid), evt->handle, evt->value_handle,
                evt->properties, format_properties(evt->properties));

        ble_uuid_from_string(UUID_TOF_STATUS, &uuid); // ToF status
        if (ble_uuid_equal(&uuid, &evt->uuid)) {
                if (evt->properties & GATT_PROP_WRITE) {
                        ctx.tof_status_val_h = evt->value_handle;
                }
        }

        ble_uuid_from_string(UUID_TOF_I_RESULT, &uuid); // ToF initiator result
        if (ble_uuid_equal(&uuid, &evt->uuid)) {
                if (evt->properties & GATT_PROP_WRITE) {
                        ctx.tof_i_result_val_h = evt->value_handle;
                }
        }

        ble_uuid_from_string(UUID_TOF_R_RESULT, &uuid); // ToF responder result
        if (ble_uuid_equal(&uuid, &evt->uuid)) {
                if (evt->properties & GATT_PROP_NOTIFY) {
                        ctx.tof_r_result_val_h = evt->value_handle;
                }
        }

        ble_uuid_from_string(UUID_TOF_VALUE, &uuid); // ToF value
        if (ble_uuid_equal(&uuid, &evt->uuid)) {
                if (evt->properties & GATT_PROP_WRITE) {
                        ctx.tof_value_val_h = evt->value_handle;
                }
        }

        characteristic = OS_MALLOC(sizeof(*characteristic));
        characteristic->handle = evt->handle;
        characteristic->val_h = evt->value_handle;

        queue_push_back(&characteristics, characteristic);
}

static void handle_evt_gattc_discover_desc(ble_evt_gattc_discover_desc_t *evt)
{
        att_uuid_t uuid;

        dbg_printf("%s: conn_idx=%04x uuid=%s handle=%04x\r\n", __func__, evt->conn_idx,
                                                        format_uuid(&evt->uuid), evt->handle);
        /* Look for  Status or Responder Result CCC */
        ble_uuid_create16(UUID_GATT_CLIENT_CHAR_CONFIGURATION, &uuid);
        if (ble_uuid_equal(&uuid, &evt->uuid)) {
                printf("setting tof ccc handle %d\r\n", evt->handle);
                /* Status ccc will be discovered first */
                if (ctx.tof_status_ccc_h == 0)
                        ctx.tof_status_ccc_h = evt->handle;
                else {
                        ctx.tof_r_result_ccc_h = evt->handle;
                }
                /* enable notifications */
                ble_gattc_util_write_ccc(evt->conn_idx, evt->handle, GATT_CCC_NOTIFICATIONS);


                /* Now the discovery is completed, let's start tof measurement */
                if (evt->handle == ctx.tof_r_result_ccc_h) {
                        ble_tof_sync_start();
                        update_tof_status(TOF_STATUS_START);
                }
        }
}

static void handle_evt_gattc_discover_completed(ble_evt_gattc_discover_completed_t *evt)
{
        service_t *service;

        dbg_printf("%s: conn_idx=%04x type=%d status=%d\r\n", __func__, evt->conn_idx, evt->type,
                                                                                        evt->status);


        service = queue_peek_front(&services);

        if (evt->type == GATTC_DISCOVERY_TYPE_SVC && service) {
                ble_gattc_discover_char(evt->conn_idx, service->start_h, service->end_h, NULL);
        } else if (evt->type == GATTC_DISCOVERY_TYPE_CHARACTERISTICS && service) {
                characteristic_t *charac, *next = NULL;

                for (charac = queue_peek_front(&characteristics); charac; charac = next) {
                        next = charac->next;

                        /*
                         * Check if there is enough room for at least one descriptor.
                         * Range start from next handle after characteristic value handle,
                         * ends before next characteristic or service's end handle
                         */
                        if (charac->val_h + 1 <= (next ? next->handle : service->end_h)) {
                                ble_gattc_discover_desc(evt->conn_idx, charac->val_h + 1, next ?
                                                        next->handle - 1 : service->end_h);
                        }
                }

                queue_remove_all(&characteristics, OS_FREE_FUNC);
                queue_pop_front(&services);
                OS_FREE(service);

                service = queue_peek_front(&services);
                if (service) {
                        ble_gattc_discover_char(evt->conn_idx, service->start_h,
                                                                        service->end_h, NULL);
                }
        }
}

static void handle_evt_gap_connection_completed(ble_evt_gap_connection_completed_t *evt)
{
        if ( evt->status == BLE_ERROR_CANCELED) {
                printf("Connection canceled\r\n");
        } else {
                printf("Connection completed iwth status %d\r\n", evt->status);
        }
}


static void handle_evt_gap_connected(ble_evt_gap_connected_t *evt)
{
        printf("%s: conn_idx=%04x\r\n", __func__, evt->conn_idx);

#if CLI_MODE
        OS_TIMER_STOP(con_tmo_timer, OS_TIMER_FOREVER);
#endif

        ctx.conn_idx = evt->conn_idx;

        /* start MTU exchange before discovery */
        printf("Exchanging MTU\r\n");
        ble_gattc_exchange_mtu(evt->conn_idx);\
}

static void handle_evt_gattc_mtu_changed(ble_evt_gattc_mtu_changed_t *evt)
{
        printf("MTU set to %u bytes\r\n", evt->mtu);

        // notify main thread, we'll start discovery from there
        OS_TASK_NOTIFY(ble_central_task_handle, DISCOVER_NOTIF, eSetBits);
}

static void handle_evt_gap_conn_param_updated(ble_evt_gap_conn_param_updated_t *evt)
{
        dbg_printf("%s: conn_idx=%04x\r\n", __func__, evt->conn_idx);
}

static void handle_evt_gap_disconnected(ble_evt_gap_disconnected_t *evt)
{
        ble_error_t err;
        ble_dev_params_t *params;
        bool advertising;

        printf("%s: conn_idx=%04x address=%s reason=%d\r\n", __func__, evt->conn_idx,
                                                 ble_address_to_string(&evt->address), evt->reason);

        queue_remove_all(&services, OS_FREE_FUNC);
        queue_remove_all(&characteristics, OS_FREE_FUNC);

        /* reset ccc handles, discovery assumes initial values are 0 */
        ctx.tof_status_ccc_h = 0;
        ctx.tof_r_result_ccc_h = 0;

        ble_tof_sync_stop();
        ble_tof_cw_stop();
        update_tof_status(TOF_STATUS_STOP);

        /* reset connection event counter */
        cmac_info_table_ptr->ble_conn_evt_counter[ctx.conn_idx] = 0;

        ctx.conn_idx = BLE_CONN_IDX_INVALID;

#if CLI_MODE
        /* Check if connection is terminated by local host */
        if (evt->reason == BLE_HCI_ERROR_CON_TERM_BY_LOCAL_HOST) {
                return;
        }

#endif
        printf("Peripheral device disconnected - restarting connection\r\n");

        /* notify main thread, we'll start reconnect */
        OS_TASK_NOTIFY(ble_central_task_handle, CONNECT_NOTIF, eSetBits);
}

static void handle_evt_gattc_read_completed(ble_evt_gattc_read_completed_t *evt)
{
        dbg_printf("%s: conn_idx=%04x handle=%04x status=%d\r\n", __func__, evt->conn_idx, evt->handle,
                                                                                        evt->status);
}

static void handle_evt_gattc_write_completed(ble_evt_gattc_write_completed_t *evt)
{
        dbg_printf("%s: conn_idx=%04x handle=%04x status=%d\r\n", __func__, evt->conn_idx, evt->handle,                                                                                        evt->status);
}

static void handle_evt_gattc_notification(ble_evt_gattc_notification_t *evt)
{
        if (evt->handle == ctx.tof_status_val_h) {
                if (evt->length == sizeof(tof_status_pdu_t)) {
                        handle_tof_status_notification((tof_status_pdu_t *) evt->value);
                } else {
                        printf("Status Notification with invalid size\r\n");
                }
        } else if (evt->handle == ctx.tof_r_result_val_h) {
                if (evt->length == sizeof(tof_result_t)) {
                       /* responder results received */
                        handle_tof_results_notification((tof_result_t *) evt->value);
                } else  {
                        printf("Result Notification with invalid size\r\n");
                }
        }
        else {
                printf("Notification from invalid handle\r\n");
        }
}

static void calc_phases()
{
        /* get agc gain from acquisition results */
        i_result.AGC_gain = get_acquisition_agc_value();
#if TOF_ENABLE_CW_DIST_CALC
        //GPIO->P1_05_MODE_REG = 0x300;
        //GPIO->P1_SET_DATA_REG = 1 << 5;         // P1_05 high
        //CRG_TOP->P1_SET_PAD_LATCH_REG = 1 << 5;


	cm_sys_clk_set(sysclk_PLL96);

        iq_demultiplex();
#if TOF_ENABLE_IFFT_DIST_CALC
        i_result.f_offset = roundf(cwd_calc_phase_mag_data(i_result.phase, i_result.amplitude));
        tof_params->mag_data = (uint32_t)i_result.amplitude;
#else
        i_result.f_offset = roundf(cwd_calc_phase_data(i_result.phase));
#endif /* TOF_ENABLE_IFFT_DIST_CALC */
        tof_params->phase_data = (uint32_t)i_result.phase;

#if !defined(MATLAB_MODE)
        /* PC may read phase data now */
        tof_params->fw_ready = 1;
#endif

	cm_sys_clk_set(sysclk_XTAL32M);

        //GPIO->P1_RESET_DATA_REG = 1 << 5;       // P1_05 low
        //CRG_TOP->P1_RESET_PAD_LATCH_REG = 1 << 5;

#else
        /*
         * Simulate delay for first computations
         * that produce the phase results
         */
        OS_DELAY_MS(50);
#endif
}

static void send_results(uint16_t evt_counter, tof_result_t *result)
{
        /* send results */
        result->event_counter = evt_counter - 1;
        result->measure_id = 0;
        ble_gattc_write_no_resp(ctx.conn_idx, ctx.tof_i_result_val_h, 0, sizeof(tof_result_t), (uint8_t *) result);
}

__UNUSED static void send_tof_value(void)
{
        ble_gattc_write(ctx.conn_idx, ctx.tof_value_val_h, 0, sizeof(ctx.tof_value),
                                                                    (uint8_t *) &ctx.tof_value);
        printf("ToF Range:%d\r\n",ctx.tof_value);
}

static void handle_tof_status_notification(tof_status_pdu_t *pdu)
{
        printf("remote status update %d reason %d\r\n", pdu->status, pdu->err_code);

        /* if remote device has stopped, restart cw measurement */
        if (pdu->status == TOF_STATUS_STOP) {
                /* update error code */
                ctx.tof_err_code = pdu->err_code;

                update_tof_status(TOF_STATUS_STOP);
                update_tof_status(TOF_STATUS_START);
        }
}

static void handle_tof_results_notification(tof_result_t *result)
{
        //printf("results received\r\n");

        if (ctx.tof_status == TOF_STATUS_CALC) {

                memcpy(&r_result, result, sizeof(tof_result_t));
#if TOF_ENABLE_CW_DIST_CALC

#if TOF_ENABLE_IFFT_DIST_CALC
                float distance = cwd_calc_ifft_distance_phase_mag(i_result.phase, i_result.amplitude, r_result.phase, r_result.amplitude);
#else
                float distance = cwd_calc_distance(i_result.phase, r_result.phase);
#endif /* TOF_ENABLE_IFFT_DIST_CALC */

                uint8_t dqf = cwd_calc_dqf(i_result.f_offset, r_result.f_offset);

                /* update distance with cw offset */
                distance = distance - cw_distance_offset;
                if (distance < 0) {
                        distance = 0;
                }

#if TOF_ENABLE_DISTANCE_AVG
                float avg_dist = calc_distance_average(distance, dqf);
#else
                float avg_dist = distance;
#endif

#if TOF_ENABLE_AUTO_XTAL_TRIM
                if (dqf != 0)
                {
                        static uint16_t xtrim = 0;
                        uint16_t new_xtrim = tune_xtal_trim(i_result.f_offset, 2.0);
                        if (xtrim != new_xtrim) {
                                printf("xtrim: %d => %d\n\r", xtrim, new_xtrim);
                                xtrim =  new_xtrim;
                        }
                }
#endif
                printf("\n\r**** ");
#if CLI_MODE
                printf("address %s ", ble_address_to_string(&ctx.peripheral_bd_address));
#endif
                printf("distance: %.2f, avg_dist: %.2f, event: %d, fo_i: %d, fo_r: %d, agc_i: %d, agc_r: %d, dqf: %d\n\n\r",
                        distance, avg_dist, i_result.event_counter, i_result.f_offset, r_result.f_offset, i_result.AGC_gain, r_result.AGC_gain, dqf);
                tof_interface_update_c_results(i_result.event_counter, distance);

                char disp_str[8];

                if ((dqf != 0) && (avg_dist < 40)) {
                        /* show valid results on display, only */
                        sprintf(disp_str,"%.1f", avg_dist);
                        tof_lcd_draw_string(disp_str);
                }

#else
                /*
                 * Simulate delay for computing result
                 */
                OS_DELAY_MS(50);
#endif
                ctx.tof_value++;
                //send_tof_value();
                update_tof_status(TOF_STATUS_STOP);

                /* Start again */
                update_tof_status(TOF_STATUS_START);
        } else {
                printf("results received with status %d\r\n", ctx.tof_status);
        }
}

static void handle_tof_start()
{
        tof_status_pdu_t pdu;

        start_tick = OS_GET_TICK_COUNT();

        /* reset error code */
        ctx.tof_err_code = TOF_NO_ERROR;

        /* set next ble event counter for cw measurement */
        cw_evt_counter =  cmac_info_table_ptr->ble_conn_evt_counter[ctx.conn_idx] + 1;

        /* prepare status pdu */
        pdu.event_counter = cw_evt_counter;
        pdu.err_code = TOF_NO_ERROR;
        pdu.status = TOF_STATUS_START;

        ble_gattc_write_no_resp(ctx.conn_idx, ctx.tof_status_val_h, 0, sizeof(tof_status_pdu_t),
                                                                                (uint8_t *) &pdu);

        //printf("next start %d\r\n", cw_evt_counter);
}

static void handle_tof_sync()
{

}

static void handle_tof_calc()
{
        calc_phases();
        send_results(evt_counter, &i_result);
}

static void handle_tof_stop()
{
        if (ctx.tof_err_code == TOF_NO_ERROR) {
                printf("Measuring took  %lu ms\r\n", OS_TICKS_2_MS(OS_GET_TICK_COUNT() - start_tick));
        } else {
                printf("Measuring took  %lu ms (error %d)\r\n", OS_TICKS_2_MS(OS_GET_TICK_COUNT() - start_tick)
                                                                                                , ctx.tof_err_code);
        }
        start_tick = 0;

#if CLI_MODE
        ble_error_t ret;
        /* check if a stop command was received from cli */
        if (stop_cmd) {
                stop_cmd = false;
                ble_tof_sync_stop();
                ble_tof_cw_stop();
                ret = ble_gap_disconnect(ctx.conn_idx, BLE_HCI_ERROR_REMOTE_USER_TERM_CON);
                printf("Disconnecting %d\r\n", ret);
        }
#endif
}

static void update_tof_status(tof_status_t status)
{
        bool invalid_transition = false;

        dbg_printf("ToF Status: %d\r\n", status);

        switch (status) {
        case TOF_STATUS_START:

                if (ctx.tof_status == TOF_STATUS_STOP) {
                        handle_tof_start();

                } else {
                        invalid_transition = true;
                }
                break;
        case TOF_STATUS_SYNC:
               /* received sync notification */
                if (ctx.tof_status == TOF_STATUS_START) {
                        handle_tof_sync();

                } else {
                        invalid_transition = true;
                }
                break;
        case TOF_STATUS_CALC:
                if (ctx.tof_status == TOF_STATUS_SYNC) {
                        handle_tof_calc();
                } else {
                        invalid_transition = true;
                }
                break;
        case TOF_STATUS_STOP:
                handle_tof_stop();
                break;
        default:
                invalid_transition = true;
                break;
        }

        if (!invalid_transition) {
                ctx.tof_status = status;
        } else {
                printf("Invalid status transition from %d to %d\r\n", ctx.tof_status, status);
        }
}

static void handle_tof_sync_end_notification(uint16_t evt_counter)
{
        switch (ctx.tof_status ) {
        case TOF_STATUS_START:
                if (evt_counter == cw_evt_counter) {
                        ble_tof_cw_start();
                        update_tof_status(TOF_STATUS_SYNC);
                } else if (evt_counter > cw_evt_counter) {
                        printf("instant passed evt %d cw %d\r\n", evt_counter, cw_evt_counter);
                        ctx.tof_err_code = TOF_ERROR_INSTANT_PASSED;
                        update_tof_status(TOF_STATUS_STOP);
                        update_tof_status(TOF_STATUS_START);
                }
                break;
        case TOF_STATUS_SYNC:
                ble_tof_cw_stop();

#ifdef MATLAB_MODE
                /* notify matalb that data are ready */
                tof_interface_data_exchange(evt_counter);
#endif
                update_tof_status(TOF_STATUS_CALC);

                /* set timeout for responder results */
                to_evt_counter = evt_counter + TOF_EVT_MEAS_OFFSET;
                break;

        case TOF_STATUS_CALC:
                /* check if timeout expired */
                if (evt_counter >= to_evt_counter) {
                        printf("results timeout\r\n");
                        ctx.tof_err_code = TOF_ERROR_RESULTS_TO;
                        update_tof_status(TOF_STATUS_STOP);
                        update_tof_status(TOF_STATUS_START);
                }
                break;
        default:
                printf("not handled status %d\r\n", ctx.tof_status);
                break;
        }
}

void update_bd_address(void)
{
        own_address_t addr;

#if defined(USE_RANDOM_BD_ADDRESS)
        ble_gap_address_get(&addr);
        if (addr.addr[0] == 0x01 &&
            addr.addr[1] == 0x00 &&
            addr.addr[2] == 0x80 &&
            addr.addr[3] == 0xCA &&
            addr.addr[4] == 0xEA &&
            addr.addr[5] == 0x80)
        {
                uint8_t offset = 0;
                nvms_t nvms;
                /*
                 * in case the current address is equal to the default one, we store a
                 * random address in 0x70000.
                 */
                printf("generating random BD address.\r\n");
                sys_trng_get_bytes(addr.addr,sizeof(addr.addr));
                /* the two MSBs of a random static address have to be 1 */
                addr.addr[5] |= 0xC0;
                addr.addr_type = PRIVATE_STATIC_ADDRESS;
                ble_gap_address_set(&addr, 0x7530); // 5 min

                nvms = ad_nvms_open(NVMS_PARAM_PART);
                if (!nvms) {
                        printf("\r\nCannot open NVMS_PARAM_PART, storing device address failed.\r\n");
                        return;
                }

                /* write random address to NVM and set it to valid */
                ad_nvms_write(nvms, offset, addr.addr, sizeof(addr.addr));
                ad_nvms_write(nvms, 6, &offset, sizeof(offset));
        }
#endif

        ble_gap_address_get(&addr);
        /* sdk assumes that a stored address is public so we need to
         * check for random static address and set the correct type.
         */
        if ((addr.addr[BD_ADDR_LEN-1] & 0xC0) == 0xC0) {
                addr.addr_type = PRIVATE_STATIC_ADDRESS;
                ble_gap_address_set(&addr, 0x0);
        }

        printf("Device address: ");
        for(int i= sizeof(addr.addr) - 1;i >=0;i--) {
             printf("%02X",addr.addr[i]);
             if(i != 0){
                     printf(":");
             } else {
                     printf("\r\n");
             }
        }
        printf("Device address type: %d\r\n", addr.addr_type);
        fflush(stdout);
}

#if CLI_MODE

static void execute_cmd(cli_cmd_t cmd, uint8_t *bd_address);

static void con_tmo_cb(OS_TIMER pxTime)
{
        OS_TASK_NOTIFY(ble_central_task_handle, CONNECT_TO_NOTIF, OS_NOTIFY_SET_BITS);
}

#endif

void ble_central_task(void *params)
{
        int8_t wdog_id;

        printf("Ble central tof task set_nb\r\n");
        ble_central_task_handle = OS_GET_CURRENT_TASK();

        /* register ble_central task to be monitored by watchdog */
        wdog_id = sys_watchdog_register(false);

        queue_init(&services);
        queue_init(&characteristics);

        /* configure_device_as_a_BLE_central */
        ble_gap_role_set(GAP_CENTRAL_ROLE);
        ble_register_app();

        update_bd_address();

        /* keep ble active */
        //ad_ble_stay_active(true);

        ble_tof_sync_init(TOF_ROLE_INITIATOR, ble_central_task_handle);

        /* Set maximum allowed MTU to increase results throughput.
         * Max data packet payload is 251 bytes.
         */
        ble_gap_mtu_size_set(512);

        ctx.tof_status = TOF_STATUS_STOP;
        ctx.conn_idx = BLE_CONN_IDX_INVALID;

        /* set set_number to find node to scan for */
        ctx.conf_set_number = *(uint8_t*)params;

        /* set service UUID to scan for */
        ble_uuid_from_string(UUID_TOF_SERVICE, &ctx.peripheral_service_uuid);

#if !CLI_MODE
        /* start scanning for another_device with tof service */
        ble_gap_scan_start(GAP_SCAN_ACTIVE, GAP_SCAN_GEN_DISC_MODE,
                                         BLE_SCAN_INTERVAL,
                                         BLE_SCAN_WINDOW,
                                         false, false);
#else
        /* initialize cli task */
        tof_cli_init(ble_central_task_handle, CLI_INPUT_NOTIF);

        /* Create timer which will be used to timeout connection attempts which take too long */
        con_tmo_timer = OS_TIMER_CREATE("tmo", OS_MS_2_TICKS(BLE_CONNECTION_TO_MS), OS_TIMER_FAIL,
                                                                                NULL, con_tmo_cb);
#endif
        for (;;) {
                OS_BASE_TYPE ret;
                uint32_t notif;

                /* notify watchdog on each loop */
                sys_watchdog_notify(wdog_id);

                /* suspend watchdog while blocking on OS_TASK_NOTIFY_WAIT() */
                sys_watchdog_suspend(wdog_id);

                /*
                 * Wait on any of the notification bits, then clear them all
                 */
                ret = OS_TASK_NOTIFY_WAIT(0, OS_TASK_NOTIFY_ALL_BITS, &notif, OS_TASK_NOTIFY_FOREVER);
                /* Blocks forever waiting for task notification. The return value must be OS_OK */
                OS_ASSERT(ret == OS_OK);

                /* resume watchdog */
                sys_watchdog_notify_and_resume(wdog_id);

                /* notified from BLE manager, can get event */
                if (notif & BLE_APP_NOTIFY_MASK) {
                        ble_evt_hdr_t *hdr;

                        hdr = ble_get_event(false);
                        if (!hdr) {
                                goto no_event;
                        }

                        if (!ble_service_handle_event(hdr)) {
                                switch (hdr->evt_code) {
                                case BLE_EVT_GAP_ADV_REPORT:
                                        handle_evt_gap_adv_report((ble_evt_gap_adv_report_t *) hdr);
                                        break;
                                case BLE_EVT_GAP_SCAN_COMPLETED:
                                        handle_evt_gap_scan_completed((ble_evt_gap_scan_completed_t *) hdr);
                                        break;
                                case BLE_EVT_GAP_CONNECTION_COMPLETED:
                                        handle_evt_gap_connection_completed((ble_evt_gap_connection_completed_t *) hdr);
                                        break;
                                case BLE_EVT_GAP_CONNECTED:
                                        handle_evt_gap_connected((ble_evt_gap_connected_t *) hdr);
                                        break;
                                case BLE_EVT_GAP_DISCONNECTED:
                                        handle_evt_gap_disconnected((ble_evt_gap_disconnected_t *) hdr);
                                        break;
                                case BLE_EVT_GAP_CONN_PARAM_UPDATED:
                                        handle_evt_gap_conn_param_updated((ble_evt_gap_conn_param_updated_t *) hdr);
                                        break;
                                case BLE_EVT_GATTC_MTU_CHANGED:
                                        handle_evt_gattc_mtu_changed((ble_evt_gattc_mtu_changed_t *) hdr);
                                        break;
                                case BLE_EVT_GATTC_DISCOVER_SVC:
                                        handle_evt_gattc_discover_svc((ble_evt_gattc_discover_svc_t *) hdr);
                                        break;
                                case BLE_EVT_GATTC_DISCOVER_CHAR:
                                        handle_evt_gattc_discover_char((ble_evt_gattc_discover_char_t *) hdr);
                                        break;
                                case BLE_EVT_GATTC_DISCOVER_DESC:
                                        handle_evt_gattc_discover_desc((ble_evt_gattc_discover_desc_t *) hdr);
                                        break;
                                case BLE_EVT_GATTC_DISCOVER_COMPLETED:
                                        handle_evt_gattc_discover_completed((ble_evt_gattc_discover_completed_t *) hdr);
                                        break;

                                case BLE_EVT_GATTC_READ_COMPLETED:
                                        handle_evt_gattc_read_completed((ble_evt_gattc_read_completed_t *) hdr);
                                        break;
                                case BLE_EVT_GATTC_WRITE_COMPLETED:
                                        handle_evt_gattc_write_completed((ble_evt_gattc_write_completed_t *) hdr);
                                        break;
                                case BLE_EVT_GATTC_NOTIFICATION:
                                        handle_evt_gattc_notification((ble_evt_gattc_notification_t *) hdr);
                                        break;
                                default:
                                        ble_handle_event_default(hdr);
                                        break;
                                }
                        }

                        OS_FREE(hdr);

no_event:
                        // notify again if there are more events to process in queue
                        if (ble_has_event()) {
                                OS_TASK_NOTIFY(OS_GET_CURRENT_TASK(), BLE_APP_NOTIFY_MASK, eSetBits);
                        }
                }

                if (notif & DISCOVER_NOTIF) {
                        ble_gattc_discover_svc(0, NULL);
                }

                if (notif & CONNECT_NOTIF) {
                        printf("Connecting...\r\n");
                        ble_gap_connect(&ctx.peripheral_bd_address, &cp);
                }

                if (notif & SCAN_START_NOTIF) {
                        memset(&ctx.peripheral_bd_address, 0, sizeof(bd_address_t));
                        ble_gap_scan_start(GAP_SCAN_ACTIVE, GAP_SCAN_GEN_DISC_MODE,
                                                                BLE_SCAN_INTERVAL,
                                                                BLE_SCAN_WINDOW,
                                                                false, false);
                }

                if (notif & TOF_SYNC_END_NOTIF) {
                        if (ctx.conn_idx != BLE_CONN_IDX_INVALID) {
                                /* update event counter */
                                evt_counter =  cmac_info_table_ptr->ble_conn_evt_counter[ctx.conn_idx];

                                handle_tof_sync_end_notification(evt_counter);

                                //printf("event counter %d\r\n", evt_counter);
                        }
                }
#if CLI_MODE
                if (notif & CLI_INPUT_NOTIF) {
                        cli_cmd_t cmd;
                        uint8_t bd_address[BD_ADDR_LEN];

                        /* Get input string, assuming there is no input until the
                         * string is parsed to a command and executed.
                         */
                        char *clistr = tof_cli_get_clistr();

                        /* echo command */
                        printf("%s\r\n", clistr);

                        /* parse command */
                        if (parseline(clistr, &cmd, bd_address)) {

                                /* validate and execute command */
                                execute_cmd(cmd, bd_address);
                        }
                        printf ("\r\n> ");

                }
                if (notif & CONNECT_TO_NOTIF) {
                        /* cancel connection attempt */
                        printf("Connection timeout - cancelling connection attempt\r\n");
                        ble_gap_connect_cancel();
                }
#endif
        }
}

#if CLI_MODE

static void execute_cmd(cli_cmd_t cmd, uint8_t *bd_address)
{
        ble_error_t ret;

        switch (cmd){
        case CLI_CMD_START:
                OS_TIMER_START(con_tmo_timer, OS_TIMER_FOREVER);
                /* Check for random static address, two most significant bits
                 * shall be equal to 1.
                 */
                if ((bd_address[BD_ADDR_LEN-1] & 0xC0) == 0xC0) {
                        ctx.peripheral_bd_address.addr_type = PRIVATE_ADDRESS;
                } else {
                        ctx.peripheral_bd_address.addr_type = PUBLIC_ADDRESS;
                }
                memcpy(ctx.peripheral_bd_address.addr, bd_address, BD_ADDR_LEN);
                ret = ble_gap_connect(&ctx.peripheral_bd_address, &cp);
                printf("Connecting %d\r\n", ret);
                break;
        case CLI_CMD_STOP:
                if (ctx.conn_idx != BLE_CONN_IDX_INVALID) {
                        /* only a flag is set at this point, the disconnection will be
                         * initiated at the end of the measurement cycle.
                         */
                        stop_cmd = true;
                } else {
                        printf("Not connected\r\n");
                }
                break;
        case CLI_CMD_HELP:
                printf("usage: start <address> | stop | help\r\n");
                printf("address format:  XX:XX:XX:XX:XX:XX\r\n");
                break;
        default:
                printf("Invalid command\r\n");
                break;
        }
}


#endif /* CLI_MODE */
