/**
 ****************************************************************************************
 *
 * @file cw_distance.c
 *
 * @brief Calculate distance based on phase data, derived from CwDistance.m
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include "cw_distance.h"
#include "s_linreg.h"
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <math.h>
#include <arm_math.h>

static uint16_t parm_update(void);
static void phase_mix_down(phase_mag *pm_data, float const f_if, int const s_rate_m, int const num_points);
static void calc_phase_per_atom(phase_mag *pm_data, int s_rate_m, int n_samp, float *phase_out, float *f_offs_out);
static void get_atom_idx(int atom_nr, int s_rate_m, int *idx_start, int *n_samp);
static void comp_dc_offset(int16_t *iq_data, int s_rate_m);
static float wrap_to_two_pi(float phase);
static void unwrap_phase(float *phases, unsigned int n_val, unsigned int n_ele);
static void iq_to_magnitude(float *iq, uint16_t *magnitude);

cw_distance_parm_t cwd_parm;

uint16_t cwd_init(uint32_t *data_buffer, bool is_initiator)
{
    /* sampling rate specific constants */
    cwd_parm.s_rate_m       = CWD_S_RATE_M_DEFAULT;
    cwd_parm.n_down_samp    = CWD_N_DOWN_SAMP_DEFAULT;

    /* frequencies */
    cwd_parm.f_if_init      = CWD_F_IF_INIT_DEFAULT;
    cwd_parm.f_step         = CWD_F_STEP_DEFAULT;

    cwd_parm.is_initiator   = is_initiator;

    /* atom specific constants/parameters */
    cwd_parm.t_atom_rx_us   = CWD_T_ATOM_RX_US_DEFAULT;
    cwd_parm.t_atom_used_us = CWD_T_ATOM_USED_US_DEFAULT;
    cwd_parm.t_atom_offs_us = CWD_T_ATOM_OFFS_US_DEFAULT;

    cwd_parm.data_buffer    = data_buffer;
    cwd_parm.comp_dc_offset = CWD_COMP_DC_OFFSET;

    /* set number of atoms and return num_points*/
    return cwd_set_n_atom(CWD_N_ATOM_DEFAULT);
}

uint16_t cwd_set_n_atom(uint8_t n_atom)
{
    if (n_atom <= CWD_N_ATOM_MAX)
    {
        cwd_parm.n_atom = n_atom;
    }
    /* update and return num_points */
    return parm_update();
}

float cwd_phase_based_distance(int16_t *init_iq, int16_t *refl_iq)
{

    float init_phase[CWD_N_ATOM_MAX];
    float refl_phase[CWD_N_ATOM_MAX];
    float init_f_offs, refl_f_offs;
    float distance;
    uint8_t dqf;

    /* running on initiator */
    init_f_offs = cwd_calc_phase_IQ(init_iq, cwd_parm.f_if_init, init_phase, NULL);

    /* running on responder */
    refl_f_offs = cwd_calc_phase_IQ(refl_iq, -cwd_parm.f_if_init, refl_phase, NULL);

    distance = cwd_calc_distance(init_phase, refl_phase);
    dqf = cwd_calc_dqf(roundf(init_f_offs), roundf(refl_f_offs));

    return distance;
}

float cwd_calc_phase_IQ(int16_t *iq_data, float f_if, float *phi_atom, float32_t *iq_atom)
{
    float f_offs_atom[CWD_N_ATOM_MAX];
    float f_offs;
    phase_mag *pm_data = (phase_mag *)iq_data;
    int i;
    int num_points, s_rate_m;
    int idx_start, n_samp;
    int16_t *i_data = iq_data;
    int16_t *q_data = i_data+1;

    /* sample down by n_down_samp */
    num_points = cwd_parm.num_points / cwd_parm.n_down_samp;
    s_rate_m = cwd_parm.s_rate_m / cwd_parm.n_down_samp;

    if (cwd_parm.comp_dc_offset)
    {
        comp_dc_offset(iq_data, s_rate_m);
    }

    /* extract phase and magnitude data */
    for (i = 0; i < num_points; i++)
    {
        float32_t ii = (float32_t)*i_data;
        float32_t qq = (float32_t)*q_data;
        pm_data[i].phase = atan2f(qq, ii);
        arm_sqrt_f32(qq * qq + ii * ii, &pm_data[i].mag);

        /* actual downsampling happens by skipping every n_down_samp-th input element */
        i_data += sizeof(float)/sizeof(int16_t) * cwd_parm.n_down_samp;
        q_data += sizeof(float)/sizeof(int16_t) * cwd_parm.n_down_samp;
    }

    /* mix down by f_if */
    phase_mix_down(pm_data, f_if, s_rate_m, num_points);

    float f_offs_sum = 0;
    /* calculate phase and f_offs per atom */
    for (i = 0; i < cwd_parm.n_atom; i++)
    {
        get_atom_idx(i, s_rate_m, &idx_start, &n_samp);

        /* analyze phase of this atom */
        float phase_atom;
        calc_phase_per_atom(&pm_data[idx_start], s_rate_m, n_samp, &phase_atom, &f_offs_atom[i]);
        if (phi_atom)
        {
            /* Phase data wanted */
            *phi_atom++ = phase_atom;
        }
        f_offs_sum += f_offs_atom[i];

        if (iq_atom)
        {
            /* IQ data wanted: calculate averaged mag for this atom */
            float mag_atom = 0.0;
            float i_val, q_val;
            for (int j = 0; j < n_samp; j++)
                mag_atom += pm_data[idx_start + j].mag;
            mag_atom /= (float)n_samp;
            /* now, turn into I/Q pair */
            cwd_polar_to_iq(phase_atom, mag_atom, &i_val, &q_val);
            *iq_atom++ = i_val;
            *iq_atom++ = q_val;
        }
    }

    f_offs = f_offs_sum / cwd_parm.n_atom;
    return f_offs;
}

float cwd_calc_phase_data(float *phase_atom)
{
    /* responder has its PLL 1 MHz above initiator -> receives initiator signal at -1 MHz */
    int sign = cwd_parm.is_initiator? 1: -1;
    return cwd_calc_phase_IQ((int16_t *)cwd_parm.data_buffer, sign * cwd_parm.f_if_init, phase_atom, NULL);
}

float cwd_calc_phase_mag_data(float *phase_atom, uint16_t *mag_atom)
{
    /* responder has its PLL 1 MHz above initiator -> receives initiator signal at -1 MHz */
    int sign = cwd_parm.is_initiator? 1: -1;
    float iq_data[2 * cwd_parm.n_atom];
    float f_offs;

    f_offs = cwd_calc_phase_IQ((int16_t *)cwd_parm.data_buffer, sign * cwd_parm.f_if_init, phase_atom, iq_data);
    iq_to_magnitude(iq_data, mag_atom);
    return f_offs;
}

void cwd_polar_to_iq(float phase, float mag, float *i_val, float *q_val)
{
    *i_val = arm_cos_f32(phase) * mag; // I [real part]
    *q_val = -arm_sin_f32(phase) * mag; // Q [imaginary part]
}

uint8_t cwd_calc_dqf(int16_t fo_i, int16_t fo_r)
{
    uint8_t dqf;
    uint8_t abs_diff = abs(fo_i + fo_r);
    if (abs_diff < CWD_DQF_F_OFFS_TH)
    {
        dqf = 100;
    }
    else
    {
        dqf = 0;
    }
    return dqf;
}

float cwd_calc_distance(float *init_phase_atom, float *refl_phase_atom)
{
    float d_phi[CWD_N_ATOM_MAX];
    float *dd_phi = d_phi; /* reuse d_phi, or: float dd_phi[CWD_N_ATOM_MAX-1];*/
    float dd_phi_mean;
    int i;

    for (i = 0; i < cwd_parm.n_atom; i++)
    {
        /* phase "difference" between initiator and responder */
        d_phi[i] = init_phase_atom[i] + refl_phase_atom[i];

        if (i != 0)
        {
            /* phase difference between neighboring frequencies */
            dd_phi[i-1] = d_phi[i] - d_phi[i-1];
        }
    }

    unwrap_phase(dd_phi, cwd_parm.n_atom - 1, 1);

    /* average dd_phi */
    dd_phi_mean = 0;
    for (i = 0; i < cwd_parm.n_atom - 1; i++)
    {
        dd_phi_mean += dd_phi[i];
    }
    dd_phi_mean = dd_phi_mean / (cwd_parm.n_atom - 1);

    dd_phi_mean = wrap_to_two_pi(dd_phi_mean - CWD_PHASE_OFFSET);

    /* distance */
    return (dd_phi_mean * CWD_C_AIR/(4 * M_PI * cwd_parm.f_step * 1e6));
}

/* --- internal, static functions --- */
static uint16_t parm_update(void)
{
    /* verify and update parameters that are based on some settings */

    /* verify n_down_samp */
    if (cwd_parm.n_down_samp < CWD_N_DOWN_SAMP_MIN)
    {
        cwd_parm.n_down_samp = CWD_N_DOWN_SAMP_MIN;
    }

    uint16_t t_buffer_us = cwd_parm.n_atom * cwd_parm.t_atom_rx_us;
    /* number of measurement samples */
    cwd_parm.num_points = t_buffer_us * cwd_parm.s_rate_m;

    return cwd_parm.num_points;
}

static void get_atom_idx(int atom_nr, int s_rate_m, int *idx_start, int *n_samp)
{
    /* calculate indexes for this atom inside acquisition data */
    int t_start_us = cwd_parm.t_atom_offs_us + atom_nr * cwd_parm.t_atom_rx_us;
    *idx_start  = t_start_us * s_rate_m;
    int t_end_us   = t_start_us + cwd_parm.t_atom_used_us;
    int idx_end    = t_end_us * s_rate_m;
#if CWD_N_SAMP_PER_ATOM == 0
    *n_samp = idx_end - *idx_start;
#else
    *n_samp = CWD_N_SAMP_PER_ATOM;
#endif
}

static void comp_dc_offset(int16_t *iq_data, int s_rate_m)
{
    int idx_start, n_samp;
    for (int atom = 0; atom < cwd_parm.n_atom; atom++)
    {
        get_atom_idx(atom, s_rate_m, &idx_start, &n_samp);

        /* ADC data is not yet sampled down, so adjust indexes accordingly */
        idx_start *= cwd_parm.n_down_samp;
        n_samp *= cwd_parm.n_down_samp;

        int sum_i = 0;
        int sum_q = 0;
        int values = 0;
        int dc_i, dc_q;

        /* calculate DC offset */
        for (int samp = idx_start; samp < idx_start + n_samp; samp += cwd_parm.n_down_samp)
        {
            sum_i += iq_data[samp*2];
            sum_q += iq_data[samp*2 + 1];
            values++;
        }

        /* calculations are in integer domain */
        dc_i = (int)roundf((float)sum_i / values);
        dc_q = (int)roundf((float)sum_q / values);

        /* subtract DC offset */
        for (int samp = idx_start; samp < idx_start + n_samp; samp += cwd_parm.n_down_samp)
        {
            iq_data[samp*2]     -= dc_i;
            iq_data[samp*2 + 1] -= dc_q;
        }
    }
}

static void phase_mix_down(phase_mag *pm_data, const float f_if, const int s_rate_m, int num_points)
{
    /* mix down by f_if --> subtract ramp
     *
     *  phase ...... signal phase in radians
     *  f_if ....... IF frequency in MHz
     *  s_rate_m ... sampling rate in MSamp
     *  num_points . number of samples
     */
    int i;

    const float factor = 2 * M_PI * f_if / s_rate_m;

    for (i = 0; i < num_points; i++)
    {
        /* subtract ramp from phase data and wrap to [0, 2*PI) to keep values
           small and thus accuracy high */

        /* opt 0: original code ==> 219.5ms @ (32MHz, 20 Atoms) */
        // phase[i] = wrap_to_two_pi(phase[i] - 2 * M_PI * f_if * i / s_rate_m);

        /* opt 1: combine constant values in a  factor ==> 164.2ms @ (32MHz, 20 Atoms) */
        // phase[i] = wrap_to_two_pi(phase[i] - i*factor);

        /* opt 2: remove wrap_to_two_pi ==> 2.113ms @ (32MHz, 20 Atoms)
         */
        pm_data[i].phase -= i * factor;
    }
}

static void calc_phase_per_atom(phase_mag *pm_data, int s_rate_m, int n_samp, float *phase_out, float *f_offs_out)
{
    /*
     * calculate phase and frequency offset for one specific atom
     *  input data:
     *      phase ..... pointer to phase data of this atom in radians
     *      s_rate_m .. sampling rate of phase data in MSamps
     *      n_samp .... number of phase samples inside this atom
     *  output data:
     *      phase_out . averaged phase data of this atom in radians
     *      f_offs_out  averaged frequency offset data of this atom in kHz
     */
    float m, b;
    float x[n_samp];
    int i;

    /* opt 0: original code ==> 62.29us @ (32MHz, 384 samples) */
    for (i = 0; i < n_samp; i++)
    {
        x[i] = i;
    }

    /* opt 0: original code ==> 7.87ms @ (32MHz, 384 samples) */
    unwrap_phase((float *)pm_data, n_samp, 2);

    /* opt 0: original code ==> 87us @ (32MHz, 384 samples) */
    s_linreg(n_samp, x, (float *)pm_data, &m, &b, 2);

    *f_offs_out = m * s_rate_m / (2 * M_PI) * 1e3;   /* in kHz */
    *phase_out = b;
}

static float wrap_to_two_pi(float phase)
{
    /* wrap phase values to range 0 ... 2 pi, basically modulo implementation */

    /* 178ms (@96 MHz, 40 atoms) */
    //return phase - 2 * M_PI * floorf(phase / (2 * M_PI));

    /* 172ms (@96 MHz, 40 atoms) */
    const float phase_x = phase / (2 * M_PI);
    const float phase_y = floorf(phase_x);
    const float phase_z = phase_x - phase_y;
    return phase_z * 2 * M_PI;
}


/*
 * parameters:
 *     phases .... pointer to phase array
 *     n_val ..... number of values inside phase array
 *     n_ele ..... number of floats per 2 subsequent phase values (e.g.
 *                 has to be 1, if phases are inside a float array,
 *                 has to be 2, if phases are interleaved with magnitudes)
 * */

static void unwrap_phase(float *phases, unsigned int n_val, unsigned int n_ele)
{
    /*
     * The basic idea of this implementation is to detect wraps by phase jumps
     * that are larger than pi. Each time a wrap occurs, we keep track of the
     * number (and direction) of wraps that occurred so far. We have to add /
     * subtract this number of wraps to all following phase values to unwrap
     * the entire signal.
     */

    int i;
    int current_offset = 0;     /* in times 2 * M_PI */

    phases[0] = wrap_to_two_pi(phases[0]);

    for (i = 1; i < n_val; i++)
    {
        /* ensure absolute phase jumps are below 2 * PI before unwrapping */
        phases[i * n_ele] = wrap_to_two_pi(phases[i * n_ele]);

        float phase_diff = phases[i * n_ele] + current_offset * 2 * M_PI - phases[(i-1) * n_ele];
        if ( phase_diff > M_PI)
        {
            current_offset -= 1;
        }
        else if (phase_diff < -M_PI)
        {
            current_offset += 1;
        }
        phases[i * n_ele] = phases[i * n_ele] + current_offset * 2 * M_PI;
    }
}

static void iq_to_magnitude(float *iq, uint16_t *magnitude)
{
    float qq, ii;

    for (int i = 0; i < cwd_parm.n_atom; i++)
    {
        ii = iq[i * 2];
        qq = iq[i * 2 + 1];
        float mag;
        arm_sqrt_f32(qq * qq + ii * ii, &mag);
        magnitude[i] = (uint16_t)roundf(mag);
    }
}
