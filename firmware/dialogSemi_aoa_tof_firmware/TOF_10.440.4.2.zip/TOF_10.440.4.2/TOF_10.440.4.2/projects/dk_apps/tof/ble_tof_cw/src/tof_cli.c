/**
 ****************************************************************************************
 *
 * @file tof_cli.c
 *
 * @brief ToF code related to cli
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "osal.h"
#include "co_bt.h"
#include "tof_cli.h"

static void cli_task(void *params);

static OS_TASK cli_notif_task_handle;
static uint32_t cli_notif;

void readline(char *buf, size_t size)
{
        int c;

        do {
                c = getchar();
                *buf = c;
                buf++;
                size--;
        } while (c != '\n' && c != '\r' && size > 1); // wait for CR/LF or reserve 1 char for \0

        /* make sure it's null-terminated */
        *buf = '\0';
}

bool parseline(char *cli_input, cli_cmd_t *cmd, uint8_t *bd_address)
{
        char *token = strtok(cli_input, " \r");

        *cmd = CLI_CMD_INVALID;

        if (token == NULL) {
                printf("No input\r\n");
                return false;
        }

        if (strcmp(token, "start") == 0) {
                *cmd = CLI_CMD_START;

                token = strtok(NULL, " \r");
                if (token == NULL) {
                        printf("No address found\r\n");
                        return false;
                }

                int i = 0;
                token = strtok(token, ":");
                while (token) {

                        if (strlen(token) != 2) {
                                printf("Invalid address byte %s at index %i\r\n",token, i);
                                return false;
                        }
                        /* Reverse bd address */
                        bd_address[BD_ADDR_LEN - 1 - i] = strtol(token, NULL, 16);

                        if (bd_address[BD_ADDR_LEN -1 - i] == 0 && strcmp(token, "00") != 0) {
                                printf("Invalid address byte %s at index %i\r\n",token, i);
                                return false;
                        }
                        //printf("%i byte %x\r\n", i, bd_address[BD_ADDR_LEN - 1 - i]);
                        i++;
                        token = strtok(NULL, ":");

                };

                if (i != 6) {
                        printf("Invalid number of address bytes: %d\r\n", i);
                        return false;
                }

        } else if (strcmp(token, "stop") == 0) {
                *cmd = CLI_CMD_STOP;
        } else if (strcmp(token, "help") == 0) {
                *cmd = CLI_CMD_HELP;
        } else {
                printf("Invalid command %s\r\n", token);
                *cmd = CLI_CMD_INVALID;
        }

        return *cmd != CLI_CMD_INVALID;

}

void tof_cli_init(OS_TASK notif_task_handle, uint32_t notif)
{
        OS_TASK handle;

        /* Start the cli task. */
        OS_TASK_CREATE("cli",                   /* The text name assigned to the task, for
                                                                 debug only; not used by the kernel. */
                cli_task,                       /* The function that implements the task. */
                NULL,                           /* The parameter passed to the task. */
                256 * OS_STACK_WORD_SIZE,       /* The number of bytes to allocate to the
                                                                           stack of the task. */
                OS_TASK_PRIORITY_NORMAL,        /* The priority assigned to the task. */
                handle);                        /* The task handle. */
        OS_ASSERT(handle);

        cli_notif_task_handle = notif_task_handle;
        cli_notif = notif;
}

static char clistr[64];

char *tof_cli_get_clistr()
{
      return clistr;
}

static void cli_task(void *params)
{
        char *token;

        printf("Multi mode cli\r\n");
        printf ("\r\n> ");

        for (;;) {
                readline (clistr, sizeof(clistr));
                OS_TASK_NOTIFY(cli_notif_task_handle, cli_notif, OS_NOTIFY_SET_BITS);
        }
}
