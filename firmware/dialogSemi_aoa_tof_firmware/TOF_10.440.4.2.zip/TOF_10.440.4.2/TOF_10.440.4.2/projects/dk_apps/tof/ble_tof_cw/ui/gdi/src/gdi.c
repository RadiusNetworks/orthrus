/**
 * \addtogroup UI
 * \{
 * \addtogroup GDI
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file gdi.c
 *
 * @brief Basic graphic functions implementation
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "gdi.h"
#include "osal.h"
#include "platform_devices.h"
#include "ad_lcdc.h"
#include "math_2d.h"
#include "fonts.h"

#if dg_configLCDC_ADAPTER
/**
 * Macros that define various parameters of the GDI
 */
#define GDI_SWIPE_STEPS                         (16)
#define GDI_SINGLE_FB_NUM                       (1)
#define GDI_DOUBLE_FB_NUM                       (0)

#define GDI_FRAME_BUFFER_ADDR                   (frame_buffer)
#define CEILING_FUNC(quotient, divisor)         (((quotient) + ((divisor) - 1)) / (divisor))

typedef struct {
        OS_EVENT event;
}frame_update_cb_data_t;

PRIVILEGED_DATA static gdi_t *gdi;

PRIVILEGED_DATA static frame_update_cb_data_t frame_update_cb_data;

static void frame_update_cb(void *cb_data)
{
        frame_update_cb_data_t *data = (frame_update_cb_data_t *)cb_data;
        OS_EVENT_SIGNAL_FROM_ISR(data->event);
}

static uint8_t frame_buffer[GDI_DISP_RESX * GDI_DISP_RESY * GDI_COLOR_BYTES
        * (GDI_SINGLE_FB_NUM + (2 * GDI_DOUBLE_FB_NUM))];

/**
 * \brief LCD device definitions
 */
#if dg_configUSE_LPM012M134B
#define LCDC_DEVICE                             (LPM012M134B)
#define HW_LCDC_FIFO_PREFETCH_LVL               (HW_LCDC_FIFO_PREFETCH_LVL_108_BYTES)

static const uint8_t screen_init_cmds[] = {
        LCDC_EXT_CLK_SET(true),
};

static const uint8_t screen_power_on_cmds[] = {
};

static const uint8_t screen_enable_cmds[] = {
        /* Enable/disable of screen is not supported with the specific HW configuration */
        LCDC_EXT_CLK_SET(true),
};

static const uint8_t screen_disable_cmds[] = {
        /* Enable/disable of screen is not supported with the specific HW configuration */
        LCDC_EXT_CLK_SET(false),
};

static const uint8_t screen_power_off_cmds[] = {
};

static const uint8_t screen_clear_cmds[] = {
        /* Screen does not have a special command for clearing */
};
#elif dg_configUSE_LPM013M091A
#define LCDC_DEVICE                             (LPM013M091A_DATA)
#define HW_LCDC_FIFO_PREFETCH_LVL               (HW_LCDC_FIFO_PREFETCH_LVL_108_BYTES)

static const uint8_t screen_init_cmds[] = {
        /* Power on */
        LCDC_GPIO_SET_INACTIVE(LPM013M091A_RST_PORT, LPM013M091A_RST_PIN),
        LCDC_DELAY_US(10),
        LCDC_GPIO_SET_ACTIVE(LPM013M091A_RST_PORT, LPM013M091A_RST_PIN),
        LCDC_DELAY_MS(120),
};

static const uint8_t screen_enable_cmds[] = {
        /* On to Analog Mode */
        LCDC_MIPI_SW_RST(),
        LCDC_DELAY_MS(10),
//        LCDC_MIPI_CMD(0xFB), LCDC_MIPI_DATA(0x01),      // Reload cancel
        LCDC_MIPI_CMD(0xB3), LCDC_MIPI_DATA(0x02),      //
        LCDC_MIPI_CMD(0xBB), LCDC_MIPI_DATA(0x10),      //
        LCDC_MIPI_CMD(0xF3), LCDC_MIPI_DATA(0x02),      // SPI GRAM access enable
        LCDC_MIPI_SET_MODE(0x06),
//        LCDC_MIPI_ENABLE(),
        LCDC_MIPI_CMD(HW_LCDC_MIPI_DCS_EXIT_SLEEP_MODE),
        LCDC_DELAY_MS(10),
        LCDC_MIPI_CMD(HW_LCDC_MIPI_DCS_SET_DISPLAY_ON),

        LCDC_MIPI_SET_POSITION(0, 0, GDI_DISP_RESX - 1, GDI_DISP_RESY - 1),

        /* Refresh frequency to 30Hz */
//        LCDC_MIPI_CMD(0xFF), LCDC_MIPI_DATA(0x24),
//        LCDC_MIPI_CMD(0xD8), LCDC_MIPI_DATA(0xC1),
//        LCDC_MIPI_CMD(0xD9), LCDC_MIPI_DATA(0x3E),
};

static const uint8_t screen_disable_cmds[] = {
};

static const uint8_t screen_clear_cmds[] = {
};
#elif dg_configUSE_PSP27801

#define LCDC_CONFIG                             (&psp27801_cfg)
#define HW_LCDC_FIFO_PREFETCH_LVL               (HW_LCDC_FIFO_PREFETCH_LVL_DISABLED)

static const uint8_t screen_init_cmds[] = {
        LCDC_GPIO_SET_INACTIVE(PSP27801_EN_PORT, PSP27801_EN_PIN),
        LCDC_DELAY_MS(1),
        LCDC_GPIO_SET_INACTIVE(PSP27801_RST_PORT, PSP27801_RST_PIN),
        LCDC_DELAY_US(10),
        LCDC_GPIO_SET_ACTIVE(PSP27801_RST_PORT, PSP27801_RST_PIN),
        LCDC_DELAY_US(10),
        LCDC_GPIO_SET_ACTIVE(PSP27801_EN_PORT, PSP27801_EN_PIN),

        LCDC_MIPI_CMD(0xfd), LCDC_MIPI_DATA(0x12),                                              /* Command Lock */
        LCDC_MIPI_CMD(0xfd), LCDC_MIPI_DATA(0xb1),                                              /* Command Lock */
        LCDC_MIPI_CMD(0xae),                                                                    /* Display Off */
        LCDC_MIPI_CMD(0xb3), LCDC_MIPI_DATA(0xf1),                                              /* Front Clock Div */
        LCDC_MIPI_CMD(0xca), LCDC_MIPI_DATA(0x5f),                                              /* Set Mux Ratio */
        LCDC_MIPI_CMD(0xa0), LCDC_MIPI_DATA(0x32),
        LCDC_MIPI_CMD(0x15), LCDC_MIPI_DATA(0x10), LCDC_MIPI_DATA(0x6f),                        /* Set Column Address */
        LCDC_MIPI_CMD(0x75), LCDC_MIPI_DATA(0x00), LCDC_MIPI_DATA(0x5f),                        /* Set Row Address */
        LCDC_MIPI_CMD(0xa1), LCDC_MIPI_DATA(0x80),                                              /* Set Display Start Line */
        LCDC_MIPI_CMD(0xa2), LCDC_MIPI_DATA(0x20),                                              /* Set Display Offset */
        LCDC_MIPI_CMD(0xb1), LCDC_MIPI_DATA(0x32),                                              /* Set Phase Length */
        LCDC_MIPI_CMD(0xbe), LCDC_MIPI_DATA(0x05),                                              /* Set VComH Voltage */
        LCDC_MIPI_CMD(0xa6),                                                                    /* Set Display Mode Reset */
        LCDC_MIPI_CMD(0xc1), LCDC_MIPI_DATA(0x8a), LCDC_MIPI_DATA(0x51), LCDC_MIPI_DATA(0x8A),  /* Set Contrast */
        LCDC_MIPI_CMD(0xc7), LCDC_MIPI_DATA(0xcf),                                              /* Set Master Contrast */
        LCDC_MIPI_CMD(0xb4), LCDC_MIPI_DATA(0xa0), LCDC_MIPI_DATA(0xb5), LCDC_MIPI_DATA(0x55),  /* Set Segment Low Voltage */
        LCDC_MIPI_CMD(0xb6), LCDC_MIPI_DATA(0x01),                                              /* Set Second Precharge Period */

        LCDC_MIPI_CMD(0xaf),                                                                    /* Set Sleep Mode Display On */
};

static const uint8_t screen_power_on_cmds[] = {
};

static const uint8_t screen_enable_cmds[] = {
        LCDC_MIPI_CMD(0xaf),                                                                    /* Set Sleep Mode Display On */
};

static const uint8_t screen_disable_cmds[] = {
        LCDC_MIPI_CMD(0xAE),                            // Display off
};

static const uint8_t screen_power_off_cmds[] = {
};

static const uint8_t screen_clear_cmds[] = {
};
#elif dg_configUSE_DT280QV10CT
#define LCDC_CONFIG                            (&dt280qv10ct_cfg)
#define HW_LCDC_FIFO_PREFETCH_LVL               (HW_LCDC_FIFO_PREFETCH_LVL_108_BYTES)

static const uint8_t screen_init_cmds[] = {
        /* Power on */
        LCDC_GPIO_SET_INACTIVE(DT280QV10CT_RST_PORT, DT280QV10CT_RST_PIN),
        LCDC_DELAY_MS(10),
        LCDC_GPIO_SET_ACTIVE(DT280QV10CT_RST_PORT, DT280QV10CT_RST_PIN),
        LCDC_DELAY_MS(120),

        LCDC_MIPI_SW_RST(),
        LCDC_DELAY_MS(100),

        LCDC_MIPI_CMD(0xC0), LCDC_MIPI_DATA(0x23),                              // POWERCONTROL1 - GVDD=3.8V
        LCDC_MIPI_CMD(0xC1), LCDC_MIPI_DATA(0x10),                              // POWERCONTROL2
        LCDC_MIPI_CMD(0xC5), LCDC_MIPI_DATA(0x2B), LCDC_MIPI_DATA(0x2B),        // VCOMCONTROL1 - VMH=3.775V - VML=-1.425V
        LCDC_MIPI_CMD(0xC7), LCDC_MIPI_DATA(0xC0),                              // VCOMCONTROL2 -
        LCDC_MIPI_SET_ADDR_MODE(0x48),

        LCDC_MIPI_SET_MODE(0x55),
        LCDC_MIPI_SET_TEAR_ON(0x00),
        LCDC_MIPI_CMD(0xB1), LCDC_MIPI_DATA(0x00), LCDC_MIPI_DATA(0x1F),        // FRAMECONTROL
        LCDC_MIPI_CMD(0xB5), LCDC_MIPI_DATA(0x5F), LCDC_MIPI_DATA(0x60), LCDC_MIPI_DATA(0x1F), LCDC_MIPI_DATA(0x1F),
};

static const uint8_t screen_power_on_cmds[] = {
        LCDC_MIPI_CMD(HW_LCDC_MIPI_DCS_EXIT_SLEEP_MODE),
        LCDC_DELAY_MS(120),
};

static const uint8_t screen_enable_cmds[] = {
        LCDC_MIPI_CMD(HW_LCDC_MIPI_DCS_SET_DISPLAY_ON),
        LCDC_DELAY_MS(80),
};

static const uint8_t screen_disable_cmds[] = {
        LCDC_MIPI_CMD(HW_LCDC_MIPI_DCS_SET_DISPLAY_OFF),
        LCDC_DELAY_MS(50),
};

static const uint8_t screen_power_off_cmds[] = {
        LCDC_MIPI_CMD(HW_LCDC_MIPI_DCS_ENTER_SLEEP_MODE),
        LCDC_DELAY_MS(120),
};

static const uint8_t screen_clear_cmds[] = {
};
#endif

static ad_lcdc_handle_t dev_open(void)
{
        ad_lcdc_handle_t dev = ad_lcdc_open(LCDC_CONFIG);
        return dev;
}

static void dev_close(ad_lcdc_handle_t dev)
{
        ad_lcdc_close(dev, false);
}

void gdi_buffer_enable(void)
{
        /* Do nothing */
}

void gdi_buffer_disable(void)
{
        /* Do nothing */
}

static void screen_setup(void)
{
#if dg_configUSE_LPM012M134B
        hw_gpio_set_active(LPM012M134B_PEN_PORT, LPM012M134B_PEN_PIN);
        hw_gpio_pad_latch_enable(LPM012M134B_PEN_PORT, LPM012M134B_PEN_PIN);
        hw_gpio_pad_latch_disable(LPM012M134B_PEN_PORT, LPM012M134B_PEN_PIN);

        hw_gpio_set_pin_function(LPM012M134B_FRP_PORT, LPM012M134B_FRP_PIN, HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD);
        hw_gpio_pad_latch_enable(LPM012M134B_FRP_PORT, LPM012M134B_FRP_PIN);
        hw_gpio_pad_latch_disable(LPM012M134B_FRP_PORT, LPM012M134B_FRP_PIN);

        hw_gpio_set_pin_function(LPM012M134B_XFRP_PORT, LPM012M134B_XFRP_PIN, HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD);
        hw_gpio_pad_latch_enable(LPM012M134B_XFRP_PORT, LPM012M134B_XFRP_PIN);
        hw_gpio_pad_latch_disable(LPM012M134B_XFRP_PORT, LPM012M134B_XFRP_PIN);
#endif /* dg_configUSE_LPM012M134B */

        ad_lcdc_handle_t dev = dev_open();
        ad_lcdc_execute_cmds(dev, screen_init_cmds, sizeof(screen_init_cmds));
        dev_close(dev);
}

static void screen_power_on(void)
{
#if dg_configUSE_LPM012M134B
        hw_gpio_set_active(LPM012M134B_PEN_PORT, LPM012M134B_PEN_PIN);
        hw_gpio_pad_latch_enable(LPM012M134B_PEN_PORT, LPM012M134B_PEN_PIN);
        hw_gpio_pad_latch_disable(LPM012M134B_PEN_PORT, LPM012M134B_PEN_PIN);
#endif /* dg_configUSE_LPM012M134B */

        ad_lcdc_handle_t dev = dev_open();
        ad_lcdc_execute_cmds(dev, screen_power_on_cmds, sizeof(screen_power_on_cmds));
        dev_close(dev);
}

static void screen_enable(void)
{
#if dg_configUSE_LPM012M134B
        hw_gpio_set_pin_function(LPM012M134B_FRP_PORT, LPM012M134B_FRP_PIN, HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD);
        hw_gpio_pad_latch_enable(LPM012M134B_FRP_PORT, LPM012M134B_FRP_PIN);
        hw_gpio_pad_latch_disable(LPM012M134B_XFRP_PORT, LPM012M134B_XFRP_PIN);

        hw_gpio_set_pin_function(LPM012M134B_XFRP_PORT, LPM012M134B_XFRP_PIN, HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD);
        hw_gpio_pad_latch_enable(LPM012M134B_XFRP_PORT, LPM012M134B_XFRP_PIN);
        hw_gpio_pad_latch_disable(LPM012M134B_FRP_PORT, LPM012M134B_FRP_PIN);
#endif /* dg_configUSE_LPM012M134B */

        ad_lcdc_handle_t dev = dev_open();
        ad_lcdc_execute_cmds(dev, screen_enable_cmds, sizeof(screen_enable_cmds));
        dev_close(dev);
}

static void screen_disable(void)
{
        ad_lcdc_handle_t dev = dev_open();
        ad_lcdc_execute_cmds(dev, screen_disable_cmds, sizeof(screen_disable_cmds));
        dev_close(dev);

#if dg_configUSE_LPM012M134B
        hw_gpio_set_pin_function(LPM012M134B_FRP_PORT, LPM012M134B_FRP_PIN, HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO);
        hw_gpio_set_inactive(LPM012M134B_FRP_PORT, LPM012M134B_FRP_PIN);
        hw_gpio_pad_latch_enable(LPM012M134B_FRP_PORT, LPM012M134B_FRP_PIN);
        hw_gpio_pad_latch_disable(LPM012M134B_FRP_PORT, LPM012M134B_FRP_PIN);

        hw_gpio_set_pin_function(LPM012M134B_XFRP_PORT, LPM012M134B_XFRP_PIN, HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO);
        hw_gpio_set_inactive(LPM012M134B_XFRP_PORT, LPM012M134B_XFRP_PIN);
        hw_gpio_pad_latch_enable(LPM012M134B_XFRP_PORT, LPM012M134B_XFRP_PIN);
        hw_gpio_pad_latch_disable(LPM012M134B_XFRP_PORT, LPM012M134B_XFRP_PIN);
#endif /* dg_configUSE_LPM012M134B */
}

static void screen_power_off(void)
{
        ad_lcdc_handle_t dev = dev_open();
        ad_lcdc_execute_cmds(dev, screen_power_off_cmds, sizeof(screen_power_off_cmds));
        dev_close(dev);

#if dg_configUSE_LPM012M134B
        hw_gpio_set_inactive(LPM012M134B_PEN_PORT, LPM012M134B_PEN_PIN);
        hw_gpio_pad_latch_enable(LPM012M134B_PEN_PORT, LPM012M134B_PEN_PIN);
        hw_gpio_pad_latch_disable(LPM012M134B_PEN_PORT, LPM012M134B_PEN_PIN);
#endif /* dg_configUSE_LPM012M134B */
}

static void screen_clear(void)
{
        ad_lcdc_handle_t dev = dev_open();
        ad_lcdc_execute_cmds(dev, screen_clear_cmds, sizeof(screen_clear_cmds));
        dev_close(dev);
}

static void dev_draw(ad_lcdc_handle_t dev, const hw_lcdc_layer_t *layer)
{
        uint32_t fps;
        OS_TICK_TIME time = OS_GET_TICK_COUNT();
#if dg_configUSE_PSP27801
        hw_lcdc_mipi_cmd(HW_LCDC_MIPI_CMD, 0x5C);
#endif
        ad_lcdc_draw_screen_async(dev, layer, frame_update_cb, &frame_update_cb_data);
        OS_ASSERT(OS_EVENT_SIGNALED == OS_EVENT_WAIT(frame_update_cb_data.event, OS_MS_2_TICKS(1000)));
        fps = 10000 / OS_TICKS_2_MS(OS_GET_TICK_COUNT() - time);
        //printf("FPS: %d.%d\r\n", fps / 10, fps % 10);
}

static void dev_set_partial_update(ad_lcdc_handle_t dev, const hw_lcdc_frame_t *frame)
{
#if dg_configUSE_PSP27801
        ad_lcdc_acquire(dev);
        hw_lcdc_mipi_cmd(HW_LCDC_MIPI_CMD, 0x15);
        hw_lcdc_mipi_cmd(HW_LCDC_MIPI_DATA, (frame->startx + 16) & 0xFF);
        hw_lcdc_mipi_cmd(HW_LCDC_MIPI_DATA, (frame->endx + 16) & 0xFF);

        hw_lcdc_mipi_cmd(HW_LCDC_MIPI_CMD, 0x75);
        hw_lcdc_mipi_cmd(HW_LCDC_MIPI_DATA, frame->starty & 0xFF);
        hw_lcdc_mipi_cmd(HW_LCDC_MIPI_DATA, frame->endy & 0xFF);
        ad_lcdc_release(dev);
#endif
        ad_lcdc_set_partial_update(dev, frame);
}

static void dev_exit_partial_update(ad_lcdc_handle_t dev)
{
#if dg_configUSE_PSP27801
        hw_lcdc_frame_t frame = {
                .startx = 0,
                .starty = 0,
                .endx = GDI_DISP_RESX - 1,
                .endy = GDI_DISP_RESY - 1,
        };
        dev_set_partial_update(dev, &frame);
#else
        ad_lcdc_exit_partial_update(dev);
#endif
}

static HW_LCDC_LAYER_COLOR_MODE gdi_to_layer_color_format(gdi_color_fmt_t format)
{
        switch (format) {
#if USE_COLOR_FORMAT == CF_NATIVE_RGB332
        case GDI_FORMAT_RGB332:   return HW_LCDC_LCM_RGB332;
#endif
#if USE_COLOR_FORMAT == CF_NATIVE_RGBA8888
        case GDI_FORMAT_RGBA8888: return HW_LCDC_LCM_RGBA8888;
#endif
        default:                  ASSERT_ERROR(0);
        }
}

static uint32_t calc_stride(gdi_coord_t width)
{
        uint32_t stride = hw_lcdc_stride_size(gdi_to_layer_color_format(gdi->color_format), width);
        return (stride + 0x3) & (~0x3);
}

static void gdi_flush_frame_buffer(size_t buffer)
{
#if USE_COLOR_FORMAT == CF_NATIVE_RGB332
        OPT_MEMSET(gdi->buffer[buffer], gdi->bg_color, gdi->stride * gdi->height);
#elif USE_COLOR_FORMAT == CF_NATIVE_RGBA8888
        size_t len = gdi->stride * gdi->height;
        for (uint32_t *d = (uint32_t *)gdi->buffer[buffer]; d < (uint32_t *)(gdi->buffer[buffer] + len); d++) {
                *d = gdi->bg_color;
        }
#endif
}

void gdi_init(void)
{
        uint8_t i;

        if (gdi) {
                return;
        }

        gdi = OS_MALLOC(sizeof(gdi_t) + sizeof(uint8_t *) * GDI_SINGLE_FB_NUM);
#if USE_COLOR_FORMAT == CF_NATIVE_RGB332
        gdi->color_format = GDI_FORMAT_RGB332;
#elif USE_COLOR_FORMAT == CF_NATIVE_RGBA8888
        gdi->color_format = GDI_FORMAT_RGBA8888;
#endif

        OS_EVENT_CREATE(frame_update_cb_data.event);

        gdi->width = GDI_DISP_RESX;
        gdi->height = GDI_DISP_RESY;

        gdi->stride = calc_stride(gdi->width);

        screen_setup();

        gdi->bg_color = GDI_COLOR_BLACK;

        gdi->bufs_num = GDI_SINGLE_FB_NUM;
        for (i = 0; i < gdi->bufs_num; i++) {
                gdi->buffer[i] = (uint8_t *)(i * gdi->stride * gdi->height + GDI_FRAME_BUFFER_ADDR);
        }

#if dg_configUSE_HW_QSPI2
        if (qspi_is_valid_addr((uint32_t)GDI_FRAME_BUFFER_ADDR)) {
                OS_ASSERT(qspi_get_device_size(HW_QSPIC2) >= GDI_DISP_RESX * GDI_DISP_RESY
                        * GDI_COLOR_BYTES * (GDI_SINGLE_FB_NUM + (2 * GDI_DOUBLE_FB_NUM)));
        }
#endif

        gdi->active_buf = 0;
}

void gdi_set_bg_color(gdi_color_t color)
{
        gdi->bg_color = color;
        gdi_flush_frame_buffers();
}

void gdi_flush_active_frame_buffer(void)
{
        gdi_flush_frame_buffer(gdi->active_buf);
}

void gdi_flush_frame_buffers(void)
{
        for (size_t i = 0; i < gdi->bufs_num; i++) {
                gdi_flush_frame_buffer(i);
        }
}

void gdi_display_power_on(void)
{
        if (!gdi->display_powered) {
                screen_power_on();
        }
        gdi->display_powered = true;
}

void gdi_display_power_off(void)
{
        if (gdi->display_powered) {
                screen_power_off();
        }
        gdi->display_powered = false;
}

bool gdi_display_is_powered(void)
{
        return gdi->display_powered;
}

void gdi_display_enable(void)
{
        if (!gdi->display_enabled) {
                screen_enable();
        }
        gdi->display_enabled = true;
}

void gdi_display_disable(void)
{
        if (gdi->display_enabled) {
                screen_disable();
        }
        gdi->display_enabled = false;
}

bool gdi_display_is_enabled(void)
{
        return gdi->display_enabled;
}

void gdi_display_update(void)
{
        ad_lcdc_handle_t dev;
        hw_lcdc_layer_t layer;

        layer.baseaddr = (uint32_t)gdi->buffer[gdi->active_buf];
        layer.dma_prefetch_lvl = HW_LCDC_FIFO_PREFETCH_LVL;
        layer.format = gdi_to_layer_color_format(gdi->color_format);
        layer.resx = gdi->width;
        layer.resy = gdi->height;
        layer.startx = 0;
        layer.starty = 0;
        layer.stride = gdi->stride;

        dev = dev_open();
        dev_draw(dev, &layer);
        dev_close(dev);
}

void gdi_display_clear(void)
{
        screen_clear();
}

void gdi_swipe_left(gdi_coord_t offsety)
{
        uint8_t *frame = (uint8_t *)(gdi->bufs_num * gdi->stride * gdi->height
                + GDI_FRAME_BUFFER_ADDR);
        uint8_t prev_buffer = gdi->active_buf;
        int32_t stride = calc_stride(gdi->width * 2);
        gdi_coord_t height = (gdi->height - offsety);
        uint32_t offset = hw_lcdc_stride_size(gdi_to_layer_color_format(gdi->color_format),
                gdi->width);
        hw_lcdc_layer_t layer;

        if (++gdi->active_buf >= gdi->bufs_num) {
                gdi->active_buf = 0;
        }

        for (int row = offsety; row < gdi->height; ++row) {
                memcpy(&frame[(row - offsety) * stride],
                        &gdi->buffer[prev_buffer][row * gdi->stride], gdi->stride);
                memcpy(&frame[(row - offsety) * stride + offset],
                        &gdi->buffer[gdi->active_buf][row * gdi->stride], gdi->stride);
        }

        layer.baseaddr = (uint32_t)frame;
        layer.dma_prefetch_lvl = HW_LCDC_FIFO_PREFETCH_LVL;
        layer.format = gdi_to_layer_color_format(gdi->color_format);
        layer.resx = gdi->width * 2;
        layer.resy = height;
        layer.startx = 0;
        layer.starty = offsety;
        layer.stride = stride;

        /* Iterate over all the steps */
        {
                ad_lcdc_handle_t dev = dev_open();
                hw_lcdc_frame_t frame_area;

                frame_area.startx = 0;
                frame_area.starty = offsety;
                frame_area.endx = gdi->width - 1;
                frame_area.endy = gdi->height - 1;
                dev_set_partial_update(dev, &frame_area);

                for (int step = 0; step <= gdi->width; step += (gdi->width / GDI_SWIPE_STEPS)) {
                        layer.startx = -step;
                        dev_draw(dev, &layer);
                }

                dev_exit_partial_update(dev);

                dev_close(dev);
        }
}

void gdi_swipe_right(gdi_coord_t offsety)
{
        uint8_t *frame = (uint8_t *)(gdi->bufs_num * gdi->stride * gdi->height
                + GDI_FRAME_BUFFER_ADDR);
        uint8_t prev_buffer = gdi->active_buf;
        int32_t stride = calc_stride(gdi->width * 2);
        gdi_coord_t height = (gdi->height - offsety);
        uint32_t offset = hw_lcdc_stride_size(gdi_to_layer_color_format(gdi->color_format),
                gdi->width);
        hw_lcdc_layer_t layer;

        if (++gdi->active_buf >= gdi->bufs_num) {
                gdi->active_buf = 0;
        }

        for (int row = offsety; row < gdi->height; ++row) {
                memcpy(&frame[(row - offsety) * stride],
                        &gdi->buffer[gdi->active_buf][row * gdi->stride], gdi->stride);
                memcpy(&frame[(row - offsety) * stride + offset],
                        &gdi->buffer[prev_buffer][row * gdi->stride], gdi->stride);
        }

        layer.baseaddr = (uint32_t)frame;
        layer.dma_prefetch_lvl = HW_LCDC_FIFO_PREFETCH_LVL;
        layer.format = gdi_to_layer_color_format(gdi->color_format);
        layer.resx = gdi->width * 2;
        layer.resy = height;
        layer.startx = -gdi->width;
        layer.starty = offsety;
        layer.stride = stride;

        /* Iterate over all the steps */
        {
                ad_lcdc_handle_t dev = dev_open();
                hw_lcdc_frame_t frame_area;

                frame_area.startx = 0;
                frame_area.starty = offsety;
                frame_area.endx = gdi->width - 1;
                frame_area.endy = gdi->height - 1;
                dev_set_partial_update(dev, &frame_area);

                for (int step = 0; step <= gdi->width; step += (gdi->width / GDI_SWIPE_STEPS)) {
                        layer.startx = -gdi->width + step;
                        dev_draw(dev, &layer);
                }

                dev_exit_partial_update(dev);

                dev_close(dev);
        }
}

void gdi_swipe_up(gdi_coord_t offsety)
{
        uint8_t *frame = (uint8_t *)(gdi->bufs_num * gdi->stride * gdi->height
                + GDI_FRAME_BUFFER_ADDR);
        uint8_t prev_buffer = gdi->active_buf;
        gdi_coord_t height = (gdi->height - offsety);
        int buffer_len = gdi->stride * height;
        hw_lcdc_layer_t layer;

        if (++gdi->active_buf >= gdi->bufs_num) {
                gdi->active_buf = 0;
        }

        memcpy(&frame[0 * buffer_len], &gdi->buffer[prev_buffer][offsety * gdi->stride],
                buffer_len);
        memcpy(&frame[1 * buffer_len], &gdi->buffer[gdi->active_buf][offsety * gdi->stride],
                buffer_len);

        layer.baseaddr = (uint32_t)frame;
        layer.dma_prefetch_lvl = HW_LCDC_FIFO_PREFETCH_LVL;
        layer.format = gdi_to_layer_color_format(gdi->color_format);
        layer.resx = gdi->width;
        layer.resy = height * 2;
        layer.startx = 0;
        layer.starty = offsety;
        layer.stride = gdi->stride;

        /* Iterate over all the steps */
        {
                ad_lcdc_handle_t dev = dev_open();
                hw_lcdc_frame_t frame_area;

                frame_area.startx = 0;
                frame_area.starty = offsety;
                frame_area.endx = gdi->width - 1;
                frame_area.endy = gdi->height - 1;
                dev_set_partial_update(dev, &frame_area);

                for (int step = 0; step <= height; step += (height / GDI_SWIPE_STEPS)) {
                        layer.starty = offsety - step;
                        dev_draw(dev, &layer);
                }

                dev_exit_partial_update(dev);

                dev_close(dev);
        }
}

void gdi_swipe_down(gdi_coord_t offsety)
{
        uint8_t *frame = (uint8_t *)(gdi->bufs_num * gdi->stride * gdi->height
                + GDI_FRAME_BUFFER_ADDR);
        uint8_t prev_buffer = gdi->active_buf;
        gdi_coord_t height = (gdi->height - offsety);
        int buffer_len = gdi->stride * height;
        hw_lcdc_layer_t layer;

        if (++gdi->active_buf >= gdi->bufs_num) {
                gdi->active_buf = 0;
        }

        memcpy(&frame[0 * buffer_len], &gdi->buffer[gdi->active_buf][offsety * gdi->stride],
                buffer_len);
        memcpy(&frame[1 * buffer_len], &gdi->buffer[prev_buffer][offsety * gdi->stride],
                buffer_len);

        layer.baseaddr = (uint32_t)frame;
        layer.dma_prefetch_lvl = HW_LCDC_FIFO_PREFETCH_LVL;
        layer.format = gdi_to_layer_color_format(gdi->color_format);
        layer.resx = gdi->width;
        layer.resy = height * 2;
        layer.startx = 0;
        layer.starty = offsety - height;
        layer.stride = gdi->stride;

        /* Iterate over all the steps */
        {
                ad_lcdc_handle_t dev = dev_open();
                hw_lcdc_frame_t frame_area;

                frame_area.startx = 0;
                frame_area.starty = offsety;
                frame_area.endx = gdi->width - 1;
                frame_area.endy = gdi->height - 1;
                dev_set_partial_update(dev, &frame_area);

                for (int step = 0; step <= height; step += (height / GDI_SWIPE_STEPS)) {
                        layer.starty = offsety - height + step;
                        dev_draw(dev, &layer);
                }

                dev_exit_partial_update(dev);

                dev_close(dev);
        }
}

void gdi_set_next_frame_buffer(void)
{
        if (++gdi->active_buf >= gdi->bufs_num) {
                gdi->active_buf = 0;
        }
}

uint8_t gdi_get_current_frame_buffer(void)
{
        return gdi->active_buf;
}

void gdi_set_frame_buffer(uint8_t frame)
{
        gdi->active_buf = frame >= gdi->bufs_num ? 0 : frame;
}

static void gdi_draw_dot_native(gdi_color_t color, gdi_coord_t x, gdi_coord_t y)
{
        if(x >= gdi->width || y >= gdi->height) {
                return;
        }
#if USE_COLOR_FORMAT == CF_NATIVE_RGB332
        int byte = x + y * gdi->stride;
        gdi->buffer[gdi->active_buf][byte] = color;
#elif USE_COLOR_FORMAT == CF_NATIVE_RGBA8888
        int byte = (x << 2) + y * gdi->stride;
        *((uint32_t *)&gdi->buffer[gdi->active_buf][byte]) = color;
#endif /* USE_COLOR_FORMAT */
}

void gdi_draw_dot(gdi_color_t color, gdi_coord_t x, gdi_coord_t y)
{
        gdi_draw_dot_native(color, x, y);
}

void gdi_draw_circle(gdi_color_t color, gdi_coord_t x0, gdi_coord_t y0, gdi_coord_t diameter)
{
        int radius = diameter / 2;
        if (!(diameter % 2)) {
                int16_t x = radius, y = 0;
                int16_t radiusError = 1 - x;

                while (x >= y) {
                        gdi_draw_dot(color, x0 + x, y0 + y);
                        gdi_draw_dot(color, x0 + y, y0 + x);
                        gdi_draw_dot(color, x0 - x, y0 + y);
                        gdi_draw_dot(color, x0 - y, y0 + x);
                        gdi_draw_dot(color, x0 - x, y0 - y);
                        gdi_draw_dot(color, x0 - y, y0 - x);
                        gdi_draw_dot(color, x0 + x, y0 - y);
                        gdi_draw_dot(color, x0 + y, y0 - x);
                        y++;

                        if (radiusError < 0) {
                                radiusError += 2 * y + 1;
                        }
                        else {
                                x--;
                                radiusError += 2 * (y - x + 1);
                        }
                }
        }
        else {
                int x = 1;
                int y = radius;
                int d = radius;

                while (y >= x) {
                        gdi_draw_dot(color, x0 + x,     y0 + y);
                        gdi_draw_dot(color, x0 + y,     y0 + x);
                        gdi_draw_dot(color, x0 - x + 1, y0 + y);
                        gdi_draw_dot(color, x0 - y + 1, y0 + x);
                        gdi_draw_dot(color, x0 - x + 1, y0 - y + 1);
                        gdi_draw_dot(color, x0 - y + 1, y0 - x + 1);
                        gdi_draw_dot(color, x0 + x,     y0 - y + 1);
                        gdi_draw_dot(color, x0 + y,     y0 - x + 1);

                        if (d > x) {
                                d -= x;
                                ++x;
                        }
                        else if (d <= radius + 1 - y) {
                                d += y - 1;
                                --y;
                        }
                        else {
                                d += y - x - 1;
                                ++x;
                                --y;
                        }
                }
        }
}

void gdi_draw_line(gdi_color_t color, gdi_coord_t x0, gdi_coord_t y0, gdi_coord_t x1,
        gdi_coord_t y1)
{
        int16_t dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
        int16_t dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
        int16_t err = dx + dy, e2; /* error value e_xy */

        for (;;) {
                gdi_draw_dot(color, x0, y0);
                if (x0 == x1 && y0 == y1)
                        break;
                e2 = 2 * err;
                if (e2 >= dy) {
                        err += dy;
                        x0 += sx;
                } /* e_xy+e_x > 0 */
                if (e2 <= dx) {
                        err += dx;
                        y0 += sy;
                } /* e_xy+e_y < 0 */
        }
}

void gdi_draw_fill_circle(gdi_color_t color, gdi_coord_t x0, gdi_coord_t y0, gdi_coord_t radius)
{
        int16_t x = radius, y = 0;
        int16_t radiusError = 1 - x;

        while (x >= y) {
                gdi_draw_line(color, x + x0, y + y0, -x + x0, y + y0);
                gdi_draw_line(color, y + x0, x + y0, -y + x0, x + y0);
                gdi_draw_line(color, -x + x0, -y + y0, x + x0, -y + y0);
                gdi_draw_line(color, -y + x0, -x + y0, y + x0, -x + y0);
                y++;
                if (radiusError < 0) {
                        radiusError += 2 * y + 1;
                } else {
                        x--;
                        radiusError += 2 * (y - x + 1);
                }
        }
}

void gdi_draw_image_native(gdi_coord_t x, gdi_coord_t y, const uint8_t *image, gdi_coord_t width,
        gdi_coord_t height)
{
        const int d_width = MIN(width, gdi->width - x);
        const int d_height = MIN(height, gdi->height - y);

        switch (gdi->color_format) {
#if USE_COLOR_FORMAT == CF_NATIVE_RGB332
        case GDI_FORMAT_RGB332:
        {
                for (int row = 0; row < d_height; ++row) {
                        int d_byte = x + (y + row) * gdi->stride;
                        int s_byte = row * width;
                        memcpy(&gdi->buffer[gdi->active_buf][d_byte], &image[s_byte], d_width);
                }
                break;
        }
#elif USE_COLOR_FORMAT == CF_NATIVE_RGBA8888
        case GDI_FORMAT_RGBA8888:
        {
                for (int row = 0; row < d_height; ++row) {
                        int d_byte = (x << 2) + (y + row) * gdi->stride;
                        int s_byte = (row * width) << 2;
                        memcpy(&gdi->buffer[gdi->active_buf][d_byte], &image[s_byte], d_width << 2);
                }
                break;
        }
#endif
        default:
                ASSERT_ERROR(0);
        }
}

void gdi_draw_image_recolor(gdi_coord_t x, gdi_coord_t y, const uint8_t *image,
        gdi_color_fmt_t src_format, gdi_coord_t width, gdi_coord_t height, gdi_color_t color)
{
        const int d_width = MIN(width, gdi->width - x);
        const int d_height = MIN(height, gdi->height - y);
        gdi_color_t fgnd = color;
        gdi_color_t bgnd = GDI_COLOR_BLACK;

        switch (src_format) {
        case GDI_FORMAT_L1:
        {
                const int s_stride = CEILING_FUNC(width, 8);
                for (int row = 0; row < d_height; ++row) {
                        for (int col = 0; col < d_width; ++col) {
                                int s_byte = col / 8 + row * s_stride;
                                int s_pos = col % 8;
                                gdi_color_t pixel = ((image[s_byte] & (1 << s_pos)) ? fgnd : bgnd);
                                gdi_draw_dot(pixel, x + col, y + row);
                        }
                }
                break;
        }
        case GDI_FORMAT_L4:
        {
                const int s_stride = CEILING_FUNC(width, 2);
                for (int row = 0; row < d_height; ++row) {
                        for (int col = 0; col < d_width; ++col) {
                                int s_byte = col / 2 + row * s_stride;
                                int s_pos = col % 2;
                                int blend = (image[s_byte] >> (1 - s_pos)) & 0xF;
                                gdi_color_t pixel = (fgnd * blend + bgnd * (0xF - blend)) / 0xF;
                                gdi_draw_dot(pixel, x + col, y + row);
                        }
                }
                break;
        }
        case GDI_FORMAT_L8:
        {
                const int s_stride = width;
                for (int row = 0; row < d_height; ++row) {
                        for (int col = 0; col < d_width; ++col) {
                                int s_byte = col + row * s_stride;
                                int blend = image[s_byte] & 0xFF;
                                gdi_color_t pixel = (fgnd * blend + bgnd * (0xFF - blend)) / 0xFF;
                                gdi_draw_dot(pixel, x + col, y + row);
                        }
                }
                break;
        }
        default:
                ASSERT_ERROR(0);
        }
}

void gdi_draw_image(gdi_coord_t x, gdi_coord_t y, const uint8_t *image, gdi_color_fmt_t src_format,
        gdi_coord_t width, gdi_coord_t height)
{
        const int d_width = MIN(width, gdi->width - x);
        const int d_height = MIN(height, gdi->height - y);

        if (src_format == gdi->color_format) {
                gdi_draw_image_native(x, y, image, d_width, d_height);
                return;
        }
        switch(src_format) {
        case GDI_FORMAT_L1:
        case GDI_FORMAT_L4:
        case GDI_FORMAT_L8:
                gdi_draw_image_recolor(x, y, image, src_format, d_width, d_height, GDI_COLOR_WHITE);
                break;
        default:
                ASSERT_ERROR(0);
        }
}

uint8_t gdi_draw_font(char character, gdi_color_t color, gdi_coord_t x, gdi_coord_t y,
        gdi_scale_t scale, const font_info_t * font)
{
        uint8_t pos = character - font->start;
        gdi_coord_t width = (font->descriptor[pos].width * scale) / 10;
        gdi_coord_t height = (font->height * scale) / 10;
        int s_stride = CEILING_FUNC(font->descriptor[pos].width, 8);

        for (int row = 0; row < height; ++row) {
                for (int col = 0; col < width; ++col) {
                        int s_byte = ((col * 10) / scale) / 8 + ((row * 10) / scale) * s_stride;
                        int s_pos = ((col * 10) / scale) % 8;
                        if (font->bitmap[font->descriptor[pos].offset + s_byte] & (1 << s_pos))
#if HARDWARE_PLATFORM_USB_VB
                                gdi_draw_dot(color, x - col, y - row);
#elif dg_configUSE_DT280QV10CT
                                gdi_draw_dot(color, x - row, y + col);

#else
                                gdi_draw_dot(color, x + col, y + row);
#endif
                }
        }
        return width;
}

void gdi_draw_rect(gdi_color_t color, gdi_coord_t x, gdi_coord_t y, gdi_coord_t w, gdi_coord_t h)
{
        gdi_draw_line(color, x, y, x + w, y);
        gdi_draw_line(color, x, y + h, x + w, y + h);
        gdi_draw_line(color, x, y, x, y + h);
        gdi_draw_line(color, x + w, y, x + w, y + h);
}

void gdi_draw_fill_rect(gdi_color_t color, gdi_coord_t x, gdi_coord_t y, gdi_coord_t w,
        gdi_coord_t h)
{
        for (int i = 0; i < h; i++) {
                gdi_draw_line(color, x, y + i, x + w, y + i);
        }
}

void gdi_draw_arc(gdi_color_t color, gdi_coord_t x, gdi_coord_t y, gdi_coord_t r, gdi_coord_t t,
        int start_angle, int end_angle)
{
        for (int i = start_angle; i <= end_angle; i++) {
                int8_t sin = math2d_sin(MATH2D_ANGLE_DEG(i));
                int8_t cos = math2d_cos(MATH2D_ANGLE_DEG(i));

                uint16_t x1 = math2d_mul_div_su16(cos, r + t / 2, 128);
                uint16_t y1 = math2d_mul_div_su16(sin, r + t / 2, 128);

                gdi_draw_fill_circle(color, x + x1, y + y1, t / 2);
        }
}

/**///JE--
//
// Getting address of frame buffer
//
void * gdi_get_frame_buffer_addr(void) {
  return (void *)frame_buffer;
}
/**///--JE
#endif /* dg_configLCDC_ADAPTER */
/**
 * \}
 * \}
 */
