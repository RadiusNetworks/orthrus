/**
 ****************************************************************************************
 *
 * @file tof_interface.c
 *
 * @brief ToF interface to external host
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <stdio.h>
#include <math.h>
#include "string.h"
#include "osal.h"
#include "tof_interface.h"
#include "acquisition.h"
#include "ble_tof.h"
#include "ble_tof_sync.h"

//// Exchange memory for Matlab is in RAM (at the end of it). See sections.ld for details.
/* Fixed size in sections.ld.h and matlab exchange memory */
volatile uint32_t tof_exchange_memory[TOF_PARAMS_LENGTH]  __attribute__((section (".tof_section")));
volatile tof_params_t *tof_params = (tof_params_t *) tof_exchange_memory;

volatile uint32_t tof_data[TOF_DATA_MAX_LENGTH];

void tof_interface_init()
{
        OS_ASSERT(sizeof(tof_params_t) <= TOF_PARAMS_LENGTH);

        memset ((void *)tof_exchange_memory, 0, TOF_PARAMS_LENGTH * 4);
        tof_data[0] = 0xFFFF;

        /* initialize handshake variables */
        tof_params->fw_ready = 0;
        tof_params->pc_ready = 1;       /* no PC participates during restarts */

        /* set ping pong and rfmon data address */
        tof_params->pp_data = (uint32_t) tof_data;
        tof_params->rfmon_data = (uint32_t) rfmon_sample_buffer;
}

void tof_interface_params_exchange()
{
        /* notify matalb */
        tof_params->role = TOF_ROLE_UNDEFINED;
        tof_params->fw_ready = 1;
        printf("wait for role ...\n\r");
        /* wait for matlab to set the rest of the parameters */
        while(tof_params->fw_ready == 1 || tof_params->role == TOF_ROLE_UNDEFINED) {
                OS_DELAY_MS(2);
        }
        printf("\n\r%s: role: %d, fw_ready: %d, fstep: %d, nb_atoms: %d\n\r", __func__, tof_params->role, tof_params->fw_ready, tof_params->f_step_mhz, tof_params->nb_atoms);
}

void tof_interface_data_exchange(uint32_t evt_counter)
{
        /* set event counter and notify matalb */
        tof_params->evt_counter =  evt_counter;
        tof_params->oflow =  rfmon_overflow();
        tof_params->agc = get_acquisition_agc_value();
        tof_params->fw_ready = 1;

        /* wait for matlab to copy the data and clear the ready flag */
        while(tof_params->fw_ready == 1) {
                OS_DELAY_MS(2);
        }
}

void tof_interface_update_c_results (uint32_t c_evt, float c_distance)
{
        tof_params->c_evt_counter = c_evt;
        tof_params->c_dist_cm = (uint32_t)round(c_distance * 100.0);
}
