/**
 ****************************************************************************************
 *
 * @file platform_devices.h
 *
 * @brief Configuration of devices connected to board
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef PLATFORM_DEVICES_H_
#define PLATFORM_DEVICES_H_

#include "peripheral_setup.h"
#include "ad_lcdc.h"

/* Platform devices configuration */

#if dg_configLCDC_ADAPTER

#if dg_configUSE_PSP27801
extern const ad_lcdc_controller_conf_t psp27801_cfg;
#endif /* dg_configUSE_PSP27801 */

#if dg_configUSE_DT280QV10CT
extern const ad_lcdc_controller_conf_t dt280qv10ct_cfg;
#endif /* dg_configUSE_DT280QV10CT */

#endif /* dg_configLCDC_ADAPTER */

#endif /* PLATFORM_DEVICES_H_ */
