/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup IMAGE
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file image.c
 *
 * @brief Image widget implementation
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include "image.h"
#include "gdi.h"

void ui_draw_image(const ui_screen_item_t *item)
{
        const ui_image_widget_t *properties = item->properties;

        if (!UI_IS_FLAG_SET(item, UI_FLAG_VISIBLE)) {
                return;
        }
        if (UI_IS_FLAG_SET(item, UI_FLAG_RECOLOR)) {
                gdi_draw_image_recolor(item->x, item->y, properties->bitmap, properties->format, item->width, item->height, item->color);
        }
        else {
                gdi_draw_image(item->x, item->y, properties->bitmap, properties->format, item->width, item->height);
        }
}

/**
 * \}
 * \}
 * \}
 */

