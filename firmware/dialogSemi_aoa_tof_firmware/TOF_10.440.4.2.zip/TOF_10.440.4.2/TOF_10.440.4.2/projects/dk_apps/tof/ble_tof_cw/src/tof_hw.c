/**
 ****************************************************************************************
 *
 * @file tof_hw.c
 *
 * @brief ToF code related to hardware
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <string.h>
#include <stdio.h>
#include "hw_gpio.h"

#include "gdi.h"
#include "common.h"
#include "calibri_36_digits.h"
#include "calibri_18_bold.h"
#include "calibri_48_bold_digits_sep.h"
#include "calibri_72_bold_digits_sep.h"

#ifdef dg_configUSE_TOF_DMA
#include "datasheet.h"
#else
#include "hw_dma.h"
#include "portmacro.h"
PRIVILEGED_DATA DMA_setup memcpy_dma;
#endif

bool tof_hw_k1_button_pressed(void)
{
#if HARDWARE_PLATFORM_USB_VB
        return  hw_gpio_get_pin_status(KEY1_PORT, KEY1_PIN);
#else
        return !hw_gpio_get_pin_status(KEY1_PORT, KEY1_PIN);
#endif
}

void tof_lcd_init()
{
#if dg_configLCDC_ADAPTER
        gdi_init();
        gdi_display_power_on();
        gdi_display_clear();
        gdi_display_enable();
        gdi_set_bg_color(GDI_COLOR_DBLUE);
        gdi_display_update();
#endif
}

void tof_lcd_draw_string(const char *str)
{
#if dg_configLCDC_ADAPTER
        /* toggle indicator per valid measurement */
        static bool update_ind = true;
        char indicator[2];

        if (update_ind) {
                sprintf(indicator,".");
        } else {
                sprintf(indicator," ");
        }
        update_ind = !update_ind;

        gdi_set_bg_color(GDI_COLOR_DBLUE);
#if HARDWARE_PLATFORM_USB_VB
	ui_draw_string(GDI_COLOR_WHITE, 80, 50, &calibri_18ptFontInfo, str, 15);
	ui_draw_string(GDI_COLOR_WHITE, 87, 107, &calibri_18ptFontInfo, indicator, 15);
#else
#if dg_configUSE_DT280QV10CT
        //ui_draw_string(GDI_COLOR_WHITE, 50, 50,&calibri_48ptFontInfo, str, 10);
        ui_draw_string(GDI_COLOR_WHITE, 50, 100, &calibri_72ptFontInfo, str, 10);
        ui_draw_string(GDI_COLOR_WHITE, 290, 270, &calibri_72ptFontInfo, indicator, 10);
#else
        ui_draw_string(GDI_COLOR_WHITE, 10, 10,&calibri_18ptFontInfo, str, 15);
        ui_draw_string(GDI_COLOR_WHITE, 87, 67, &calibri_18ptFontInfo, indicator, 15);
#endif
#endif


        gdi_display_update();
#endif
}


void tof_hw_rpi_set_antenna_switch(uint8_t ant)
{
#ifdef HARDWARE_PLATFORM_RPI
        SetWord16(P1_01_MODE_REG, 0x300);
        if (ant & 1)
        {
                /* ant = 1 => LED ON => antenna left, P1_01 = 1 */
                SetWord16(P1_SET_DATA_REG, 2);
                printf("antenna switch: select left - LED on\r\n");
        }
        else
        {
                /* ant = 0 => LED OFF => antenna right, P1_01 = 0 */
                SetWord16(P1_RESET_DATA_REG, 2);
                printf("antenna switch: select right  - LED off\r\n");
        }
#else
        printf("antenna switch: not defined\r\n");
#endif
}

#ifdef dg_configUSE_TOF_DMA

#define USE_DMA_MS_PIN          (0)

#if  USE_DMA_MS_PIN
/* Measurement Trigger output - P1_08 */
#define MS_TRIGGER_PIN (1<<8)
#define CONFIGURE_MS_TRIGGER_OUT()      do{SetWord32( P1_08_MODE_REG, 0x300);} while(0)
#define SET_MS_TRIGGER(x)               do{ SetWord32(x ? P1_SET_DATA_REG : P1_RESET_DATA_REG, MS_TRIGGER_PIN);} while(0)
#else
#define CONFIGURE_MS_TRIGGER_OUT()
#define SET_MS_TRIGGER(x)
#endif

void init_cw_dma(uint16_t length)
{
  // setup for 1 byte transfer, 2500 bytes = 240us
  // setup for 4 byte transfer, 2500 bytes =  60us
  // setup memcpy transfer,     2500 bytes = 120us
  SetBits(DMA0_CTRL_REG, DMA_ON, 0);

  SetBits16(DMA0_CTRL_REG, AINC, 1);
  SetBits16(DMA0_CTRL_REG, BINC, 1);
  // setup for 4 byte transfer.
  uint16_t dma_len;
  dma_len = length / 4;
  dma_len += length & 3 ? 1 : 0;
  SetWord16(DMA0_LEN_REG, dma_len-1);
  SetWord16(DMA0_INT_REG, dma_len-1);
  SetBits16(DMA0_CTRL_REG, BW, 2);
  SetWord8(DMA_INT_MASK_REG, DMA_IRQ_ENABLE0);
  NVIC_EnableIRQ(DMA_IRQn);

}

void start_cw_dma(void* dst, void * src)
{
        CONFIGURE_MS_TRIGGER_OUT();
        SET_MS_TRIGGER(1);

        SetWord32(DMA0_A_START_REG, (uint32_t)src);
        SetWord32(DMA0_B_START_REG, (uint32_t)dst);
        SetBits(DMA0_CTRL_REG, DMA_ON, 1);
}

void wait_cw_dma()
{
        bool dma_active = true;
        do
        {
                /* just poll register */
                dma_active = GetBits16(DMA0_CTRL_REG, DMA_ON);
        }
        while(dma_active);
}


void DMA_Handler()
{
  /* setup dummy handler, just to catch IRQ */
  SET_MS_TRIGGER(0);
}

#else

static void memcpy_dma_callback(void *user_data, uint32_t len)
{

}

void start_cw_dma(void* dst, void * src)
{
        hw_dma_channel_update_destination(memcpy_dma.channel_number, dst, memcpy_dma.length,
                                                                               memcpy_dma.callback);
        hw_dma_channel_enable(memcpy_dma.channel_number, HW_DMA_STATE_ENABLED);
}

void tof_dma_init(uint16_t length)
{
        memcpy_dma.channel_number = HW_DMA_CHANNEL_0;
        memcpy_dma.bus_width = HW_DMA_BW_WORD;
        memcpy_dma.irq_enable = HW_DMA_IRQ_STATE_ENABLED;
        memcpy_dma.dma_req_mux = HW_DMA_TRIG_NONE;
        memcpy_dma.irq_nr_of_trans = 0;                 /* set to 0 to fire IRQ after transfer ends */
        memcpy_dma.a_inc = HW_DMA_AINC_TRUE;
        memcpy_dma.b_inc = HW_DMA_BINC_TRUE;
        memcpy_dma.circular = HW_DMA_MODE_NORMAL;
        memcpy_dma.dma_prio = 0;
        memcpy_dma.dma_idle = HW_DMA_IDLE_BLOCKING_MODE;//HW_DMA_IDLE_INTERRUPTING_MODE; /* Not used by the HW in this case */
        memcpy_dma.dma_init = HW_DMA_INIT_AX_BX_AY_BY;
        memcpy_dma.dreq_mode = HW_DMA_DREQ_START;
        memcpy_dma.burst_mode = HW_DMA_BURST_MODE_DISABLED;
        memcpy_dma.src_address = 0;
        memcpy_dma.dest_address = 0;
        memcpy_dma.length = length/4; /* words or bytes ? */
        memcpy_dma.callback = memcpy_dma_callback;
        memcpy_dma.user_data = NULL;

        hw_dma_channel_initialization(&memcpy_dma);
        //hw_dma_channel_enable(memcpy_dma.channel_number, HW_DMA_STATE_ENABLED);

        printf("DMA0_CTRL_REG %x\r\n", DMA->DMA0_CTRL_REG);
        printf("DMA0_LEN_REG %x\r\n",  DMA->DMA0_LEN_REG);
        printf("DMA0_INT_REG %x\r\n",  DMA->DMA0_INT_REG);
        printf("DMA_INT_MASK_REG %x\r\n",  DMA->DMA_INT_MASK_REG);

        hw_gpio_configure_pin(HW_GPIO_PORT_1, HW_GPIO_PIN_6, HW_GPIO_MODE_OUTPUT,
                                                                     HW_GPIO_FUNC_GPIO, 0);
}

void init_cw_dma(uint16_t length)
{
        tof_dma_init(length);
}
#endif /* dg_configUSE_TOF_DMA */
