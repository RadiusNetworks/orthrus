/**
 ****************************************************************************************
 *
 * @file ble_tof_cw_task.c
 *
 * @brief BLE ToF CW task
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include "osal.h"
#include "ad_nvms.h"
#include "hw_cpm.h"
#include "ble_tof.h"
#include "ble_bufops.h"
#include "tof_interface.h"
#include "tof_cli.h"
#include "tof_hw.h"
#include "ble_tof_cw_config.h"

#include "acquisition.h"

#if TOF_ENABLE_CW_DIST_CALC
#include "cw_distance.h"
#include "iq_demultiplex.h"
#endif

#if (RFMON_CFG_LEN_SMPL > TOF_DATA_MAX_LENGTH)
#error "invalid tof capture length"
#endif

/* tof configuration contains
 * 2 bytes of magic 0xABCD,
 * 1 byte role,
 * 1 byte set number,
 * 2 bytes cw offset,
 * 2 bytes xtal32m trim value
 * 1 byte  flag_auto_xtal32_trim
 * 1 byte  flag_distance_averaging
 */
#define TOF_CONFIG_SETTING_BYTE_SIZE  (10)
#define TOF_MEMORY_MAGIC              (0xABCD)

typedef struct {
        tof_role_t role;
        uint8_t set_number;
        int16_t cw_offset;
        uint16  xtal32m_trim_value;
        uint8_t flag_auto_xtal32_trim:1;
        uint8_t flag_distance_averaging:1;

} tof_config_params_t;


extern void ble_central_task(void *params);
extern void ble_peripheral_task(void *params);

float cw_distance_offset; /* in meters */



static void  tof_config_params_print(tof_config_params_t *cfg)
{
        printf("role=%d, set_number=%d, cw_offset=%d xtal32m_trim_value=%d auto_xtal32_trim=%d, distance_averaging=%d\r\n",
                        cfg->role, cfg->set_number, cfg->cw_offset, cfg->xtal32m_trim_value, cfg->flag_auto_xtal32_trim, cfg->flag_distance_averaging);
}

static void  tof_config_params_init(tof_config_params_t *cfg)
{
        cfg->role = DEFAULT_TOF_ROLE;
        cfg->set_number = DEFAULT_TOF_SET_NUM;
        cfg->cw_offset = 0;
        cfg->xtal32m_trim_value = DEFAULT_TOF_XTAL32M_TRIM;
        cfg->flag_auto_xtal32_trim = 1;
        cfg->flag_distance_averaging = 1;
}

static bool tof_config_params_get(tof_config_params_t *cfg)
{
        uint32_t offset = 0;
        nvms_t nvms;
        uint8_t settings[TOF_CONFIG_SETTING_BYTE_SIZE];

        tof_config_params_init(cfg);

        nvms = ad_nvms_open(NVMS_GENERIC_PART);
        if (!nvms) {
                printf("Cannot open NVMS_GENERIC_PART, using default role and set number \r\n");
                return false;
        }

        /*
         * We are looking for configuration from the beginning of NVMS_GENERIC_PART
         * format of data is (xx bits)
         * magic: TOF_MEMORY_MAGIC
         * role: 0x00, 0x01 or 0x02
         */
        ad_nvms_read(nvms, offset, (uint8_t *) &settings, sizeof(settings));
        if (settings[0] != 0xAB || settings[1] != 0xCD) {
                printf("NVMS_GENERIC_PART not programmed, programming default role, set number and cw offset\r\n");
                settings[0] = 0xAB;
                settings[1] = 0xCD;
                settings[2] = cfg->role;
                settings[3] = cfg->set_number;
                put_u16(&settings[4], cfg->cw_offset);
                put_u16(&settings[6], cfg->xtal32m_trim_value);
                settings[8] = cfg->flag_auto_xtal32_trim;
                settings[9] = cfg->flag_distance_averaging;
                ad_nvms_write(nvms, offset, settings, sizeof(settings));
                return false;
        }

        if ((settings[2] > TOF_ROLE_RESPONDER) || (settings[3] >= TOF_MAX_SET_NUM)) {
                printf("NVMS_GENERIC_PART corrupted, programming default role, set number and cw offset\r\n");
                settings[2] = cfg->role;
                settings[3] = cfg->set_number;
                put_u16(&settings[4], cfg->cw_offset);
                put_u16(&settings[6], cfg->xtal32m_trim_value);
                settings[8] = cfg->flag_auto_xtal32_trim;
                settings[9] = cfg->flag_distance_averaging;
                ad_nvms_write(nvms, offset, settings, sizeof(settings));
                return false;
        }

        if (get_u16(&settings[6]) > MAX_TOF_XTAL32M_TRIM) {
                printf("XTAL trim value inside NVMS_GENERIC_PART unreasonable, programming default XTAL trim\r\n");
                put_u16(&settings[6], cfg->xtal32m_trim_value);
                ad_nvms_write(nvms, offset, settings, sizeof(settings));
        }

        cfg->role = settings[2];
        cfg->set_number = settings[3];
        cfg->cw_offset = get_u16(&settings[4]);
        cfg->xtal32m_trim_value = get_u16(&settings[6]);
        cfg->flag_auto_xtal32_trim = settings[8];
        cfg->flag_distance_averaging = settings[9];
        printf("\r\n\r\nToF configuration: ");
        tof_config_params_print(cfg);

        return true;
}

bool tof_config_params_set(tof_config_params_t *cfg)
{
        uint32_t offset = 0;
        nvms_t nvms;
        uint8_t settings[TOF_CONFIG_SETTING_BYTE_SIZE];

        nvms = ad_nvms_open(NVMS_GENERIC_PART);
        if (!nvms) {
                printf("\r\n\r\nCannot open NVMS_GENERIC_PART, setting of ToF configuration parameters failed\r\n");
                return false;
        }

        /*
         * We are looking for configuration from the beginning of NVMS_GENERIC_PART
         * format of data is (xx bits)
         * magic: TOF_MEMORY_MAGIC
         * role: 0x00, 0x01 or 0x02
         */
        ad_nvms_read(nvms, offset, (uint8_t *) &settings, sizeof(settings));
        if (settings[0] != 0xAB || settings[1] != 0xCD) {
                printf("\r\n\r\nNVMS_GENERIC_PART not programmed, setting of ToF configuration parameters failed\r\n");
                return false;
        }

        settings[2] = cfg->role;
        settings[3] = cfg->set_number;
        put_u16(&settings[4], cfg->cw_offset);
        put_u16(&settings[6], cfg->xtal32m_trim_value);
        settings[8] = cfg->flag_auto_xtal32_trim;
        settings[9] = cfg->flag_distance_averaging;
        ad_nvms_write(nvms, offset, settings, sizeof(settings));
        printf("\r\n\r\nToF configuration updated: ");
        tof_config_params_print(cfg);

        return true;
}

static char clistr[64];

void tof_config_params_menu(tof_config_params_t *cfg)
{
        int16_t mc = '0';
        int16_t mr = '0';
        tof_config_params_t menu_cfg;

        memcpy(&menu_cfg, cfg, sizeof(tof_config_params_t));

        printf("\r\nEntering configuration mode\r\n");
        while (mc != 'e') {

                printf("1. Set role\r\n");
                printf("2. Set offset\r\n");
                printf("3. Set set_number\r\n");
                printf("4. auto xtal32m trim on/off\r\n");
                printf("5. distance averaging on/off\r\n");
                printf("t. Set xtal32m trim value\r\n");
                printf("d. Dump parameters\r\n");
                printf("e. Exit configuration\r\n");
                mc = getchar();
                printf("\r\n%c. ", mc);

                if (mc == '1') {
                        printf("Enter role initiator (%d), responder (%d):\r\n", TOF_ROLE_INITIATOR, TOF_ROLE_RESPONDER);
                        mr = getchar();
                        menu_cfg.role = mr - '0';
                        printf("role %d\r\n\r\n", menu_cfg.role);
                        if ((menu_cfg.role != TOF_ROLE_INITIATOR) && (menu_cfg.role != TOF_ROLE_RESPONDER)) {
                                printf("New role is invalid and will be ignored\r\n");
                                menu_cfg.role = cfg->role;
                        }
                } else if (mc == '2') {
                        printf("Enter offset in cm:\r\n");
                        readline(clistr, sizeof(clistr) -1 );
                        menu_cfg.cw_offset = atoi(clistr);
                        printf("offset %d\r\n\r\n", menu_cfg.cw_offset);
                } else if (mc == '3') {
                        printf("Enter setnumber:\r\n");
                        readline(clistr, sizeof(clistr) -1 );
                        menu_cfg.set_number =atoi(clistr);
                        printf("setnumber %d\r\n\r\n", menu_cfg.set_number);
                        if (menu_cfg.set_number < 0 || menu_cfg.set_number > TOF_MAX_SET_NUM)
                        {
                                printf("New setnumber %d is not in range (0,%d) and will be ignored\r\n", menu_cfg.set_number, TOF_MAX_SET_NUM);
                                menu_cfg.set_number = cfg->set_number;
                        }
                } else if (mc == '4') {
                        menu_cfg.flag_auto_xtal32_trim ^= 1;
                        printf("Auto xtal32m trim is now: %d\r\n", menu_cfg.flag_auto_xtal32_trim);
                } else if (mc == '5') {
                        menu_cfg.flag_distance_averaging ^= 1;
                        printf("Distance averaging is now: %d\r\n", menu_cfg.flag_distance_averaging);
                } else if (mc == 't') {
                        printf("Enter xtal32m_trim_value:\r\n");
                        readline(clistr, sizeof(clistr) -1 );
                        menu_cfg.xtal32m_trim_value = atoi(clistr);
                        printf("xtal32m_trim_value %d\r\n\r\n", menu_cfg.xtal32m_trim_value);
                } else if (mc == 'd') {
                        printf("\r\nold: ");
                        tof_config_params_print(cfg);
                        printf("new: ");
                        tof_config_params_print(&menu_cfg);
                        printf("\n\r");
                } else if (mc == 'e') {
                        if(memcmp(cfg, &menu_cfg, sizeof(tof_config_params_t))!= 0){
                                printf("\r\n**** Updating configuration parameters**** \r\n\r\n");
                                /* update current parameters */
                                /* store new parameters to flash */
                                tof_config_params_set(&menu_cfg);

                        } else {
                                printf("\r\n**** Exiting configuration without update ****\r\n\r\n");
                        }
                } else {
                        printf("Invalid menu number %c\r\n", mc);
                }
        }
}

void ble_tof_cw_task(void *params)
{
        phase_meas_config_params_t meas_params;
        tof_config_params_t cfg_params;

        printf("\n\rToF application: %s %s\n\r", TOF_APP_NAME, TOF_APP_VERSION);

        /* initialize tof interface memory */
        tof_interface_init();

        /* read configuration parameters (role and set number) from non volatile memory
         * role and xtal trim settings can be overridden by matlab */
        tof_config_params_get(&cfg_params);

        tof_params->role = cfg_params.role;
        tof_params->set_number = cfg_params.set_number;
        tof_params->cw_offset = cfg_params.cw_offset;
        tof_params->xtal32m_trim_value = cfg_params.xtal32m_trim_value;

        /* check if button is pressed to enter configuration mode */
        bool k1 = tof_hw_k1_button_pressed();
        printf("k1 button %d\r\n", tof_hw_k1_button_pressed());
        if (k1) {
                tof_config_params_menu(&cfg_params);

                /* reboot after configuration to avoid issue with rf diagnostics irq not enabling
                 * after clock has settled (about 8s)
                 */
                OS_DELAY_MS(1000);
                hw_cpm_reboot_system();
        }

        tof_hw_rpi_set_antenna_switch(0);

        /* set cw distance offset in meters -- global variable for now */
        cw_distance_offset = ((float) cfg_params.cw_offset) / 100;
        printf("cw distance offset %.2f\r\n", cw_distance_offset);

        /*set default values */
        meas_params.dst_buffer = (uint32_t *)tof_data;
        meas_params.dst_buffer_size = RFMON_CFG_LEN_SMPL;

        meas_params.use_diversity = false;
        meas_params.meas_length_us = meas_params.use_diversity ? MEAS_LENGTH_US_DIVERSITY : MEAS_LENGTH_US_NORMAL;
        meas_params.agc_freeze_lvl = AGC_FREEZE_LEVEL;
        meas_params.use_auto_xtal_trim = cfg_params.flag_auto_xtal32_trim;
        meas_params.use_distance_average = cfg_params.flag_distance_averaging;

#ifdef MATLAB_MODE
        /* initialize exchange memory with default values */
        tof_params->f_start_mhz = MEAS_FREQ_START_MHZ;
        tof_params->f_step_mhz = MEAS_FREQ_STEP_MHZ;
        tof_params->nb_atoms = meas_params.dst_buffer_size / US_TO_SAMPLES(meas_params.meas_length_us);

        /* exchange tof interface parameters*/
        tof_interface_params_exchange();

        /* restrict nb_atoms to buffer size */
        if (tof_params->nb_atoms > meas_params.dst_buffer_size / US_TO_SAMPLES(meas_params.meas_length_us)){
                tof_params->nb_atoms = meas_params.dst_buffer_size / US_TO_SAMPLES(meas_params.meas_length_us);
        }

        /*take over the parameters */
        cfg_params.role = tof_params->role;
        cfg_params.xtal32m_trim_value = tof_params->xtal32m_trim_value;

        meas_params.f_start_mhz = tof_params->f_start_mhz;
        meas_params.f_step_mhz =  tof_params->f_step_mhz;
        meas_params.nb_atoms = tof_params->nb_atoms;

        /* assure number of atoms fits into given buffer size */
        OS_ASSERT(meas_params.nb_atoms <=  meas_params.dst_buffer_size / US_TO_SAMPLES(meas_params.meas_length_us));
#else
        meas_params.role = (cfg_params.role == TOF_ROLE_INITIATOR) ? USE_PONG : USE_PING;
        meas_params.f_start_mhz = MEAS_FREQ_START_MHZ;
        meas_params.f_step_mhz = MEAS_FREQ_STEP_MHZ;
        /* calculate number of atoms from given buffer size */
        meas_params.nb_atoms =  meas_params.dst_buffer_size / US_TO_SAMPLES(meas_params.meas_length_us);

#endif
        meas_params.role = (cfg_params.role == TOF_ROLE_INITIATOR) ? USE_PONG : USE_PING;

#if TOF_ENABLE_CW_DIST_CALC
        /* initialize cw distance calculation */
        cwd_init(meas_params.dst_buffer, cfg_params.role == TOF_ROLE_INITIATOR);
        meas_params.dst_buffer_size = cwd_set_n_atom(meas_params.nb_atoms);
        printf("initialized cw distance calculation with nb_atoms=%d and %d samples\n\r", meas_params.nb_atoms, meas_params.dst_buffer_size);
        iq_demux_init(meas_params.dst_buffer, meas_params.dst_buffer_size);
#endif

        configure_acquisition(meas_params);

        set_xtal_trim(cfg_params.xtal32m_trim_value);

        if (cfg_params.role == TOF_ROLE_INITIATOR) {
                ble_central_task((void *)&cfg_params.set_number);
        } else {
                ble_peripheral_task((void *)&cfg_params.set_number);
        }
}
