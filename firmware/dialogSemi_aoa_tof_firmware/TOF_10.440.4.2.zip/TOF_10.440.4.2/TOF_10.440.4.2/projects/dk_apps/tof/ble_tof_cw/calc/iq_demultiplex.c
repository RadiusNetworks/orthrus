/**
 ****************************************************************************************
 *
 * @file iq_demultiplex.c
 *
 * @brief Get IQ data from test bus data
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#if defined (MATLAB_MEX_FILE)
#   include "mex.h"
#   define DBG_PRINT(...)      mexPrintf(__VA_ARGS__)
#else
#   include <stdio.h>
#   define DBG_PRINT(...)      printf(__VA_ARGS__)
#endif


#include <stdint.h>
#include <stdio.h>
#include "iq_demultiplex.h"


/*context variable */

iq_demux_parm_t iq_demux_parm;


void iq_demux_init(uint32_t * p_test_bus_data, size_t nb_elements)
{
    iq_demux_parm.p_test_bus_data = p_test_bus_data;
    iq_demux_parm.nb_elements = nb_elements;
}

void iq_demultiplex(void)
{
    int16_t *p_iq = (int16_t*) iq_demux_parm.p_test_bus_data;
    iq_demux(iq_demux_parm.p_test_bus_data, iq_demux_parm.nb_elements, (int16_t *) p_iq);
}


/*
  This function demultiplexes the I/Q data from an uint32_t array.

   * pTestBusData   is a pointer to the uint32_t array
   * nb_elements    is the number of test bus samples
   * pIQData        pointer to a 16 bit I/Q array.

   Note:
    Function can operate in place and hence pTestBusData can be equal to pIQData.

   Step 1
    mask the 9 bit and shift bit 31(i) and 22 (q) to bit 15,
    so that the MSB of the 9th bit number is the MSB of the int16.
   Step 2:
    do arithmetic shift the data by another 7 bit right in order
    to get 9 bit signed integers which are in the range (-256, 255).
*/
int16_t * iq_demux(uint32_t * pTestBusData, size_t nb_elements, int16_t * pIQData)
{
    size_t idx;
    int16_t idata;
    int16_t qdata;
    int16_t *pIdata = (int16_t *) pIQData;
    int16_t *pQdata = pIdata+1;

    for (idx = 0; idx < nb_elements; idx++)
    {
        // conservative approach.
        idata = ((*pTestBusData & 0xff800000UL) >> 16);
        qdata = ((*pTestBusData & 0x007fC000UL) >> 7);
        *pQdata = (int16_t)(qdata/128);
        *pIdata = (int16_t)(idata/128);
        pQdata += 2;
        pIdata += 2;
        pTestBusData += 1;
    }

    return pIQData;
}
