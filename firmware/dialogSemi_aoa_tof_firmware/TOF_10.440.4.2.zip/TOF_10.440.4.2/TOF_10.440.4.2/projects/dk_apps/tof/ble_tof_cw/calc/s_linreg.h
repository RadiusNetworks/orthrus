/**
 ****************************************************************************************
 *
 * @file s_linreg.h
 *
* @brief Simple linear fit implementation that fits y = mx + b to a given set
 *        of (x,y) data. Based on 5 different sums.
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <stdint.h>

/*
 * Simple linear fit of a given data set. Fit to y = mx + b.
 * arguments:
 *      n ..... number of data points
 *      x,y ... arrays of data
 *      *m .... output slope
 *      *b .... output intercept
 * return value:
 *      0 on success, !=0 on failure
 */
int s_linreg(int n, float *x, float *y, float *m, float *b, int nele);
