/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup STATIC_LABEL
 *
 * \brief Static label widget
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file static_label.h
 *
 * @brief Static label widget API
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef STATIC_LABEL_H_
#define STATIC_LABEL_H_

#include "stdlib.h"
#include "stdint.h"
#include "screen.h"
#include "common.h"

/**
 * \brief Static label type definition
 */
typedef struct {
        const char *text;               /**< Label text */
        const ui_align_t align;         /**< Label text alignment */
        const font_info_t *font;        /**< Pointer to the font descriptor */
        const gdi_scale_t scale;        /**< Scaling factor in tenths */
} ui_static_label_t;

/**
 * Static label object declaration macro
 */
#define __DECLARE_STATIC_LABEL(name, _color, _x, _y, _w, _h, _font, _text, _align, _scale)         \
        static const ui_static_label_t name##_properties = {                                       \
                .text = _text,                                                                     \
                .align = _align,                                                                   \
                .font = _font,                                                                     \
                .scale = _scale,                                                                   \
        };                                                                                         \
        INITIALISED_PRIVILEGED_DATA static ui_flags_t name##_flags = UI_FLAG_REDRAW | UI_FLAG_VISIBLE;\
        static const ui_screen_item_t name = {                                                     \
                .color = _color,                                                                   \
                .x = _x,                                                                           \
                .y = _y,                                                                           \
                .width = _w,                                                                       \
                .height = _h,                                                                      \
                .type = UI_STATIC_LABEL,                                                           \
                .properties = &(name##_properties),                                                \
                .status = NULL,                                                                    \
                .flags = &(name##_flags)                                                           \
        };

#define DECLARE_STATIC_LABEL(name, color, x, y, w, h, font, text, align)                           \
        __DECLARE_STATIC_LABEL(name, color, x, y, w, h, font, text, align, 10)

#define DECLARE_STATIC_LABEL_SCALED(name, color, x, y, w, h, font, text, align, scale)             \
        __DECLARE_STATIC_LABEL(name, color, x, y, w, h, font, text, align, scale)

/**
 * Draw static label widget
 *
 * \param [in] item pointer to suitable screen widget
 */
void ui_draw_static_label(const ui_screen_item_t *item);

#endif /* STATIC_LABEL_H_ */

/**
 * \}
 * \}
 * \}
 */
