/**
 * \addtogroup UI
 * \{
 * \addtogroup FONTS
 *
 * \brief Basic font data types
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file calibri_48_bold_digits_sep.h
 *
 * @brief Calibri 48px Bold Font definition
 *
 * Copyright (C) 2018 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef CALIBRI_48_BOLD_H_
#define CALIBRI_48_BOLD_H_

#include "fonts.h"

/**
 ****************************************************************************************
 * \name                          Font data for Calibri 18pt
 ****************************************************************************************
 * \{ */
/**
 * \brief Character bitmaps for Calibri 48pt
 */
extern const uint8_t calibri_48ptBitmaps[];

/**
 * \brief Font information for Calibri 48pt
 */
extern const font_info_t calibri_48ptFontInfo;

/**
 * \brief Character descriptors for Calibri 48pt
 */
extern const font_char_info_t calibri_48ptDescriptors[];
/** \} */

#endif /* CALIBRI_48_BOLD_H_ */


/**
 * \}
 * \}
 */
