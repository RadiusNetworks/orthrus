/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file text.c
 *
 * @brief Basic text drawing functions
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include "gdi.h"
#include "fonts.h"

static gdi_coord_t ui_font_width(const font_info_t *font, char const character, gdi_scale_t scale)
{
        uint8_t pos = character - font->start;
        gdi_coord_t width = (font->descriptor[pos].width * scale) / 10;

        return width;
}

gdi_coord_t ui_measure_string(const font_info_t *font, const char *str, uint8_t scale)
{
        gdi_coord_t len = 0;
        const char *cur_char = str;

        while (*cur_char) {
                if (*cur_char == ' ') {
                        len += (font->spaceWidth * scale) / 10;
                } else if (((uint8_t)font->start) <= ((uint8_t)*cur_char)
                        && ((uint8_t)*cur_char) <= ((uint8_t)font->end)) {
                        len += len == 0 ? 0 : font->kerning;
                        len += ui_font_width(font, *cur_char, scale);
                }
                cur_char++;
        }

        return len;
}

void ui_draw_string(gdi_color_t color, gdi_coord_t x, gdi_coord_t y, const font_info_t *font, const char *str, gdi_scale_t scale)
{
        gdi_coord_t x_offset = x;
        const char *cur_char = str;

        while (*cur_char) {
                if (*cur_char == ' ') {
#if HARDWARE_PLATFORM_USB_VB
                        x_offset -= (font->spaceWidth * scale) / 10;
#else
                        x_offset += (font->spaceWidth * scale) / 10;
#endif
                } else if (((uint8_t)font->start) <= ((uint8_t)*cur_char)
                        && ((uint8_t)*cur_char) <= ((uint8_t)font->end)) {
#if HARDWARE_PLATFORM_USB_VB
                        x_offset -= x_offset == x ? 0 : font->kerning;
                        x_offset -= gdi_draw_font(*cur_char, color, x_offset, y, scale, font);
#else
                        x_offset += x_offset == x ? 0 : font->kerning;
#if dg_configUSE_DT280QV10CT
                        x_offset += gdi_draw_font(*cur_char, color, y, x_offset, scale, font);
#else
                        x_offset += gdi_draw_font(*cur_char, color, x_offset, y, scale, font);
#endif
#endif /* HARDWARE_PLATFORM_USB_VA */
                }
                cur_char++;
        }
}

/**
 * \}
 * \}
 */
