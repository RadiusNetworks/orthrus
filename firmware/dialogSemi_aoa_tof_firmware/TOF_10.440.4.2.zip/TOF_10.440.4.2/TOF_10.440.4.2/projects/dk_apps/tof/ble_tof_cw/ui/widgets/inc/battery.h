/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup BATTERY
 *
 * \brief Battery widget
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file battery.h
 *
 * @brief Battery widget API
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef BATTERY_WIDGET_H_
#define BATTERY_WIDGET_H_

#include "stdlib.h"
#include "stdint.h"
#include "screen.h"
#include "common.h"

/**
 * \brief Battery states definition
 */
typedef enum {
        UI_BATTERY_NOT_CHARGING,
        UI_BATTERY_CHARGING,
        UI_BATTERY_WARNING,
} ui_battery_state_t;

#define BATTERY_WIDTH           (24)
#define BATTERY_HEIGHT          (12)

/**
 * \brief Battery widget type definition
 */
typedef struct {
        uint8_t level;
        ui_battery_state_t state;
} ui_battery_widget_t;

/**
 * Battery widget declaration macro
 */
#define DECLARE_BATTERY_WIDGET(name, _x, _y, _level)                                               \
        INITIALISED_PRIVILEGED_DATA static ui_battery_widget_t name##_status = {                   \
                .level = _level,                                                                   \
                .state = UI_BATTERY_NOT_CHARGING,                                                  \
        };                                                                                         \
        INITIALISED_PRIVILEGED_DATA static ui_flags_t name##_flags = UI_FLAG_REDRAW | UI_FLAG_VISIBLE;\
        static const ui_screen_item_t name = {                                                     \
                .x = _x,                                                                           \
                .y = _y,                                                                           \
                .width = BATTERY_WIDTH,                                                            \
                .height = BATTERY_HEIGHT,                                                          \
                .type = UI_BATTERY_WIDGET,                                                         \
                .properties = NULL,                                                                \
                .status = &(name##_status),                                                        \
                .flags = &(name##_flags)                                                           \
        };

/**
 * Draw battery widget
 *
 * \param [in] item pointer to suitable screen widget
 * \param [in] x    x coordinate of the widget
 * \param [in] y    y coordinate of the widget
 */
void ui_draw_battery(const ui_screen_item_t *item, gdi_coord_t x, gdi_coord_t y);

/**
 * Set battery level
 *
 * \param [in] item  pointer to suitable screen widget
 * \param [in] level battery level from 0 to 100
 */
void ui_battery_widget_set_level(const ui_screen_item_t *item, uint8_t level);

/**
 * Set battery charging state
 *
 * \param [in] item  pointer to suitable screen widget
 * \param [in] state battery charging state: UI_BATTERY_NOT_CHARGING or UI_BATTERY_CHARGING
 */
void ui_battery_widget_set_state(const ui_screen_item_t *item, ui_battery_state_t state);

#endif /* BATTERY_WIDGET_H_ */

/**
 * \}
 * \}
 * \}
 */
