/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup SCREEN
 *
 * \brief Screen widget
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file screen.h
 *
 * @brief Screen widget API
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef SCREEN_H_
#define SCREEN_H_

#include "stdlib.h"
#include "stdint.h"
#include "common.h"
#include "stdbool.h"
#include "gdi.h"
#include "status_bar.h"

typedef void (*on_main_cb_t)(void *user_data);

/**
 * \brief Screen type definition
 */
typedef struct {
        uint8_t *flags;
        const ui_screen_item_t* const *items;
        void *param;
        on_main_cb_t on_main;
} ui_screen_t;

/**
 * \brief Screen object declaration macros
 */
#define DECLARE_SCREEN_BEGIN(name, on_main_cb, status_bar_supported)                               \
        static const ui_screen_item_t* const name##_items[];                                       \
        PRIVILEGED_DATA static void* name##_param;                                                 \
        INITIALISED_PRIVILEGED_DATA static ui_flags_t name##_flags =                               \
                UI_FLAG_REDRAW | (status_bar_supported ? UI_FLAG_STATUS_BAR : 0);                  \
        static const ui_screen_t name = {                                                          \
                &(name##_flags),                                                                   \
                name##_items,                                                                      \
                &(name##_param),                                                                   \
                on_main_cb                                                                         \
        };                                                                                         \
        static const ui_screen_item_t* const name##_items[] = {

#define DECLARE_SCREEN_OBJECT(name) &(name),

#define DECLARE_SCREEN_END() NULL };

/**
 * \brief Set active screen
 *
 * \param [in] screen pointer to suitable screen
 */
void ui_set_active_screen(const ui_screen_t * const screen);

/**
 * \brief Draw active screen
 *
 * \param [in] force_redraw true if screen should be redraw
 */
void ui_draw_active_screen(bool force_redraw);

/**
 * \brief Switch to left screen using swipe animation
 *
 * \param [in] screen pointer to suitable screen
 */
void ui_swipe_left(const ui_screen_t * const screen);

/**
 * \brief Switch to right screen using swipe animation
 *
 * \param [in] screen pointer to suitable screen
 */
void ui_swipe_right(const ui_screen_t * const screen);

/**
 * \brief Switch to next screen using swipe up animation
 *
 * \param [in] screen pointer to suitable screen
 */
void ui_swipe_up(const ui_screen_t * const screen);

/**
 * \brief Switch to previous screen using swipe down animation
 *
 * \param [in] screen pointer to suitable screen
 */
void ui_swipe_down(const ui_screen_t * const screen);

/**
 * \brief Set visibility state of screen widget
 *
 * \param [in] item        pointer to suitable screen widget
 * \param [in] visibility  visibility state of screen widget
 */
void ui_set_item_visibility(const ui_screen_item_t * const item, bool visibility);

/**
 * \brief Get visibility state of screen widget
 *
 * \param [in]  item        pointer to suitable screen widget
 *
 * \return visibility state of screen widget
 */
bool ui_get_item_visibility(const ui_screen_item_t * const item);

/**
 * \brief Set validity state of screen widget
 *
 * \param [in] item        pointer to suitable screen widget
 * \param [in] validity    validity state of screen widget
 */
void ui_set_item_validity(const ui_screen_item_t * const item, bool validity);

/**
 * \brief Get validity state of screen widget
 *
 * \param [in]  item        pointer to suitable screen widget
 *
 * \return validity state of screen widget
 */
bool ui_get_item_validity(const ui_screen_item_t * const item);

/**
 * \brief Set blinking state of screen widget
 *
 * \param [in] item        pointer to suitable screen widget
 * \param [in] blinking    blinking state of screen widget
 */
void ui_set_item_blinking(const ui_screen_item_t * const item, bool blinking);

/**
 * \brief Get blinking state of screen widget
 *
 * \param [in]  item        pointer to suitable screen widget
 *
 * \return blinking state of screen widget
 */
bool ui_get_item_blinking(const ui_screen_item_t * const item);

/**
 * \brief Toggle visibility state of screen widget
 *
 * \param [in] item  pointer to suitable screen widget
 */
void ui_toggle_item_visibility(const ui_screen_item_t * const item);

/**
 * \brief Register status bar
 *
 * \param [in] bar  pointer to status bar widget
 */
void ui_register_status_bar(ui_status_bar_t *bar);

/**
 * \brief Unregister status bar
 */
void ui_unregister_status_bar(void);

#endif /* SCREEN_H_ */

/**
 * \}
 * \}
 * \}
 */
