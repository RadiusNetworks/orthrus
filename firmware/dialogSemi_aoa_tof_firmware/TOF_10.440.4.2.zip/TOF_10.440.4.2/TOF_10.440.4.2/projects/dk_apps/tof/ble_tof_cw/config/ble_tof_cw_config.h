/**
 ****************************************************************************************
 *
 * @file ble_tof_cw_task.h
 *
 * @brief Code related to BLE ToF CW demo
 *
 * Copyright (C) 2015 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef BLE_TOF_CW_CONFIG_H_
#define BLE_TOF_CW_CONFIG_H_

/* Must be defined if program is connected to Matlab */
//#define MATLAB_MODE (1)
#undef MATLAB_MODE

#if defined(MATLAB_MODE)
        #define DEFAULT_TOF_ROLE                                TOF_ROLE_UNDEFINED
#else
        #define DEFAULT_TOF_ROLE                                TOF_ROLE_INITIATOR
        //#define DEFAULT_TOF_ROLE                                TOF_ROLE_RESPONDER
#endif

/* When set central does not scan but waits for cli commands
 * set address, start, stop and acts accordingly
 */
#define CLI_MODE                        (0)

/* note: initially it was thought to have this vars in the eclipse parameters,
 * however it was not possible to handover string variables to the makefile
 * (because last \" was ommited) - so we define it here for now.*/
#define TOF_APP_NAME "ble_tof_cw"
#define TOF_APP_VERSION "v2.2"

/* if set pins P1_02, P1_03 will be used to measure synchronization jitter */
#define TOF_ENABLE_JITTER_STATS         (0)

/* perform distance calculation in firmware, if defined */
#define TOF_ENABLE_CW_DIST_CALC         (1)

#define TOF_ENABLE_IFFT_DIST_CALC       (1)

/* this feature auto-tunes the XTAL_TRIM register in order to
 *  minimize the frequency offset.
 */
#define TOF_ENABLE_AUTO_XTAL_TRIM       (1)

/* this feature applies a 4 value sliding average
 *  on the raw distance values.
 */
#define TOF_ENABLE_DISTANCE_AVG         (1)

/* Demo set number for future support of multiple demo sets */
#define TOF_MAX_SET_NUM                                 (255)
#define DEFAULT_TOF_SET_NUM                             (0)

#define DEFAULT_TOF_XTAL32M_TRIM                        (0x120)

/* this value is added to the current evt_counter in order to calculate the "measurement" event
 * - found that TOF_EVT_MEAS_OFFSET = 5 is currently achievable minimum  */
#define TOF_EVT_MEAS_OFFSET                             (5)

#define BLE_CONN_INTERVAL_MIN                           (BLE_CONN_INTERVAL_FROM_MS(60))
#define BLE_CONN_INTERVAL_MAX                           (BLE_CONN_INTERVAL_FROM_MS(60))
#define BLE_CONN_SLAVE_LATENCY                          (0)
#define BLE_CONN_SUPERVISION_TO                         (BLE_CONN_INTERVAL_MIN * 4)

#define BLE_SCAN_INTERVAL                               (BLE_SCAN_INTERVAL_FROM_MS(30))
#define BLE_SCAN_WINDOW                                 (BLE_SCAN_WINDOW_FROM_MS(30))

/* Timeout for connection attempts in CLI_MODE */
#define BLE_CONNECTION_TO_MS  (10000)

#define USE_RANDOM_BD_ADDRESS                           (1)

#endif /* BLE_TOF_CW_CONFIG_H_*/
