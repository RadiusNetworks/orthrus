/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 *
 * \brief UI widgets
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file common.h
 *
 * @brief Common widgets definitions
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef COMMON_H_
#define COMMON_H_

#include "fonts.h"
#include "gdi.h"

/**
 * \brief Screen item flags definition
 */
typedef enum {
        UI_FLAG_NONE       = 0,
        UI_FLAG_REDRAW     = (1 << 0),
        UI_FLAG_VISIBLE    = (1 << 1),
        UI_FLAG_STATUS_BAR = (1 << 2),
        UI_FLAG_BLINKING   = (1 << 3),
        UI_FLAG_VALID      = (1 << 4),
        UI_FLAG_RECOLOR    = (1 << 5),
} ui_flags_t;

#define UI_IS_FLAG_SET(item, flag)    ((*((item)->flags) & flag) == flag ? 1 : 0)
#define UI_SET_FLAG(item, flag)       (*((item)->flags) |= flag)
#define UI_CLEAR_FLAG(item, flag)     (*((item)->flags) &= ~flag)

/**
 * \brief UI item border definition
 */
enum {
        UI_NO_BORDER,
        UI_BORDER
};

/**
 * \brief Text alignment definition
 */
typedef enum {
        UI_ALIGN_LEFT,
        UI_ALIGN_CENTER,
        UI_ALIGN_RIGHT,
} ui_align_t;

/**
 * \brief Screen item types definition
 */
typedef enum {
        UI_STATIC_LABEL,
        UI_CIRCLE_PROGRESS_BAR,
        UI_TEXTBOX,
        UI_IMAGE,
        UI_BATTERY_WIDGET,
        UI_ANALOG_CLOCK,
} ui_item_type_t;

/**
 * \brief Screen item type definition
 */
typedef struct {
        gdi_coord_t x;
        gdi_coord_t y;
        gdi_coord_t width;
        gdi_coord_t height;
        gdi_color_t color;
        ui_item_type_t type;
        const void *properties;
        void *status;
        ui_flags_t *flags;
} ui_screen_item_t;

/**
 * Measure the string length
 *
 * \param [in] font pointer to the font definition
 * \param [in] str pointer to the string
 *
 * return string length in pixels
 */
gdi_coord_t ui_measure_string(const font_info_t *font, const char *str, gdi_scale_t scale);

/**
 * Draw string
 *
 * \param [in] x upper left corner x coordinate
 * \param [in] y upper left corner y coordinate
 * \param [in] font pointer to the font definition
 * \param [in] str pointer to the string
 */
void ui_draw_string(gdi_color_t color, gdi_coord_t x, gdi_coord_t y, const font_info_t *font, const char *str, gdi_scale_t scale);

#endif /* COMMON_H_ */

/**
 * \}
 * \}
 */
