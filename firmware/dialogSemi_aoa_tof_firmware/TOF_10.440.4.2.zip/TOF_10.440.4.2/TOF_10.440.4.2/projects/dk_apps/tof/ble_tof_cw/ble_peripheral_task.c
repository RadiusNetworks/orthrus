/**
 ****************************************************************************************
 *
 * @file ble_peripheral_task.c
 *
 * @brief BLE peripheral task
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "osal.h"
#include "sys_watchdog.h"
#include "sys_clock_mgr.h"
#include "ble_service.h"
#include "ble_uuid.h"
#include "ble_bufops.h"
#include "sys_trng.h"

#include "ble_mgr.h"
#include "ble_tof.h"
#include "ble_tof_sync.h"
#include "user_config_defs.h"
#include "tof_interface.h"
#include "tof_hw.h"
#include "ble_tof_cw_config.h"

#if TOF_ENABLE_CW_DIST_CALC
#include "iq_demultiplex.h"
#include "cw_distance.h"
#endif
#include "acquisition.h"

/*
 * Notification bits reservation
 * bit #0 is always assigned to BLE event queue notification
 * bit #5 is always assigned to ToF synchronization end notification
 */

static const char device_name[BLE_GAP_DEVNAME_LEN_MAX] = "ToF Peripheral";

/* Use 4 byte alignment to avoid the unpacking of phase values for calculations */
PRIVILEGED_DATA static tof_result_t i_result __ALIGNED(4);              // initiator result
PRIVILEGED_DATA static tof_result_t r_result __ALIGNED(4);              // responder result

INITIALISED_PRIVILEGED_DATA static uint16_t evt_counter = 0;            // next event counter after synchronization end
INITIALISED_PRIVILEGED_DATA static uint16_t cw_evt_counter = 0;         // event counter for cw measurement
INITIALISED_PRIVILEGED_DATA static uint16_t to_evt_counter = 0;         // timeout event counter for remote results

/*
 * BLE peripheral advertising data
 */
INITIALISED_PRIVILEGED_DATA static uint8_t adv_data[] = {
        0x07, GAP_DATA_TYPE_LOCAL_NAME,
        'R', 'a', 'n', 'g', 'e', 'P',
        0x12, GAP_DATA_TYPE_UUID128_SVC_DATA,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, /* 16 bytes reserved for UUID */
        1, /* set number */
};

PRIVILEGED_DATA static OS_TASK ble_peripheral_task_handle;

extern float cw_distance_offset; /* in meters */

struct peripheral_context {

        ble_service_t svc;

        uint16_t conn_idx;

        tof_status_t tof_status;
        tof_error_t tof_err_code;
        uint16_t tof_value;

        // handles
        uint16_t tof_status_val_h;
        uint16_t tof_status_ccc_h;
        uint16_t tof_i_result_val_h;
        uint16_t tof_r_result_val_h;
        uint16_t tof_r_result_ccc_h;
        uint16_t tof_value_val_h;

        uint8_t conf_set_number;
};

INITIALISED_PRIVILEGED_DATA static struct peripheral_context ctx = {0};

static void update_tof_status(tof_status_t status);
static void handle_tof_results_write_req();
static void handle_tof_status_write_req(tof_status_pdu_t *pdu);
static void handle_tof_value_write_req(uint16_t value);

/*
 * BLE peripheral advertising data
 */
static void set_adv_data()
{
        uint8_t uuid128_data_index;
        att_uuid_t uuid;

        /* TLV: GAP_DATA_TYPE_UUID128_SVC_DATA */
        ble_uuid_from_string(UUID_TOF_SERVICE, &uuid);
        uuid128_data_index = sizeof(adv_data) - sizeof(uuid.uuid128) - 1;
        memcpy(&adv_data[uuid128_data_index], uuid.uuid128, sizeof(uuid.uuid128));

        /*put set number in last byte of advertising data after service UUID */
        adv_data[sizeof(adv_data) - 1] = ctx.conf_set_number;
        ble_gap_adv_data_set(sizeof(adv_data), adv_data, 0, NULL);
}

static void start_advertising()
{
        printf("Start advertising...\r\n");
        ble_gap_adv_start(GAP_CONN_MODE_UNDIRECTED);
}

static void handle_evt_gap_adv_completed(ble_evt_gap_adv_completed_t *evt)
{
        printf("Advertising completed\r\n");
}

static void handle_evt_gap_connected(ble_evt_gap_connected_t *evt)
{
        printf("Connected\r\n");

        ctx.conn_idx = evt->conn_idx;
}

static void handle_evt_gap_disconnected(ble_evt_gap_disconnected_t *evt)
{
        ble_error_t err;
        ble_dev_params_t *params;
        bool scanning;

        printf("Disconnected\r\n");

        ble_tof_sync_stop();
        ble_tof_cw_stop();
        update_tof_status(TOF_STATUS_STOP);

        /* reset connection event counter */
        cmac_info_table_ptr->ble_conn_evt_counter[ctx.conn_idx] = 0;

        ctx.conn_idx = BLE_CONN_IDX_INVALID;

        /* restart advertising so we can connect again */
        start_advertising();
}

static void handle_read_req(ble_service_t *svc, const ble_evt_gatts_read_req_t *evt)
{

        ble_gatts_read_cfm(evt->conn_idx, evt->handle, ATT_ERROR_READ_NOT_PERMITTED, 0, NULL);
}

static void handle_write_req(ble_service_t *svc, const ble_evt_gatts_write_req_t *evt)
{
        att_error_t status = ATT_ERROR_ATTRIBUTE_NOT_FOUND;

        if (evt->handle == ctx.tof_value_val_h) {
                if (evt->length == sizeof(uint16_t)) {
                        uint16_t value = get_u16(evt->value);
                        handle_tof_value_write_req(value);
                        status = ATT_ERROR_OK;
                } else  {
                        status = ATT_ERROR_INVALID_VALUE_LENGTH;
                }
        }

        if (evt->handle == ctx.tof_i_result_val_h) {
                if (evt->length == sizeof(tof_result_t)) {
                        handle_tof_results_write_req((tof_result_t *) evt->value);
                        status = ATT_ERROR_OK;
                } else  {
                        status = ATT_ERROR_INVALID_VALUE_LENGTH;
                }
        }

        if (evt->handle == ctx.tof_status_val_h) {
                tof_status_pdu_t *pdu = (tof_status_pdu_t *) evt->value;

                if (evt->length == sizeof(tof_status_pdu_t)) {
                        handle_tof_status_write_req(pdu);
                        status = ATT_ERROR_OK;
                } else  {
                        status = ATT_ERROR_INVALID_VALUE_LENGTH;
                }
        }

        if (evt->handle == ctx.tof_status_ccc_h) {
                if (evt->length == sizeof(uint16_t)) {
                        status = ATT_ERROR_OK;
                } else {
                        status = ATT_ERROR_INVALID_VALUE_LENGTH;
                }
        }

        if (evt->handle == ctx.tof_r_result_ccc_h) {
                if (evt->length == sizeof(uint16_t)) {
                        status = ATT_ERROR_OK;
                } else {
                        status = ATT_ERROR_INVALID_VALUE_LENGTH;
                }
        }

        if (status != ATT_ERROR_OK) {
                printf("write error %d status %d\r\n", evt->handle, status);
        }
        ble_gatts_write_cfm(evt->conn_idx, evt->handle, status);
}

/*
 * Custom range measurement service data
 */
static void tof_service_init(void)
{
        att_uuid_t uuid;
        uint16_t num_attr;

        ctx.svc.read_req = handle_read_req;
        ctx.svc.write_req = handle_write_req;

        num_attr = ble_gatts_get_num_attr(0, 4, 2);

        ble_uuid_from_string(UUID_TOF_SERVICE, &uuid);
        ble_gatts_add_service(&uuid, GATT_SERVICE_PRIMARY, num_attr);

        ble_uuid_from_string(UUID_TOF_STATUS, &uuid);
        ble_gatts_add_characteristic(&uuid, GATT_PROP_WRITE | GATT_PROP_WRITE_NO_RESP | GATT_PROP_NOTIFY,
                                           ATT_PERM_WRITE, sizeof(tof_status_pdu_t), 0, NULL,
                                                                           &ctx.tof_status_val_h);

        ble_uuid_create16(UUID_GATT_CLIENT_CHAR_CONFIGURATION, &uuid);
        ble_gatts_add_descriptor(&uuid, ATT_PERM_RW, sizeof(uint16_t), 0, &ctx.tof_status_ccc_h);

        ble_uuid_from_string(UUID_TOF_I_RESULT, &uuid);
        ble_gatts_add_characteristic(&uuid, GATT_PROP_WRITE | GATT_PROP_WRITE_NO_RESP, ATT_PERM_WRITE,
                                                sizeof(tof_result_t), 0, NULL, &ctx.tof_i_result_val_h);

        ble_uuid_from_string(UUID_TOF_R_RESULT, &uuid);
        ble_gatts_add_characteristic(&uuid, GATT_PROP_NOTIFY, ATT_PERM_NONE,
                                                sizeof(tof_result_t), 0, NULL, &ctx.tof_r_result_val_h);

        ble_uuid_create16(UUID_GATT_CLIENT_CHAR_CONFIGURATION, &uuid);
        ble_gatts_add_descriptor(&uuid, ATT_PERM_RW, sizeof(uint16_t), 0, &ctx.tof_r_result_ccc_h);

        ble_uuid_from_string(UUID_TOF_VALUE, &uuid);
        ble_gatts_add_characteristic(&uuid, GATT_PROP_WRITE , ATT_PERM_WRITE,
                                                sizeof(uint16_t), 0, NULL, &ctx.tof_value_val_h);


        ble_gatts_register_service(&ctx.svc.start_h, &ctx.tof_status_val_h,
                                                     &ctx.tof_status_ccc_h,
                                                     &ctx.tof_i_result_val_h,
                                                     &ctx.tof_r_result_val_h,
                                                     &ctx.tof_r_result_ccc_h,
                                                     &ctx.tof_value_val_h, 0);
        ctx.svc.end_h = ctx.svc.start_h + num_attr;

        ble_service_add(&ctx.svc);
}

static void calc_phases()
{
        /* get agc gain from acquisition results */
        r_result.AGC_gain = get_acquisition_agc_value();
#if TOF_ENABLE_CW_DIST_CALC
        //GPIO->P1_05_MODE_REG = 0x300;
        //GPIO->P1_SET_DATA_REG = 1 << 5;         // P1_05 high

        cm_sys_clk_set(sysclk_PLL96);

        iq_demultiplex();
#if TOF_ENABLE_IFFT_DIST_CALC
        r_result.f_offset = roundf(cwd_calc_phase_mag_data(r_result.phase, r_result.amplitude));
        tof_params->mag_data = (uint32_t)r_result.amplitude;
#else
        r_result.f_offset = roundf(cwd_calc_phase_data(r_result.phase));
#endif /* TOF_ENABLE_IFFT_DIST_CALC */
        tof_params->phase_data = (uint32_t)r_result.phase;

#if !defined(MATLAB_MODE)
        /* PC may read phase data now */
        tof_params->fw_ready = 1;
#endif

        cm_sys_clk_set(sysclk_XTAL32M);

        //GPIO->P1_RESET_DATA_REG = 1 << 5;       // P1_05 low

#else
        /*
         * Simulate delay for first computations
         * that produce the phase results
         */
        OS_DELAY_MS(50);
#endif
}

static void send_results(uint16_t evt_counter, tof_result_t *result)
{
        /* send results */
        result->event_counter = evt_counter - 1;
        result->measure_id = 0;
        ble_gatts_send_event(ctx.conn_idx, ctx.tof_r_result_val_h,
                GATT_EVENT_NOTIFICATION, sizeof(tof_result_t), result);
}

static void send_tof_stop(tof_error_t err_code)
{
        tof_status_pdu_t pdu;

        /* update error code */
        ctx.tof_err_code = err_code;

        /* prepare status pdu */
        pdu.event_counter = cmac_info_table_ptr->ble_conn_evt_counter[ctx.conn_idx] + 1;
        pdu.err_code = err_code;
        pdu.status = TOF_STATUS_STOP;

        ble_gatts_send_event(ctx.conn_idx, ctx.tof_status_val_h, GATT_EVENT_NOTIFICATION,
                                                        sizeof(tof_status_pdu_t), (uint8_t *) &pdu);
}

static void handle_tof_value_write_req(uint16_t value)
{
        ctx.tof_value = value;
        printf("Range: %d\r\n",ctx.tof_value);
        update_tof_status(TOF_STATUS_STOP);
}

static void handle_tof_status_write_req(tof_status_pdu_t *pdu)
{
        if (pdu->status == TOF_STATUS_START) {
                cw_evt_counter = pdu->event_counter;
                //printf("next start %d, cur %d\r\n", cw_evt_counter, evt_counter);
                if (!ble_tof_sync_active()) {
                        ble_tof_sync_start();
                }
                update_tof_status(pdu->status);
        } else {
                printf("unexpected status %d\r\n", pdu->status);
        }
}

static void handle_tof_results_write_req(tof_result_t *result)
{
        //printf("results received\r\n");

        if (ctx.tof_status == TOF_STATUS_CALC) {

                memcpy(&i_result, result, sizeof(tof_result_t));

#if TOF_ENABLE_CW_DIST_CALC

#if TOF_ENABLE_IFFT_DIST_CALC
                float distance = cwd_calc_ifft_distance_phase_mag(i_result.phase, i_result.amplitude, r_result.phase, r_result.amplitude);
#else
                float distance = cwd_calc_distance(i_result.phase, r_result.phase);
#endif /* TOF_ENABLE_IFFT_DIST_CALC */

                uint8_t dqf = cwd_calc_dqf(i_result.f_offset, r_result.f_offset);

                /* update distance with cw offset */
                distance = distance - cw_distance_offset;
                if (distance < 0) {
                        distance = 0;
                }

#if TOF_ENABLE_DISTANCE_AVG
                float avg_dist = calc_distance_average(distance, dqf);

#else
                float avg_dist = distance;
#endif


#if TOF_ENABLE_AUTO_XTAL_TRIM
                if (dqf != 0)
                {
                        static uint16_t xtrim = 0;
                        uint16_t new_xtrim = tune_xtal_trim(i_result.f_offset, 3.0);
                        if (xtrim != new_xtrim) {
                                printf("xtrim: %d => %d\n\r", xtrim, new_xtrim);
                                xtrim =  new_xtrim;
                        }
                }
#endif

                printf("\n\r**** distance: %.2f, avg_dist: %.2f, event: %d, fo_i: %d, fo_r: %d, agc_i: %d, agc_r: %d, dqf: %d\n\n\r",
                        distance, avg_dist, i_result.event_counter, i_result.f_offset, r_result.f_offset, i_result.AGC_gain, r_result.AGC_gain, dqf);
                tof_interface_update_c_results(i_result.event_counter, distance);

                char disp_str[8];

                if ((dqf != 0) && (avg_dist < 40)) {
                        /* show valid results on display, only */
                        sprintf(disp_str,"%.1f", avg_dist);
                        tof_lcd_draw_string(disp_str);
                }

#else

                /*
                 * Simulate delay for computing result
                 */
                OS_DELAY_MS(5);
#endif
                update_tof_status(TOF_STATUS_STOP);

                /* wait for next start from initiator */
        } else {
                printf("results received with status %d\r\n", ctx.tof_status);
        }
}

static void handle_tof_start()
{
        /* reset error code */
        ctx.tof_err_code = TOF_NO_ERROR;
}

static void handle_tof_sync()
{
}

static void handle_tof_calc()
{
        calc_phases();
        send_results(evt_counter, &r_result);
}

static void update_tof_status(tof_status_t status)
{
        bool invalid_transition = false;

        dbg_printf("ToF Status: %d\r\n", status);

        switch (status) {
        case TOF_STATUS_START:
                if (ctx.tof_status == TOF_STATUS_STOP) {
                       handle_tof_start();

                } else {
                        invalid_transition = true;
                }
                break;
        case TOF_STATUS_SYNC:
                if (ctx.tof_status == TOF_STATUS_START) {
                        handle_tof_sync();

                } else {
                        invalid_transition = true;
                }
                break;
        case TOF_STATUS_CALC:
                if (ctx.tof_status == TOF_STATUS_SYNC) {
                              handle_tof_calc();
                } else {
                        invalid_transition = true;
                }
                break;
        case TOF_STATUS_STOP:
                break;
        default:
                invalid_transition = true;
                break;
        }

        if (!invalid_transition) {
                ctx.tof_status = status;
        } else {
                printf("Invalid status transition from %d to %d\r\n", ctx.tof_status, status);
        }
}

static void handle_tof_sync_end_notification(uint16_t evt_counter)
{
        switch (ctx.tof_status ) {
        case TOF_STATUS_START:
                if (evt_counter == cw_evt_counter) {
                        ble_tof_cw_start();
                        update_tof_status(TOF_STATUS_SYNC);
                } else if (evt_counter > cw_evt_counter) {
                        printf("instant passed evt %d cw %d\r\n", evt_counter, cw_evt_counter);
                        /* Notify initiator that measurement has stopped */
                        send_tof_stop(TOF_ERROR_INSTANT_PASSED);
                        update_tof_status(TOF_STATUS_STOP);
                }
                break;
        case TOF_STATUS_SYNC:
                ble_tof_cw_stop();

#ifdef MATLAB_MODE
                /* notify matalb that data are ready */
                tof_interface_data_exchange(evt_counter);
#endif

                /* check if event counter is the correct one or there was an rx failure */
                if (evt_counter != cw_evt_counter + 1) {
                        printf("sync failed evt %d cw %d\r\n", evt_counter, cw_evt_counter);
                        /* Notify initiator that measurement has stopped */
                        send_tof_stop(TOF_ERROR_SYNC_FAILED);
                        update_tof_status(TOF_STATUS_STOP);
                } else {
                        update_tof_status(TOF_STATUS_CALC);

                        /* set timeout for responder results */
                        to_evt_counter = evt_counter + TOF_EVT_MEAS_OFFSET;
                }
                break;

        case TOF_STATUS_CALC:
                if (evt_counter == to_evt_counter) {
                        printf("results timeout\r\n");
                        /* Notify initiator that measurement has stopped */
                        send_tof_stop(TOF_ERROR_RESULTS_TO);
                        update_tof_status(TOF_STATUS_STOP);
                }
                break;
        case TOF_STATUS_STOP:
                /* waiting for next start */
                break;
        default:
                printf("not handled status %d\r\n", ctx.tof_status);
                break;
        }
}

extern void update_bd_address(void);

/*
 * Main code
 */
void ble_peripheral_task(void *params)
{
        int8_t wdog_id;
        ble_service_t *svc;
        // in case services which do not use svc are all disabled, just surpress -Wunused-variable
        (void) svc;

        printf("Ble peripheral task started\r\n");
        ble_peripheral_task_handle = OS_GET_CURRENT_TASK();

        /* register ble_peripheral task to be monitored by watchdog */
        wdog_id = sys_watchdog_register(false);

        /* configure_device_as_a_BLE peripheral */
        ble_gap_role_set(GAP_PERIPHERAL_ROLE);
        ble_register_app();

        update_bd_address();

        /* keep ble active */
        //ad_ble_stay_active(true);

        ble_tof_sync_init(TOF_ROLE_RESPONDER, ble_peripheral_task_handle);

        printf("device name: %s\r\n", device_name);
        ble_gap_device_name_set(device_name, ATT_PERM_READ);

        /* Set maximum allowed MTU to increase results throughput.
         * Max data packet payload is 251 bytes.
         */
        ble_gap_mtu_size_set(512);

        /* register custom range measurement service */
        tof_service_init();

        ctx.tof_status = TOF_STATUS_STOP;
        ctx.conn_idx = BLE_CONN_IDX_INVALID;
        ctx.conf_set_number = *(uint8_t*)params;

        set_adv_data();
        start_advertising();

        for (;;) {
                OS_BASE_TYPE ret;
                uint32_t notif;

                /* notify watchdog on each loop */
                sys_watchdog_notify(wdog_id);

                /* suspend watchdog while blocking on OS_TASK_NOTIFY_WAIT() */
                sys_watchdog_suspend(wdog_id);

                /*
                 * Wait on any of the notification bits, then clear them all
                 */
                ret = OS_TASK_NOTIFY_WAIT(0, OS_TASK_NOTIFY_ALL_BITS, &notif, OS_TASK_NOTIFY_FOREVER);
                /* Blocks forever waiting for task notification. The return value must be OS_OK */
                OS_ASSERT(ret == OS_OK);

                /* resume watchdog */
                sys_watchdog_notify_and_resume(wdog_id);

                /* notified from BLE manager, can get event */
                if (notif & BLE_APP_NOTIFY_MASK) {
                        ble_evt_hdr_t *hdr;

                        hdr = ble_get_event(false);
                        if (!hdr) {
                                goto no_event;
                        }

                        if (ble_service_handle_event(hdr)) {
                                goto handled;
                        }

                        switch (hdr->evt_code) {
                        case BLE_EVT_GAP_CONNECTED:
                                handle_evt_gap_connected((ble_evt_gap_connected_t *) hdr);
                                break;
                        case BLE_EVT_GAP_DISCONNECTED:
                                handle_evt_gap_disconnected((ble_evt_gap_disconnected_t *) hdr);
                                break;
                        case BLE_EVT_GAP_ADV_COMPLETED:
                                handle_evt_gap_adv_completed((ble_evt_gap_adv_completed_t *) hdr);
                                break;
                        default:
                                ble_handle_event_default(hdr);
                                break;
                        }

handled:
                        OS_FREE(hdr);

no_event:
                        // notify again if there are more events to process in queue
                        if (ble_has_event()) {
                                OS_TASK_NOTIFY(OS_GET_CURRENT_TASK(), BLE_APP_NOTIFY_MASK, eSetBits);
                        }
                }

                if (notif & TOF_SYNC_END_NOTIF) {
                        if (ctx.conn_idx != BLE_CONN_IDX_INVALID) {
                                /* update event counter */
                                evt_counter =  cmac_info_table_ptr->ble_conn_evt_counter[ctx.conn_idx];

                                handle_tof_sync_end_notification(evt_counter);

                                //printf("event counter %d\r\n", evt_counter);
                        }
                }
        }
}
