/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 *
 * \brief UI widgets
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file ui_widgets.h
 *
 * @brief All UI widgets elements
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef UI_WIDGETS_H_
#define UI_WIDGETS_H_

#include "screen.h"
#include "image.h"
#include "static_label.h"
#include "textbox.h"
#include "circle_progress_bar.h"
#include "battery.h"
#include "status_bar.h"

#endif /* UI_WIDGETS_H_ */

/**
 * \}
 * \}
 */
