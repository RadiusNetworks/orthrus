/**
 * \addtogroup UI
 * \{
 * \addtogroup MATH_2D
 *
 * \brief 2D fixed point math
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file math_2d.h
 *
 * @brief 2D fixed point math functions API
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef MATH_2D_H_
#define MATH_2D_H_

#include "stdint.h"

/**
 * Convert deg angle of 0..360 to internal representation (0..255)
 */
#define MATH2D_ANGLE_DEG(deg) (((deg) == 360) ? 0xff : ((deg) * 0x100 / 360))

/**
 * \brief Sine trigonometric function
 * @param x             Angle
 * @return              Sine value of angle x
 */

int8_t math2d_sin(uint8_t x);
/**
 * \brief Cosine trigonometric function
 * @param x             Angle
 * @return              Cosine value of angle x
 */
int8_t math2d_cos(uint8_t x);

/**
 * \brief Multiply and Division between 8-bit unsigned integers
 *
 * @param u1            First Multiplier
 * @param u2            Second Multiplier
 * @param d             Divider
 *
 * @return              Result of Division after multiplication
 */
uint8_t math2d_mul_div_uu8(uint8_t u1, uint8_t u2, uint8_t d);

/**
 * \brief Multiply and Division between 8-bit signed and 8-bit  unsigned integers
 *
 * @param u1            First Multiplier signed
 * @param u2            Second Multiplier unsigned
 * @param d             Divider unsigned
 *
 * @return              Result of Division after multiplication
 */
int8_t math2d_mul_div_su8(int8_t s, uint8_t u, uint8_t d);

/**
 * \brief Multiply and Division between 16-bit unsigned integers
 *
 * @param u1            First Multiplier
 * @param u2            Second Multiplier
 * @param d             Divider
 *
 * @return              Result of Division after multiplication
 */
uint16_t math2d_mul_div_uu16(uint16_t u1, uint16_t u2, uint16_t d);

/**
 * \brief Multiply and Division between 16-bit signed and 16-bit  unsigned integers
 *
 * @param u1            First Multiplier signed
 * @param u2            Second Multiplier unsigned
 * @param d             Divider unsigned
 *
 * @return              Result of Division after multiplication
 */
int16_t math2d_mul_div_su16(int16_t s, uint16_t u, uint16_t d);

/**
 * \brief Absolute value function
 *
 * @param num           Signed integer input
 * @return              Absolute value of num
 */
uint16_t math2d_abs_16(int16_t num);

/**
 * \brief Function to limit 16-bit unsigned integers inside a given range
 *
 * @param val           Number to be limited
 * @param min           Minimum value
 * @param max           Maximum value
 * @return              Val if val is between [min, max] interval, else min(if val<min)
 *                      or max (if val>max)
 */
uint16_t math2d_limit_u16(uint16_t val, uint16_t min, uint16_t max);

/**
 * \brief Function to limit 16-bit signed integers inside a given range
 *
 * @param val           Number to be limited
 * @param min           Minimum value
 * @param max           Maximum value
 * @return              Val if val is between [min, max] interval, else min(if val<min)
 *                      or max (if val>max)
 */
int16_t math2d_limit_s16(int16_t val, int16_t min, int16_t max);

/**
 * \brief Function to limit 8-bit unsigned integers inside a given range
 *
 * @param val           Number to be limited
 * @param min           Minimum value
 * @param max           Maximum value
 * @return              Val if val is between [min, max] interval, else min(if val<min)
 *                      or max (if val>max)
 */
uint8_t math2d_limit_u8(uint8_t val, uint8_t min, uint8_t max);

/**
 * \brief Function to limit 16-bit signed integers inside a given range
 *
 * @param val           Number to be limited
 * @param min           Minimum value
 * @param max           Maximum value
 * @return              Val if val is between [min, max] interval, else min(if val<min)
 *                      or max (if val>max)
 */
int8_t math2d_limit_s8(int8_t val, int8_t min, int8_t max);

#endif /* MATH_2D_H_ */

/**
 * \}
 * \}
 */
