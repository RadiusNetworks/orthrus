/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup TEXTBOX
 *
 * \brief Textbox widget
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file textbox.h
 *
 * @brief Textbox widget API
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef TEXTBOX_H_
#define TEXTBOX_H_

#include "stdlib.h"
#include "stdint.h"
#include "stdbool.h"
#include "screen.h"
#include "common.h"

/**
 * \brief Textbox type definition
 */
typedef struct {
        const bool border;              /**< Display textbox border or not */
        const font_info_t *font;        /**< Pointer to the font descriptor */
        const gdi_scale_t scale;        /**< Scaling factor in tenths */
        const ui_align_t align;         /**< Text alignment */
        char *text;                     /**< Pointer to the textbox text */
} ui_textbox_t;

/**
 * Test box declaration macro
 */
#define __DECLARE_TEXTBOX(name, _color, _x, _y, _w, _h, _border, _font, _text, _max_str, _align, _scale, _visible, _valid) \
        PRIVILEGED_DATA static char name##_text_val[_max_str+1];                                   \
        INITIALISED_PRIVILEGED_DATA static ui_flags_t name##_flags =                               \
                UI_FLAG_REDRAW | (_visible ? UI_FLAG_VISIBLE : 0) | (_valid ? UI_FLAG_VALID : 0);  \
        const ui_textbox_t name##_properties = {                                                   \
                .border = _border,                                                                 \
                .font = _font,                                                                     \
                .scale = _scale,                                                                   \
                .align = _align,                                                                   \
                .text = _text                                                                      \
        };                                                                                         \
        const ui_screen_item_t name = {                                                            \
                .color = _color,                                                                   \
                .x = _x,                                                                           \
                .y = _y,                                                                           \
                .width = _w,                                                                       \
                .height = _h,                                                                      \
                .type = UI_TEXTBOX,                                                                \
                .properties = &(name##_properties),                                                \
                .status = name##_text_val,                                                         \
                .flags = &(name##_flags)                                                           \
        };

#define DECLARE_TEXTBOX(name, color, x, y, w, h, border, font, text, max_str, align)               \
        __DECLARE_TEXTBOX(name, color, x, y, w, h, border, font, text, max_str, align, 10, true, true)

#define DECLARE_TEXTBOX_SCALED(name, color, x, y, w, h, border, font, text, max_str, align, scale) \
        __DECLARE_TEXTBOX(name, color, x, y, w, h, border, font, text, max_str, align, scale, true, true)

#define DECLARE_TEXTBOX_EXTENDED(name, color, x, y, w, h, border, font, text, max_str, align, visible, valid) \
        __DECLARE_TEXTBOX(name, color, x, y, w, h, border, font, text, max_str, align, 10, visible, valid)

/**
 * Draw textbox widget
 *
 * \param [in] item pointer to suitable screen widget
 */
void ui_draw_textbox(const ui_screen_item_t *item);

/**
 * Draw textbox widget
 *
 * \param [in] item pointer to suitable screen widget
 * \param [in] format format string
 */
void ui_textbox_set_text(const ui_screen_item_t *item, const char *format, ...);

#endif /* TEXTBOX_H_ */

/**
 * \}
 * \}
 * \}
 */
