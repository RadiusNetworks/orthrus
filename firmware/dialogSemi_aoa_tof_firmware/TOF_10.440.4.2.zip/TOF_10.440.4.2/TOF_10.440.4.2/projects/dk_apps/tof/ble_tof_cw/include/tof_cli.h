/**
 ****************************************************************************************
 *
 * @file tof_cli.h
 *
 * @brief ToF code related to cli
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef TOF_CLI_H_
#define TOF_CLI_H_

#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <osal.h>

typedef enum {
        CLI_CMD_START,
        CLI_CMD_STOP,
        CLI_CMD_HELP,
        CLI_CMD_INVALID,
} cli_cmd_t;

/* Read a line from cli */
void readline(char *buf, size_t size);

/* Parse line to a get a command. In case of 'start' command
 * the line should also contain the address parameter.
 */
bool parseline(char *cli_input, cli_cmd_t *cmd, uint8_t *address);

/* Initialize cli task. This task receives input strings and notifies waiting task
 * that a string was read from cli.
 */
void tof_cli_init(OS_TASK notif_task_handle, uint32_t notif);

/* Returns the current input string */
char *tof_cli_get_clistr();

#endif /* TOF_CLI_H_*/
