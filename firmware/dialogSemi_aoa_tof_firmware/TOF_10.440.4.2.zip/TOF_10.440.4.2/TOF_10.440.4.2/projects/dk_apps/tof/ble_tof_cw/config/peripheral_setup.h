 /**
 ****************************************************************************************
 *
 * @file periph_setup.h
 *
 * @brief Peripheral Setup file.
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */
#ifndef PERIPH_SETUP_H_
#define PERIPH_SETUP_H_

#include "hw_gpio.h"

/*
 * Include definitions for configuring the hardware blocks.
 */

#if dg_configUSE_PSP27801
#define PSP27801_RW_PORT                        HW_GPIO_PORT_1
#define PSP27801_RW_PIN                         HW_GPIO_PIN_9

#define PSP27801_CS_PORT                        HW_GPIO_PORT_0
#define PSP27801_CS_PIN                         HW_GPIO_PIN_20

#define PSP27801_SCK_PORT                       HW_GPIO_PORT_0
#define PSP27801_SCK_PIN                        HW_GPIO_PIN_21

#define PSP27801_SDO_PORT                       HW_GPIO_PORT_0
#define PSP27801_SDO_PIN                        HW_GPIO_PIN_24

#define PSP27801_SDI_PORT                       HW_GPIO_PORT_0
#define PSP27801_SDI_PIN                        HW_GPIO_PIN_26

#define PSP27801_DC_PORT                        HW_GPIO_PORT_1
#define PSP27801_DC_PIN                         HW_GPIO_PIN_1

#define PSP27801_EN_PORT                        HW_GPIO_PORT_0
#define PSP27801_EN_PIN                         HW_GPIO_PIN_27

#define PSP27801_RST_PORT                       HW_GPIO_PORT_0
#define PSP27801_RST_PIN                        HW_GPIO_PIN_12
#endif /* dg_configUSE_PSP27801 */

#if dg_configUSE_DT280QV10CT
#define DT280QV10CT_SDA_PORT                    HW_GPIO_PORT_0
#define DT280QV10CT_SDA_PIN                     HW_GPIO_PIN_24

#define DT280QV10CT_RST_PORT                    HW_GPIO_PORT_0
#define DT280QV10CT_RST_PIN                     HW_GPIO_PIN_12

#define DT280QV10CT_SCK_PORT                    HW_GPIO_PORT_0
#define DT280QV10CT_SCK_PIN                     HW_GPIO_PIN_27

#define DT280QV10CT_DC_PORT                     HW_GPIO_PORT_0
#define DT280QV10CT_DC_PIN                      HW_GPIO_PIN_20

#define DT280QV10CT_CS_PORT                     HW_GPIO_PORT_0
#define DT280QV10CT_CS_PIN                      HW_GPIO_PIN_21

#define DT280QV10CT_TE_PORT                     HW_GPIO_PORT_1
#define DT280QV10CT_TE_PIN                      HW_GPIO_PIN_22
#endif /* dg_configUSE_DT280QV10CT */

#endif /* PERIPH_SETUP_H_ */
