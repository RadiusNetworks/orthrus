/**
 ****************************************************************************************
 *
 * @file cw_distance.h
 *
 * @brief Calculate distance based on phase data
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

/* Prevent double inclusion */
#ifndef CW_DISTANCE_H
#define CW_DISTANCE_H

#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <arm_math.h>

#define CWD_C_AIR           (299792458/1.0003)
#define CWD_PHASE_OFFSET    (5.8/180*M_PI)
#define CWD_DQF_F_OFFS_TH   (2)

/* default parameters */
#define CWD_S_RATE_M_DEFAULT        (8)
#define CWD_N_DOWN_SAMP_DEFAULT     (2)
#define CWD_N_DOWN_SAMP_MIN         (2)
#define CWD_F_IF_INIT_DEFAULT       (1)
#define CWD_F_STEP_DEFAULT          (2)
#define CWD_T_ATOM_RX_US_DEFAULT    (48)
#define CWD_T_ATOM_USED_US_DEFAULT  (32)
#define CWD_T_ATOM_OFFS_US_DEFAULT  (4)
#define CWD_N_ATOM_DEFAULT          (20)
#define CWD_COMP_DC_OFFSET          (true)

#define CWD_N_ATOM_MAX              (40)
#define CWD_MAX_NUM_POINTS  (CWD_T_ATOM_RX_US_DEFAULT * CWD_N_ATOM_MAX * CWD_S_RATE_M_DEFAULT)

/* do only use the first N_SAMP samples of each atom for phase calculation
 * set to 0 to use all */
#define CWD_N_SAMP_PER_ATOM         (40)

#define CWD_NFFT                    (2048)
#define CWD_MAX_PEAKS               (20)
#define CWD_FFT_PEAK_THRESH         0.44

// struct containing interleaved phase/magnitude values
typedef struct
{
    float32_t phase;
    float32_t mag;
}
phase_mag;

typedef struct cw_distance_parm_tag
{
    /* sampling rate in Msamps */
    uint8_t s_rate_m;
    /* down sampling / decimation factor */
    uint8_t n_down_samp;

    /* initiator IF frequency relative to responder in MHz */
    float f_if_init;
    /* frequency step in MHz */
    float f_step;

    bool is_initiator;

    /* number of atoms per measurement */
    uint8_t n_atom;
    /* time per atom inside buffer */
    uint8_t t_atom_rx_us;
    /* used sampling time per atom (for calculation) */
    uint8_t t_atom_used_us;
    /* time before first used data point inside buffer */
    uint8_t t_atom_offs_us;

    /* number of measurement samples */
    uint16_t num_points;
    /* sample data buffer */
    uint32_t *data_buffer;

    /* perform DC offset compensation before phase extraction */
    bool comp_dc_offset;
} cw_distance_parm_t;

extern cw_distance_parm_t cwd_parm;


/*
 * initialize cw_distance specific parameters, returns the number of samples
 * for the standard configuration
 */
uint16_t cwd_init(uint32_t *data_buffer, bool is_initiator);

/* set n_atom and return the number of samples for this configuration (num_points) */
uint16_t cwd_set_n_atom(uint8_t n_atom);

/*
 * Calculate the distance based on given IQ samples using phase-based
 * algorithm. Ensure to provide arrays with at least num_points
 * length.
 */
float cwd_phase_based_distance(int16_t *init_iq, int16_t *refl_iq);

/*
 * Calculate the distance based on given IQ samples using IFFT-based
 * algorithm. Ensure to provide arrays with at least num_points
 * length.
 */
float cwd_ifft_based_distance(int16_t *init_iq, int16_t *refl_iq);

/*
 * calculate phase data out of IQ data. Generate one phase value per atom
 *  input data:
 *      iq_data ... complex signal vector (signed integer, 9 bits per I/Q, 
 *                  interleaved)
 *      f_if ...... IF frequency in MHz (pos. for init, neg. for refl.)
 *  output data:
 *      phase_atom  phase data (one float per atom, may be NULL)
 *      iq_atom     IQ data (two float32_t per atom, may be NULL)
 *      f_offs .... frequency offset (single float) (= return value)
 */
float cwd_calc_phase_IQ(int16_t *iq_data, float f_if, float *phase_atom, float32_t *iq_atom);

float cwd_calc_phase_data(float *phase_atom);
float cwd_calc_phase_mag_data(float *phase_atom, uint16_t *mag_atom);
float cwd_calc_ifft_distance_phase_mag(float *i_phase, uint16_t *i_mag, float *r_phase, uint16_t *r_mag);
void cwd_polar_to_iq(float phase, float mag, float *i_val, float *q_val);

/*
 * calculate distance out of phase values.
 *  input data:
 *      init_phase_atom ... phase data of initiator (one float per atom)
 *      refl_phase_atom ... phase data of responder (one float per atom)
 *  output data:
 *      return value ...... distance in m
 */
float cwd_calc_distance(float *init_phase_atom, float *refl_phase_atom);

/*
 * calculate distance quality factor out of frequency offset values of both sides.
 *  input data:
 *      fo_i ........... average initiator frequency offset in kHz
 *      fo_r ........... average responder frequency offset in kHz
 *  output data:
 *      return value ... distance quality factor (0: bad measurement, 100: good measurement)
 */
uint8_t cwd_calc_dqf(int16_t fo_i, int16_t fo_r);

#endif /* CW_DISTANCE_H */
