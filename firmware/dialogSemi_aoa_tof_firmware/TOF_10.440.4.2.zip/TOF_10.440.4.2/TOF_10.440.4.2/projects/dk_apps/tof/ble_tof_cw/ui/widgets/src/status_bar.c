/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup STATUS_BAR
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file status_bar.c
 *
 * @brief Status bar widget implementation
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include "stdbool.h"
#include "common.h"
#include "status_bar.h"
#include "gdi.h"
#include "osal.h"
#include "image.h"
#include "battery.h"

#if dg_configLCDC_ADAPTER

#define STATUS_BAR_FRAME_WIDTH                  (2)
#define STATUS_BAR_FRAME_HEIGHT                 (2)

gdi_coord_t ui_status_bar_width(const ui_status_bar_t *status_bar)
{
        const ui_screen_item_t* const *items;
        const ui_screen_item_t *item;
        gdi_coord_t len = 0;

        items = status_bar->items;

        while (*items != NULL) {
                item = *items;

                if (!UI_IS_FLAG_SET(item, UI_FLAG_VISIBLE)) {
                        items++;
                        continue;
                }

                len += len == 0 ? 0 : status_bar->spacer;
                len += item->width;

                items++;
        }
        return len + STATUS_BAR_FRAME_WIDTH * 2;
}

gdi_coord_t ui_status_bar_height(const ui_status_bar_t *status_bar)
{
        const ui_screen_item_t* const *items;
        const ui_screen_item_t *item;
        gdi_coord_t len = 0;

        items = status_bar->items;

        while (*items != NULL) {
                item = *items;

                len = MAX(item->height, len);

                items++;
        }
        return len + STATUS_BAR_FRAME_HEIGHT * 2;
}

void ui_draw_status_bar(const ui_status_bar_t *status_bar)
{
        const ui_screen_item_t* const *items;
        const ui_screen_item_t *item;
        gdi_coord_t xpos, ypos;

        if (!status_bar) {
                return;
        }

        items = status_bar->items;

        switch(status_bar->align) {
        case UI_ALIGN_LEFT:
                xpos = ui_status_bar_width(status_bar);
                break;
        case UI_ALIGN_CENTER:
                xpos = GDI_DISP_RESX - (GDI_DISP_RESX - ui_status_bar_width(status_bar)) / 2;
                break;
        case UI_ALIGN_RIGHT:
                xpos = GDI_DISP_RESX;
                break;
        }

        while (*items != NULL) {
                item = *items;

                UI_CLEAR_FLAG(item, UI_FLAG_REDRAW);

                if (!UI_IS_FLAG_SET(item, UI_FLAG_VISIBLE)) {
                        items++;
                        continue;
                }

                xpos -= item->width;
                ypos = (status_bar->height - item->height) / 2;

                switch (item->type) {

                case UI_IMAGE:
                        if (UI_IS_FLAG_SET(item, UI_FLAG_RECOLOR)) {
                                gdi_draw_image_recolor(xpos, ypos,
                                        ((ui_image_widget_t *)item->properties)->bitmap,
                                        ((ui_image_widget_t *)item->properties)->format, item->width,
                                        item->height, item->color);
                        }
                        else {
                                gdi_draw_image(xpos, ypos,
                                        ((ui_image_widget_t *)item->properties)->bitmap,
                                        ((ui_image_widget_t *)item->properties)->format, item->width,
                                        item->height);
                        }
                        break;

                case UI_BATTERY_WIDGET:
                        ui_draw_battery(item, xpos, ypos);
                        break;

                default:
                        break;
                }

                xpos -= status_bar->spacer;

                items++;
        }
}

uint8_t ui_status_bar_redraw_needed(const ui_status_bar_t *status_bar)
{
        const ui_screen_item_t* const *items;

        if (!status_bar) {
                return 0;
        }

        items = status_bar->items;

        while (*items != NULL) {
                if (UI_IS_FLAG_SET(*items, UI_FLAG_REDRAW)) {
                        return 1;
                }
                items++;
        }

        return 0;
}
#endif /* dg_configLCDC_ADAPTER */

/**
 * \}
 * \}
 * \}
 */
