/**
 ****************************************************************************************
 *
 * @file ble_tof_sync.c
 *
 * @brief BLE ToF code for CW synchronization
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <stdio.h>
#include "osal.h"
#include "hw_timer.h"
#include "systick.h"
#include "ble_tof.h"
#include "ble_tof_sync.h"
#include "acquisition.h"
#include "tof_interface.h"
#include "ble_tof_cw_config.h"

#include "ble_stack_config.h"
#include "user_config_defs.h"

#define DIAG1_SIGNAL_DETECTED_Pos       10
#define DIAG1_MATCH0101_Pos             9
#define DIAG1_SYNC_FOUND_Pos            8
#define DIAG1_PHY_TX_EN_RFCU_Pos        7
#define DIAG1_PHY_RX_EN_RFCU_Pos        6
#define DIAG1_DCF_26_Pos                5
#define DIAG1_DCF_25_Pos                4
#define DIAG1_DCF_24_Pos                3
#define DIAG1_DCF_23_Pos                2
#define DIAG1_DCF_22_Pos                1
#define DIAG1_DCF_21_Pos                0

PRIVILEGED_DATA static tof_role_t tof_role;
PRIVILEGED_DATA static tof_state_t tof_state;
PRIVILEGED_DATA static bool tof_error;
PRIVILEGED_DATA static OS_TASK tof_task_handle;
PRIVILEGED_DATA static uint32_t sync_to_in_ticks;
PRIVILEGED_DATA static uint32_t tof_notif;

PRIVILEGED_DATA static bool tof_sync_start;
PRIVILEGED_DATA static bool tof_cw_start;

extern void cpu_signal(void);

/* gpios used to temporary measure the synchronization with an oscilloscope */
__RETAINED volatile uint32 delay;
__RETAINED_CODE void toggle_gpio12(void)
{
#if TOF_ENABLE_JITTER_STATS
        GPIO->P1_02_MODE_REG = 0x300;
        GPIO->P1_SET_DATA_REG = 1 << 2;         // P1_02 high
        CRG_TOP->P1_SET_PAD_LATCH_REG = 1 << 2;

        for (delay = 0; delay < 50; delay++)
        {
        }

        GPIO->P1_RESET_DATA_REG = 1 << 2;       // P1_02 low
        CRG_TOP->P1_RESET_PAD_LATCH_REG = 1 << 2;
#endif /* TOF_ENABLE_JITTER_STATS */
}

__RETAINED_CODE void toggle_gpio13(void)
{
#if TOF_ENABLE_JITTER_STATS
        GPIO->P1_03_MODE_REG = 0x300;
        GPIO->P1_SET_DATA_REG = 1 << 3;         // P1_03 high
        CRG_TOP->P1_SET_PAD_LATCH_REG = 1 << 3;

        for (delay = 0; delay < 50; delay++)
        {
        }

        GPIO->P1_RESET_DATA_REG = 1 << 3;       // P1_03 low
        CRG_TOP->P1_RESET_PAD_LATCH_REG = 1 << 3;
#endif /* TOF_ENABLE_JITTER_STATS */
}

static void Notification_Handler(void)
{
        /* disable timer and timer clock */
        hw_timer_disable(HW_TIMER);

        OS_ASSERT(tof_notif);

        /* send OS notification */
        OS_TASK_NOTIFY_FROM_ISR(tof_task_handle, tof_notif, eSetBits);
}

void notification_timer_config(uint32_t period)
{
        timer_config timer_cfg = {
                .clk_src = HW_TIMER_CLK_SRC_EXT,
                .prescaler = 0,
                .timer = { .direction = HW_TIMER_DIR_UP,
                           .reload_val = period-1,
                           .free_run = false },
                .pwm = { .frequency = 0, .duty_cycle = 0},
        };

        hw_timer_init(HW_TIMER, &timer_cfg);
        hw_timer_register_int(HW_TIMER, Notification_Handler);

        tof_notif = 0;
}

void notification_timer_start(uint32_t notif)
{
        /* set notification and start timer */
        tof_notif = notif;
        OS_ASSERT(tof_notif);

        hw_timer_enable_clk(HW_TIMER);
        hw_timer_enable(HW_TIMER);
}

__RETAINED_CODE void delay_us(int us)
{
        hw_clk_delay_usec(us);
}


void restart_rf_diag_irq()
{
        /* Enable TX/RX irqs */
        CMAC->CM_DIAG_IRQ1_STAT_REG = 0x7FF;    // clear all bits for now
        NVIC_ClearPendingIRQ(RFDIAG_IRQn);
        NVIC_EnableIRQ(RFDIAG_IRQn);
}

/**
 * \brief RF diagnostic port interrupt
 */
__RETAINED_CODE void RFDIAG_Handler(void)
{
        volatile uint16 rf_diagirq_stat;

        rf_diagirq_stat = CMAC->CM_DIAG_IRQ1_STAT_REG;
        CMAC->CM_DIAG_IRQ1_STAT_REG = 0x7FF;    // clear all bits for now

        if (tof_sync_start) {

                systick_irq_start(sync_to_in_ticks);
                tof_state = TOF_STATE_PREPARE;
                tof_error = false;
                toggle_gpio12();
                /* Disable TX/RX irqs  that can be triggered if there are more packets in
                 * the connection event or from the acquisition code.
                 */
                NVIC_DisableIRQ(RFDIAG_IRQn);
        }
}

/* Sync Timeout in irq mode, we can now start the radio measurement */
__RETAINED_CODE void SysTick_Handler(void)
{
        SEGGER_SYSTEMVIEW_ISR_ENTER();

        /* extra delay to avoid irq latencies or to synchronize if different code
         * need for initiator / responder before actual measurement starts
         */
        /* prepare_acqusition */
        while (SysTick->VAL > sync_to_in_ticks - SYNC_TO_DELAY_IN_TICKS) {
                ;
        }

        /* check if cw measurement is active */
        if (!tof_cw_start) {

                systick_stop();

                /* Enable TX/RX irqs after sync is completed */
               restart_rf_diag_irq();

                /* OS_TASK_NOTIFY_FROM_ISR call is unsafe if Systick has irq priority 0 */
                notification_timer_start(TOF_SYNC_END_NOTIF);

                SEGGER_SYSTEMVIEW_ISR_EXIT();
                return;
        }

#ifdef SYNC_TIMER_FREE_RUNNING
        if (tof_state == TOF_STATE_PREPARE) {
                systick_stop();
                systick_irq_start(SYS_US_2_TICKS(1750));
        } else if (tof_state == TOF_STATE_ATOM_START) {
                systick_stop();
                /* use timer free running mode for atoms sequence */
                systick_irq_start(SYS_US_2_TICKS(160));
        }
#else
        systick_stop();
        systick_irq_start(SYS_US_2_TICKS(tof_state == TOF_STATE_PREPARE ? 1750 : 160));
#endif


        toggle_gpio13();

        /* run_acquisition; */
        switch (tof_state)
        {
        case TOF_STATE_PREPARE:
                if (REG_GETF(CRG_TOP, SYS_STAT_REG, RAD_IS_UP) == 1) {
                        systick_stop();
                        printf("IRQ: Ooops SYS_STAT_REG is on\r\n");
                        tof_state = TOF_STATE_ATOM_STOP;
                        tof_error = true;

                } else {
                        if (tof_params->pc_ready)
                        {
                                tof_params->fw_ready = 0;
                                /* Inform cmac to remain active after PD_RAD power domain is switched on.
                                 * This way the 1 Mhz clock is provided to the radio.
                                 * */
                                cmac_dynamic_config_table_ptr->sleep_enable = false;
                                rf_system_init();
                                //toggle_gpio13();
                                prepare_acquisition();
                                tof_state = TOF_STATE_ATOM_START;
                        } else {
                                systick_stop();
                                printf("PC is accessing memory, stop measurement\r\n");
                                tof_state = TOF_STATE_ATOM_STOP;
                                tof_error = true;
                        }
                }
                break;
        case TOF_STATE_ATOM_START:
                tof_state = TOF_STATE_ATOM_RUN;
                /* no break */
        case TOF_STATE_ATOM_RUN:
                if (run_acquisition_atom_cb()) {
                        tof_state = TOF_STATE_ATOM_STOP;
                }
                break;
        default:
                systick_stop();
                printf("oops\r\n");
                tof_state = TOF_STATE_ATOM_STOP;
                tof_error = true;
                break;
        }

        if (tof_state == TOF_STATE_ATOM_STOP) {
                systick_stop();

                if (!tof_error) {
                        /* Inform cmac that it can go to sleep and close PD_RAD the power domain */
                        cmac_dynamic_config_table_ptr->sleep_enable = true;
                        cpu_signal();
                        delay_us(200);
                        //toggle_gpio13();
                        rf_system_stop();
                }

                /* Enable TX/RX irqs after acquisition is completed */
                restart_rf_diag_irq();

                /* OS_TASK_NOTIFY_FROM_ISR call is unsafe if Systick has irq priority 0 */
                notification_timer_start(TOF_SYNC_END_NOTIF);
        }

        SEGGER_SYSTEMVIEW_ISR_EXIT();
}

void sys_cmac_on_error_handler(void)
{
        printf("CM_CTRL_SYS_REG %x\r\n", CMAC->CM_CTRL_SYS_REG);
        ASSERT_ERROR(0);
}

void enable_systick_irq()
{
        /* Disable timer */
        SysTick->CTRL  = 0;

        /* Warning: highest priority (0), not compatible with FreeRTOS calls */
        NVIC_SetPriority (SysTick_IRQn, 0);

        printf("priority SYSTICK changed  %lu\r\n", NVIC_GetPriority(SysTick_IRQn));
}

void enable_rf_diag_irq(uint32 signal, bool negedge)
{
        const uint32_t MASK = 1 << signal;
        const uint32_t NMASK = ~MASK;

        /* init registers */
        CMAC->CM_DIAG_IRQ1_EDGE_REG = 0;
        CMAC->CM_DIAG_IRQ1_STAT_REG = 0x7FF;    // clear all bits
        CMAC->CM_DIAG_IRQ1_MASK_REG = 0;        // disable all sources

        /* Program edge trigger for the DIAG IRQ source. */
        if (negedge) {
                CMAC->CM_DIAG_IRQ1_EDGE_REG |= MASK;
        } else {
                CMAC->CM_DIAG_IRQ1_EDGE_REG &= NMASK;
        }

        /* Clear the status bits before the interrupts are unmasked. An interrupt will otherwise be generated at the point. */
        CMAC->CM_DIAG_IRQ1_STAT_REG |= MASK;

        /* Program mask reg for the DIAG IRQ source */
        CMAC->CM_DIAG_IRQ1_MASK_REG |= MASK;

        /* NOTE: RF_DIAG IRQ for Cortex-M0 must be disabled */
        /* Enable RF_DIAG_IRQn interrupt - The ISR is implemented with the RF_DIAG_Handler() function */
        NVIC_EnableIRQ(RFDIAG_IRQn);

        /* Set highest priority (0), not compatible with FreeRTOS calls */
        NVIC_SetPriority(RFDIAG_IRQn, 0);
        printf("priority RFDIAG_IRQn changed  %lu\r\n", NVIC_GetPriority(RFDIAG_IRQn));
}

void ble_tof_cw_start(void)
{
        tof_cw_start = true;
}

void ble_tof_cw_stop(void)
{
        tof_cw_start = false;
}

bool ble_tof_cw_active(void)
{
        return tof_cw_start;
}

void ble_tof_sync_start(void)
{
        tof_sync_start = true;
}

void ble_tof_sync_stop(void)
{
        tof_sync_start = false;
}

bool ble_tof_sync_active(void)
{
        return tof_sync_start;
}

void ble_tof_sync_init(tof_role_t role, OS_TASK handle)
{
        printf("trim reg %x\r\n", CRG_XTAL->CLK_FREQ_TRIM_REG);

        tof_sync_start = false;

        enable_systick_irq();

        sync_to_in_ticks = SYS_US_2_TICKS(SYNC_TO_IN_MS * 1000);

        if (role == TOF_ROLE_INITIATOR) {
                /* add offset between tx enable and rx sync word found */
                sync_to_in_ticks += SYS_US_2_TICKS(SYNC_TX_RX_OFFSET_IN_US) + 4;

                enable_rf_diag_irq(DIAG1_PHY_TX_EN_RFCU_Pos, false);

        } else {
                enable_rf_diag_irq(DIAG1_SYNC_FOUND_Pos, false);
        }

        tof_role = role;
        tof_task_handle = handle;

        notification_timer_config(SYS_US_2_TICKS(10));
}
