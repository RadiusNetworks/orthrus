/**
 ****************************************************************************************
 *
 * @file systick.h
 *
 * @brief System Timer code
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef SYSTICK_H_
#define SYSTICK_H_

/* For 32MHz */
#define SYS_US_2_TICKS(us)               (32 * (us))     /* each us is 32 ticks */
#define SYS_MS_2_TICKS(ms)               (32000 * (ms))  /* each ms is 32000 ticks */


/* start timer in irq mode (SysTick_IRQn must be enabled) */
__STATIC_INLINE void systick_irq_start(uint32_t ticks)          __attribute__((always_inline));

__STATIC_INLINE void systick_irq_start(uint32_t ticks)
{
        SysTick->LOAD = ticks -1;
        SysTick->VAL = 0x0;

        /* enable irq mode */
        SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_ENABLE_Msk;
}

/* stop timer */
__STATIC_INLINE void systick_stop()                             __attribute__((always_inline));

__STATIC_INLINE void systick_stop()
{
        SysTick->CTRL &= ~(SysTick_CTRL_ENABLE_Msk);
}

/* start timer in polling mode  */
__STATIC_INLINE void systick_poll_start(uint32_t ticks)         __attribute__((always_inline));
__STATIC_INLINE void systick_poll_start(uint32_t ticks)
{
        SysTick->LOAD = ticks - 1;
        SysTick->VAL = 0x0;

        /* enable polling mode */
        SysTick->CTRL  = SysTick_CTRL_CLKSOURCE_Msk | SysTick_CTRL_ENABLE_Msk;
}

/* wait for timer */
__STATIC_INLINE void systick_wait()                             __attribute__((always_inline));

__STATIC_INLINE void systick_wait()
{
        while ((SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk) == 0) {}
}

#endif /* SYSTICK_H_*/
