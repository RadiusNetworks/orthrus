/**
 ****************************************************************************************
 *
 * @file cw_ifft_distance.c
 *
 * @brief Calculate distance using IFFT
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <arm_math.h>
#include <arm_const_structs.h>

#include "cw_distance.h"
#include "peakdetect.h"

#if CWD_N_ATOM_MAX >= CWD_NFFT
#  error CWD_N_ATOM_MAX must be smaller than CWD_NFFT
#endif

#if CWD_NFFT == 512
#  define CFFT_SR arm_cfft_sR_f32_len512
#elif CWD_NFFT == 1024
#  define CFFT_SR arm_cfft_sR_f32_len1024
#elif CWD_NFFT == 2048
#  define CFFT_SR arm_cfft_sR_f32_len2048
#else
#  error Unsupported FFT size
#endif

static float32_t init_IQ[2 * CWD_N_ATOM_MAX];
static float32_t refl_IQ[2 * CWD_N_ATOM_MAX];
/* 2 * CWD_NFFT to have space for real/imag part */
static float32_t com_IQ[2 * CWD_NFFT];


static int filt_data(float32_t *in_data, int *peak_idx, int npeaks, float32_t *ref_axis_dist);
static float cwd_calc_ifft_distance(float32_t *init_IQ, float32_t *refl_IQ);

float cwd_ifft_based_distance(int16_t *init_iq, int16_t *refl_iq)
{
    float init_f_offs, refl_f_offs;
    float distance;
    //uint8_t dqf;

    /* running on initiator */
    init_f_offs = cwd_calc_phase_IQ(init_iq, cwd_parm.f_if_init, NULL, init_IQ);

    /* running on responder */
    refl_f_offs = cwd_calc_phase_IQ(refl_iq, -cwd_parm.f_if_init, NULL, refl_IQ);

    distance = cwd_calc_ifft_distance(init_IQ, refl_IQ);
    //dqf = cwd_calc_dqf(roundf(init_f_offs), roundf(refl_f_offs));

    return distance;
}

float cwd_calc_ifft_distance_phase_mag(float *i_phase, uint16_t *i_mag, float *r_phase, uint16_t *r_mag)
{
    float init_IQ[cwd_parm.n_atom * 2];
    float refl_IQ[cwd_parm.n_atom * 2];

    /* convert phase mag to IQ */
    for(int i = 0; i < cwd_parm.n_atom; i++)
    {
        cwd_polar_to_iq(i_phase[i], (float)i_mag[i], &init_IQ[i*2], &init_IQ[i*2+1]);
        cwd_polar_to_iq(r_phase[i], (float)r_mag[i], &refl_IQ[i*2], &refl_IQ[i*2+1]);
    }

    return cwd_calc_ifft_distance(init_IQ, refl_IQ);
}

static float cwd_calc_ifft_distance(float32_t *init_IQ, float32_t *refl_IQ)
{

    /*
     * n_atom must be smaller than CWD_NFFT
     *
     * Usually, CWD_NFFT is much larger. Through the memset() below, and
     * the complex multiplication of initiator and responder I/Q values,
     * this implies the subsequent IFFT performs some oversampling.
     */
    memset(com_IQ, 0, sizeof(com_IQ));
    arm_cmplx_mult_cmplx_f32(init_IQ, refl_IQ, com_IQ, cwd_parm.n_atom);

    arm_cfft_f32(&CFFT_SR, com_IQ, true, true);
    /*
     * Calculate magnitude of IFFT result. Note that this actually
     * shrinks the data contents of com_IQ to one half.
     */
    arm_cmplx_mag_f32(com_IQ, com_IQ, CWD_NFFT);

    /* normalize result */
    float32_t maxval = 0;
    for (int i = 0; i < CWD_NFFT; i++)
        if (com_IQ[i] > maxval)
            maxval = com_IQ[i];
    for (int i = 0; i < CWD_NFFT; i++)
        com_IQ[i] /= maxval;

    /*
     * Run the peak detection algorithm.
     *
     * The way it is written now, it needs to be able to detect both
     * peaks and valleys, to avoid aborting prematurely.
     */
    int peak_idx[CWD_MAX_PEAKS];
    int npeaks;

    detect_peak(com_IQ, CWD_NFFT,
                peak_idx, &npeaks, CWD_MAX_PEAKS,
                0.001f,
                1);

    if (npeaks == 0)
        return INFINITY;

    /*
     * Filter peaks so only those above a certain minimum are finally
     * considered.
     *
     * This also applies the "meters" scale from above, so the results
     * of filtering are given in meters.
     */
    float32_t dist_init[npeaks];
    int res_count = filt_data(com_IQ, peak_idx, npeaks, dist_init);

    if (res_count == 0)
            return INFINITY;

    /*
     * Find the minimal value.
     *
     * NB: by now, this always ought to be the very first one in
     * npeaks[], so this could probably be simplified.
     */
    float32_t minval = INFINITY;
    for (int i = 0; i < res_count; i++)
        if (dist_init[i] < minval)
            minval = dist_init[i];

    minval -= 0.9;

    return minval;
}

/*
 * Filter peak data.  in_data contains the IFFT values,
 * peak_idx[npeaks] the indices of the peaks found.  Only those above
 * CWD_FFT_PEAK_THRESH are considered for further evaluation.
 *
 * ref_axis_dist is the distances corresponding to the filtered peaks,
 * in meters.
 * That name merely reflects the Python code naming only.
 */
static int filt_data(float32_t *in_data, int *peak_idx, int npeaks,
                     float32_t *ref_axis_dist)
{
    int count = 0;

    /* calculate meter scale corresponding to IFFT indices */
    const float wrap_dx = CWD_C_AIR / (2 * cwd_parm.f_step * 1E6);
    const float32_t delta = wrap_dx / (float32_t)(CWD_NFFT - 1);

    for (int ii = 0; ii < npeaks; ii++)
        if (in_data[peak_idx[ii]] >= CWD_FFT_PEAK_THRESH)
        {
            *ref_axis_dist++ = peak_idx[ii] * delta;
            count++;
        }

    return count;
}
