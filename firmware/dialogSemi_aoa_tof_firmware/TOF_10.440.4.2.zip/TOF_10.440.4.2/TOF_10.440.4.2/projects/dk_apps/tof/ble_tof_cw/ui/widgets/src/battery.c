/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup BATTERY
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file battery.c
 *
 * @brief Battery widget implementation
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include "gdi.h"
#include "battery.h"

const uint8_t battery_bitmap[] =
{
        0xF8, 0xFF, 0xFF, //    #####################
        0x0C, 0x00, 0x80, //   ##                   #
        0x04, 0x00, 0x80, //   #                    #
        0x07, 0x00, 0x80, // ###                    #
        0x07, 0x00, 0x80, // ###                    #
        0x07, 0x00, 0x80, // ###                    #
        0x07, 0x00, 0x80, // ###                    #
        0x07, 0x00, 0x80, // ###                    #
        0x07, 0x00, 0x80, // ###                    #
        0x04, 0x00, 0x80, //   #                    #
        0x0C, 0x00, 0x80, //   ##                   #
        0xF8, 0xFF, 0xFF, //    #####################
};

const uint8_t charge_bitmap[] =
{
        0xE0, 0x00, //      ###
        0xE0, 0x03, //      #####
        0xE0, 0x0F, //      #######
        0x7F, 0x00, // #######
        0x7C, 0x00, //   #####
        0x70, 0x00, //     ###
};

const uint8_t warning_bitmap[] =
{
        0x01, // #
        0x01, // #
        0x01, // #
        0x01, // #
        0x00, //
        0x01, // #
};

void ui_draw_battery(const ui_screen_item_t *item, gdi_coord_t x, gdi_coord_t y)
{
        uint8_t level;
        gdi_color_t color;
        ui_battery_widget_t *bat = (ui_battery_widget_t*) item->status;

        level = ((15 * bat->level) + 50) / 100;

        color = bat->level >= 30 ? GDI_COLOR_GREEN : bat->level >= 15 ? GDI_COLOR_YELLOW : GDI_COLOR_RED;
        if (bat->state == UI_BATTERY_WARNING)
                color = GDI_COLOR_RED;

        gdi_draw_image_recolor(x, y, battery_bitmap, GDI_FORMAT_L1, BATTERY_WIDTH, BATTERY_HEIGHT, color);
        gdi_draw_fill_rect(color, x + 5 + (15 - level), y + 2, level, 8);

        if (bat->state == UI_BATTERY_CHARGING) {
                gdi_draw_image_recolor(x + 7, y + 3, charge_bitmap, GDI_FORMAT_L1, 12, 6, GDI_COLOR_WHITE);
        } else if (bat->state == UI_BATTERY_WARNING) {
                gdi_draw_image_recolor(x + 13, y + 3, warning_bitmap, GDI_FORMAT_L1, 1, 6, GDI_COLOR_RED);
        }
}

void ui_battery_widget_set_level(const ui_screen_item_t *item, uint8_t level)
{
        if (level <= 100) {
                if(((ui_battery_widget_t*) item->status)->level != level)
                        UI_SET_FLAG(item, UI_FLAG_REDRAW);
                ((ui_battery_widget_t*) item->status)->level = level;
        }
}

void ui_battery_widget_set_state(const ui_screen_item_t *item, ui_battery_state_t state)
{
        if(((ui_battery_widget_t*) item->status)->state != state)
                UI_SET_FLAG(item, UI_FLAG_REDRAW);
        ((ui_battery_widget_t*) item->status)->state = state;
}

/**
 * \}
 * \}
 * \}
 */
