/**
 * \addtogroup UI
 * \{
 * \addtogroup FONTS
 *
 * \brief Basic font data types
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file fonts.h
 *
 * @brief Basic font data types definitions
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef FONTS_H_
#define FONTS_H_

#include "stdlib.h"
#include "stdint.h"

/**
 * \brief Font character definition
 */
typedef struct {
        uint8_t width;          /**< Character width in bits */
        uint16_t offset;        /**< Character offset in bitmap table */
} font_char_info_t;

/**
 * \brief Font definition
 */
typedef struct {
        uint8_t height;                         /**< Font height in bits */
        char start;                             /**< First character */
        char end;                               /**< Last character */
        uint8_t spaceWidth;                     /**< Space character width in bits */
        uint8_t kerning;                        /**< Space between two characters */
        const font_char_info_t *descriptor;     /**< Pointer to font character definitions */
        const uint8_t *bitmap;                  /**< Pointer to font character bitmaps */
} font_info_t;

#endif /* FONTS_H_ */

/**
 * \}
 * \}
 */
