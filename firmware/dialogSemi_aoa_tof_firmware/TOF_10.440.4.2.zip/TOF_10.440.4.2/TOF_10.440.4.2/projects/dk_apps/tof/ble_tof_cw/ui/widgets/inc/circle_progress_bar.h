/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup CIRCLE_PROGRESS_BAR
 *
 * \brief Circle progress bar widget
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file circle_progress_bar.h
 *
 * @brief Circle progress bar widget API
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef CIRCLE_PROGRESS_BAR_H_
#define CIRCLE_PROGRESS_BAR_H_

#include "stdlib.h"
#include "stdint.h"
#include "screen.h"
#include "common.h"

/**
 * Circle progress bar declaration macro
 */
#define  DECLARE_CIRCLE_PROGRESS_BAR(name, _color, _x, _y, _r, _val)                               \
        INITIALISED_PRIVILEGED_DATA static uint8_t name##_value = _val;                            \
        INITIALISED_PRIVILEGED_DATA static ui_flags_t name##_flags = UI_FLAG_REDRAW | UI_FLAG_VISIBLE;\
        static const ui_screen_item_t name = {                                                     \
                .color = _color,                                                                   \
                .x = _x,                                                                           \
                .y = _y,                                                                           \
                .width = _r,                                                                       \
                .type = UI_CIRCLE_PROGRESS_BAR,                                                    \
                .properties = NULL,                                                                \
                .status = &(name##_value),                                                         \
                .flags = &(name##_flags)                                                           \
        };

/**
 * Draw circle progress bar widget
 *
 * \param [in] item pointer to suitable screen widget
 */
void ui_draw_circle_progress(const ui_screen_item_t *item);

/**
 * Set progress value
 *
 * \param [in] item pointer to suitable screen widget
 * \param [in] value new progress bar value
 */
void ui_circle_progress_set_value(const ui_screen_item_t *item, uint8_t value);

#endif /* CIRCLE_PROGRESS_BAR_H_ */

/**
 * \}
 * \}
 * \}
 */
