/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup CIRCLE_PROGRESS_BAR
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file circle_progress_bar.c
 *
 * @brief Circle progress bar widget implementation
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include "circle_progress_bar.h"
#include "common.h"
#include "gdi.h"

void ui_draw_circle_progress(const ui_screen_item_t *item)
{
        uint8_t *progress = (uint8_t*) item->status;
        int16_t val;

        if (!UI_IS_FLAG_SET(item, UI_FLAG_VISIBLE)) {
                return;
        }

        val = *progress * 36;
        val /= 10;
        val -= 90;

        gdi_draw_circle(item->color, item->x, item->y, item->width * 2);
        gdi_draw_circle(item->color, item->x, item->y, (item->width + 5) * 2);
        gdi_draw_arc(item->color, item->x, item->y, item->width+1, 4, -45, val / 2);
}

void ui_circle_progress_set_value(const ui_screen_item_t *item, uint8_t value)
{
        *((uint8_t*) item->status) = value;
        UI_SET_FLAG(item, UI_FLAG_REDRAW);
}

/**
 * \}
 * \}
 * \}
 */
