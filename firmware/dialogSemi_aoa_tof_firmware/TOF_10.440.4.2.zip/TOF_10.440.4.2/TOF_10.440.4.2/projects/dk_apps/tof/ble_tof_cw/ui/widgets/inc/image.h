/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup IMAGE
 *
 * \brief Image widget
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file image.h
 *
 * @brief Image widget API
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef IMAGE_H_
#define IMAGE_H_

#include "stdlib.h"
#include "stdint.h"
#include "screen.h"
#include "common.h"

#define _IMAGE_TO_GDI_FORMAT(frmt)      GDI_FORMAT_ ## frmt
#define IMAGE_TO_GDI_FORMAT(frmt)       _IMAGE_TO_GDI_FORMAT(frmt)

typedef struct {
        gdi_color_fmt_t format;
        const uint8_t  *bitmap;
} ui_image_widget_t;

/**
 * Image object declaration macro
 */
#define __DECLARE_IMAGE_EXTENDED(name, _x, _y, _keep_colors, _color, _visible)                     \
        static const ui_image_widget_t name##_properties = {                                       \
                .format = IMAGE_TO_GDI_FORMAT(name##_format),                                      \
                .bitmap = (name##_bitmap),                                                         \
        };                                                                                         \
        INITIALISED_PRIVILEGED_DATA static ui_flags_t name##_flags =                               \
                UI_FLAG_REDRAW                                                                     \
              | (_visible ? UI_FLAG_VISIBLE : 0)                                                   \
              | (_keep_colors ? 0 : UI_FLAG_RECOLOR);                                              \
        static const ui_screen_item_t name = {                                                     \
                .color = _color,                                                                   \
                .x = _x,                                                                           \
                .y = _y,                                                                           \
                .width = name##_width,                                                             \
                .height = name##_height,                                                           \
                .type = UI_IMAGE,                                                                  \
                .properties = &(name##_properties),                                                \
                .status = NULL,                                                                    \
                .flags = &(name##_flags)                                                           \
        };

#define DECLARE_IMAGE(name, x, y) \
        __DECLARE_IMAGE_EXTENDED(name, x, y, true, 0, true)
#define DECLARE_IMAGE_EXT(name, x, y, visible) \
        __DECLARE_IMAGE_EXTENDED(name, x, y, true, 0, visible)
#define DECLARE_IMAGE_GRAY2COLOR(name, x, y, color) \
        __DECLARE_IMAGE_EXTENDED(name, x, y, false, color, true)
#define DECLARE_IMAGE_GRAY2COLOR_EXT(name, x, y, color, visible) \
        __DECLARE_IMAGE_EXTENDED(name, x, y, false, color, visible)

#define IMG_RESX(name)                  (name##_width)
#define IMG_RESY(name)                  (name##_height)

/**
 * Draw image widget
 *
 * \param [in] item pointer to suitable screen widget
 */
void ui_draw_image(const ui_screen_item_t *item);

#endif /* IMAGE_H_ */

/**
 * \}
 * \}
 * \}
 */
