/**
 * \addtogroup UI
 * \{
 * \addtogroup WIDGETS
 * \{
 * \addtogroup STATUS_BAR
 *
 * \brief Status bar widget
 * \{
 */
/**
 ****************************************************************************************
 *
 * @file status_bar.h
 *
 * @brief Status bar widget API
 *
 * Copyright (C) 2017 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef STATUS_BAR_H_
#define STATUS_BAR_H_

#include "stdlib.h"
#include "stdint.h"
#include "common.h"

/**
 * \brief Status bar widget type definition
 */
typedef struct {
        gdi_coord_t height;                   //!< Height of the status bar
        gdi_coord_t spacer;                   //!< Space in pixels between items
        ui_align_t align;                     //!< Status bar alignment
        const ui_screen_item_t* const *items; //!< List of status bar items
} ui_status_bar_t;

/**
 * Status bar object declaration macro
 */
#define DECLARE_STATUS_BAR_BEGIN(name, _spacer, _align)                                            \
        static const ui_screen_item_t* const name##_items[];                                       \
        INITIALISED_PRIVILEGED_DATA static ui_status_bar_t name = {                                \
                .height = 0,                                                                       \
                .spacer = _spacer,                                                                 \
                .align = _align,                                                                   \
                .items = name##_items                                                              \
        };                                                                                         \
        static const ui_screen_item_t* const name##_items[] = {                                    \

#define DECLARE_STATUS_BAR_OBJECT(name) &(name),

#define DECLARE_STATUS_BAR_END() NULL };

gdi_coord_t ui_status_bar_width(const ui_status_bar_t *status_bar);
gdi_coord_t ui_status_bar_height(const ui_status_bar_t *status_bar);

/**
 * Draw status bar widget
 *
 * \param [in] status_bar  pointer to status bar widget
 */
void ui_draw_status_bar(const ui_status_bar_t *status_bar);

/**
 * Check if status bar widget should be redraw
 *
 * \param [in] status_bar  pointer to status bar widget
 */
uint8_t ui_status_bar_redraw_needed(const ui_status_bar_t *status_bar);

#endif /* STATUS_BAR_H_ */

/**
 * \}
 * \}
 * \}
 */
