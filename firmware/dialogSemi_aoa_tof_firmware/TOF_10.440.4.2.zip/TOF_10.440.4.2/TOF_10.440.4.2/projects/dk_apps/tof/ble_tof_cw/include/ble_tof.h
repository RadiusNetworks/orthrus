/**
 ****************************************************************************************
 *
 * @file ble_tof.h
 *
 * @brief Code related to ble tof service
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */
#ifndef BLE_TOF_H_
#define BLE_TOF_H_

#if (dg_configSYSTEMVIEW)
#  include "SEGGER_SYSVIEW_FreeRTOS.h"
#else
#  define SEGGER_SYSTEMVIEW_ISR_ENTER()
#  define SEGGER_SYSTEMVIEW_ISR_EXIT()
#endif

#undef DEBUG_TOF

#ifdef DEBUG_TOF
    #define    dbg_printf(f,...)        printf(f,##__VA_ARGS__)
#else
    #define    dbg_printf(f,...)        do { } while (0)
#endif

#define TOF_MAX_PHASE_NUM               (40)

/* ToF service settings */
#define UUID_TOF_SERVICE        "4f120ca4-85d3-11e8-adc0-fa7ae01bbebc"
#define UUID_TOF_STATUS         "6a005098-85d3-11e8-adc0-fa7ae01bbebc"
#define UUID_TOF_I_RESULT       "6a005336-85d3-11e8-adc0-fa7ae01bbebc"
#define UUID_TOF_R_RESULT       "6a005476-85d3-11e8-adc0-fa7ae01bbebc"
#define UUID_TOF_VALUE          "6a0055a2-85d3-11e8-adc0-fa7ae01bbebc"

typedef enum {
        TOF_STATUS_STOP,
        TOF_STATUS_START,
        TOF_STATUS_SYNC,
        TOF_STATUS_CALC,
} tof_status_t;

typedef enum {
        TOF_ROLE_UNDEFINED = 0,
        TOF_ROLE_INITIATOR = 1,
        TOF_ROLE_RESPONDER = 2
} tof_role_t;

typedef enum {
        TOF_STATE_PREPARE,
        TOF_STATE_ATOM_START,
        TOF_STATE_ATOM_RUN,
        TOF_STATE_ATOM_STOP,
} tof_state_t;

typedef enum {
        TOF_NO_ERROR,
        TOF_ERROR_INSTANT_PASSED,
        TOF_ERROR_SYNC_FAILED,
        TOF_ERROR_RESULTS_TO
} tof_error_t;

/* Structure for ToF status pdu
 event_counter : the ble event counter for next cw measurement when status is TOF_STATUS_START
 err_code : the reason cw measurement failed when status is TOF_STATUS_STOP
 status: TOF_STATUS_START for a write command from the initiator or
         TOF_STATUS_STOP for a notification from the responder
*/
typedef struct __attribute__ ((packed)) {
        uint16_t  event_counter;
        tof_error_t  err_code;
        tof_status_t status;
} tof_status_pdu_t;

/* Structure for ToF result */
typedef struct __attribute__ ((packed)) {
        uint16_t  event_counter;
        uint16_t  measure_id;
        uint16_t  AGC_gain;
        int16_t   f_offset;
        float     phase[TOF_MAX_PHASE_NUM];
        uint16_t  amplitude[TOF_MAX_PHASE_NUM];
} tof_result_t;

#endif /* BLE_TOF_H_ */
