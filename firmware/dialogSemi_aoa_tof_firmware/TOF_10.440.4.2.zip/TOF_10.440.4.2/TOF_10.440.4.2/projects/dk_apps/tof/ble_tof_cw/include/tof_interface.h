/**
 ****************************************************************************************
 *
 * @file tof_interface.h
 *
 * @brief ToF interface to external host
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef TOF_INTERFACE_H_
#define TOF_INTERFACE_H_

/* Fixed size allocated in sections.ld.h. */
#define TOF_PARAMS_LENGTH                       (96) /* words */
#define TOF_DATA_MAX_LENGTH                     (4096*4) /* words */

typedef struct {
        /* === bidirectional flag === */
        uint32_t fw_ready;      /* handshake: low, if FW accesses pp_data and rfmon_data */
        uint32_t pc_ready;      /* handshake: low, if PC accesses pp_data and rfmon_data */

        /* === parameters set from MATLAB in the FW === */
        uint32_t role;          /* role of the firmware */
        uint32_t set_number;
        int32_t cw_offset;
        uint32_t f_start_mhz;
        uint32_t f_step_mhz;
        uint32_t nb_atoms;
        uint32_t xtal32m_trim_value;

        /* === information sent to MATLAB from FW === */
        uint32_t pp_data;       /* start address of the exchange memory for the ping pong data */
        uint32_t rfmon_data;    /* start address of the exchange memory for the rf monitor data */
        uint32_t phase_data;    /* start of phase data array */
        uint32_t mag_data;      /* start of magnitude data array */
        uint32_t evt_counter;   /* current iteration counter */
        uint32_t oflow;         /* current rf monitor overflow bit value */
        uint32_t agc;           /* current agc value */
        uint32_t c_evt_counter; /* event counter used for c distance calculation */
        uint32_t c_dist_cm;     /* distance calculated in firmware in centimeter */
        uint32_t f_offset;      /* frequency offset */

} __attribute__((packed)) tof_params_t;


void tof_interface_init();
void tof_interface_params_exchange();
void tof_interface_data_exchange(uint32_t evt_counter);
void tof_interface_update_c_results (uint32_t c_evt, float c_distance);

extern volatile tof_params_t *tof_params;
extern volatile uint32_t tof_data[];

#endif /* TOF_INTERFACE_H_*/
