/**
 ****************************************************************************************
 *
 * @file platform_devices.c
 *
 * @brief Configuration of devices connected to board data structures
 *
 * Copyright (C) 2017-2018 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#include <ad_lcdc.h>
#include "peripheral_setup.h"

/*
 * PLATFORM PERIPHERALS 
 *****************************************************************************************
 */
 #if dg_configLCDC_ADAPTER
 
#if dg_configUSE_PSP27801

/* GPIO configuration */
static const ad_io_conf_t psp27801_gpio_cfg[] = {
        { PSP27801_SDI_PORT,PSP27801_SDI_PIN,   { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD_SPI_DO,  true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
        { PSP27801_SCK_PORT, PSP27801_SCK_PIN,  { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD_SPI_CLK, true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
        { PSP27801_CS_PORT,  PSP27801_CS_PIN,   { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD_SPI_EN,  true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
        { PSP27801_DC_PORT,  PSP27801_DC_PIN,   { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD_SPI_DC,  true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
        { PSP27801_EN_PORT,  PSP27801_EN_PIN,   { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO,        true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
        { PSP27801_RST_PORT, PSP27801_RST_PIN,  { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO,        true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
        { PSP27801_RW_PORT,  PSP27801_RW_PIN,   { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO,        true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
 };

static const ad_lcdc_io_conf_t psp27801_io = {
        .voltage_level = HW_GPIO_POWER_V33,
        .io_cnt = sizeof(psp27801_gpio_cfg) / sizeof(psp27801_gpio_cfg[0]),
        .io_list = psp27801_gpio_cfg,
};

/* Driver configuration */
static const ad_lcdc_driver_conf_t psp27801_drv = {
        .hw_init.phy_type = HW_LCDC_PHY_CUSTOM,
        .hw_init.format = HW_LCDC_OCM_8RGB565,
        .hw_init.cfg_extra_flags = HW_LCDC_MIPI_CFG_RESET | HW_LCDC_MIPI_CFG_SPI4
                                    | HW_LCDC_MIPI_CFG_DMA | HW_LCDC_MIPI_CFG_TE_DIS,
        .hw_init.mode = HW_LCDC_MODE_DISABLE,
        .hw_init.iface_freq = LCDC_FREQ_8MHz,
        .ext_clk = HW_LCDC_EXT_CLK_OFF,
        .te_enable = false,
        .te_polarity = HW_LCDC_TE_LOW,
        .display.resx = 96,
        .display.resy = 96,
        .display.fpx = 0,
        .display.fpy = 0,
        .display.bpx = 0,
        .display.bpy = 0,
        .display.blx = 2,
        .display.bly = 1,
};

const ad_lcdc_controller_conf_t psp27801_cfg = {
        .io = &psp27801_io,
        .drv = &psp27801_drv,
};
#endif

#if dg_configUSE_DT280QV10CT
/* GPIO configuration */
static const ad_io_conf_t dt280qv10ct_gpio_cfg[] = {
        { DT280QV10CT_SDA_PORT, DT280QV10CT_SDA_PIN, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD_SPI_DO,  true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
        { DT280QV10CT_SCK_PORT, DT280QV10CT_SCK_PIN, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD_SPI_CLK, true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
        { DT280QV10CT_CS_PORT,  DT280QV10CT_CS_PIN,  { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD_SPI_EN,  true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
        { DT280QV10CT_DC_PORT,  DT280QV10CT_DC_PIN,  { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_LCD_SPI_DC,  true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
        { DT280QV10CT_TE_PORT,  DT280QV10CT_TE_PIN,   { HW_GPIO_MODE_INPUT, HW_GPIO_FUNC_LCD,         true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
        { DT280QV10CT_RST_PORT, DT280QV10CT_RST_PIN, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO,        true }, { HW_GPIO_MODE_OUTPUT, HW_GPIO_FUNC_GPIO, true }},
 };

static const ad_lcdc_io_conf_t dt280qv10ct_io = {
        .voltage_level = HW_GPIO_POWER_V33,
        .io_cnt = sizeof(dt280qv10ct_gpio_cfg) / sizeof(dt280qv10ct_gpio_cfg[0]),
        .io_list = dt280qv10ct_gpio_cfg,
};

/* Driver configuration */
static const ad_lcdc_driver_conf_t dt280qv10ct_drv = {
        .hw_init.phy_type = HW_LCDC_PHY_MIPI_SPI4,
        .hw_init.format = HW_LCDC_OCM_8RGB565,
        .hw_init.cfg_extra_flags = 0,
        .hw_init.mode = HW_LCDC_MODE_DISABLE,
        .hw_init.iface_freq = LCDC_FREQ_48MHz,
        .ext_clk = HW_LCDC_EXT_CLK_OFF,
        .te_enable = true,
        .te_polarity = HW_LCDC_TE_LOW,
        .display.resx = 240,
        .display.resy = 320,
        .display.fpx = 0,
        .display.fpy = 0,
        .display.bpx = 0,
        .display.bpy = 0,
        .display.blx = 2,
        .display.bly = 1,
};

const ad_lcdc_controller_conf_t dt280qv10ct_cfg = {
        .io = &dt280qv10ct_io,
        .drv = &dt280qv10ct_drv,
};
#endif /* dg_configUSE_DT280QV10CT */

#endif /* dg_configLCDC_ADAPTER */
