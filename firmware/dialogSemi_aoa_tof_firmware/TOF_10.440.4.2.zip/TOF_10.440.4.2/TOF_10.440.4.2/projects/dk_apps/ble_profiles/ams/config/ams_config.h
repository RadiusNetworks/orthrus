/**
 ****************************************************************************************
 *
 * @file ams_config.h
 *
 * @brief Application configuration
 *
 * Copyright (C) 2018-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef AMS_CONFIG_H_
#define AMS_CONFIG_H_

/*
 * Non-zero value enables extended printouts from application, like more detailed information about
 * remote commands and entity updates
 */
#ifndef CFG_VERBOSE_LOG
#       define CFG_VERBOSE_LOG (0)
#endif

/*
 * LED port configuration
 */
#ifndef CFG_LED_PORT
#               define CFG_LED_PORT (HW_GPIO_PORT_1)
#endif

/*
 * LED pin configuration
 */
#ifndef CFG_LED_PIN
#               define CFG_LED_PIN (HW_GPIO_PIN_1)
#endif

/*
 * User button port configuration
 */
#ifndef CFG_USER_BUTTON_PORT
#               define CFG_USER_BUTTON_PORT (HW_GPIO_PORT_0)
#endif

/*
 * User button pin configuration
 */
#ifndef CFG_USER_BUTTON_PIN
#               define CFG_USER_BUTTON_PIN (HW_GPIO_PIN_6)
#endif

#endif /* AMS_CONFIG_H_ */
