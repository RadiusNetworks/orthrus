#!/bin/bash

# Display objects diff between two elf files, reporting size of missing objects.
# example
#./compare-elf.sh elf-files/dynamic_all_in.elf elf-files/dynamic_all_no_uecc.elf
#-------------------------------------------------------------------------------

fileA="$1"
fileB="$2"
[ -e output.txt ] && rm output.txt
# Display elf info for the first input file
arm-none-eabi-readelf -e $fileA > output.txt
mkdir temp
#Generate output from nm for the two files.
arm-none-eabi-gcc-nm --print-size --size-sort --line-numbers $fileA>temp/nmA.txt
arm-none-eabi-gcc-nm --print-size --size-sort --line-numbers $fileB>temp/nmB.txt
#Generate diff after clipping memory address and object size(so as to get a clean diff)
diff -u  <(cut -b20- temp/nmA.txt) <(cut -b20- temp/nmB.txt)| grep -E "^\-" >temp/diff.txt
echo    >> output.txt
echo    Objects Diff:>> output.txt
echo    >> output.txt
#Use diff lines as grep input in order to output objects and their size - sort by memory adress.
grep -f <(cut -b5- temp/diff.txt) temp/nmA.txt | sort >>output.txt
#calculate total
echo    >> output.txt
echo  Total:  >> output.txt
grep -f <(cut -b5- temp/diff.txt) temp/nmA.txt | awk 'NR > 3 { sum += $2 } END { print sum }' >>output.txt

rm -rf temp
less output.txt
