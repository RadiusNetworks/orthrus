Angle of Arrival project.
-------------------------
-------------------------

aoa-binaries
--------------

- aoa-tx

 Binary file of aoa-tx for 690-usb-kit.

 Change tx board transmit channel from git bash from this directory by typing:
```
 sh set-tx-channel <new_tx_channel>
 i.e set the tx channel to 10 by:
 sh set-tx-channel 10
```

 This will produce the new binary from the modified hex 
 Needs to be reflashed to the device either with smartsnippets toolbox or with sdk pythonscript

Flash tx board with:
sdk10\utilities\python_scripts\qspi\program_qspi.py --jlink --prod_header aoa-binaries\aoa-tx\aoatx.bin


- aoa-rx 

 Binary file for aoa-rx for 690-pro-dk with aoa daughterboard and adafruit lcd screen.

Flash rx board with:
sdk10\utilities\python_scripts\qspi\program_qspi.py --jlink --prod_header aoa-binaries\aoa-rx\aoarx.bin


aoa-rx
------
  AoA rx eclipse project

  In order to build, Start a Smart Snippets Studio with worksapce location pointing at angle-of-arrival\sdk10 
  and import aoa-rx project into workspace.
  Import also python-scripts under sdk10 directory.

  Eclipse project that captures IQ data from ana aoa-tx board and runs angle of arrival processing.
  
  Major User AoA parameters can be configured from aoa_rx_settings.h
  
When LCD_MODE is defined, adafruit lcd screen is used to plot the estimated angle index.
  
When MATLAB_MODE IS DEFINED, Matlab script from aoa-matlab/aoa_sdk_process.m
  takes control of the firmware and runs in tandem with 690 processing.
  
When SOFT_AGC is defined agc value is controlled by SOFT_AGC_UPPER_LIMIT and SOFT_AGC_LOWER_LIMIT
  oterwise AOA_AGC_DEFAULT_VALUE is used.
  AGC setting values:
  9 = 0 dB gain
  8 = 6 dB gain
  7 = 12 dB gain  
  6 = 18 dB gain
  5 = 24 dB gain
  4 = 30 dB gain
  3 = 36 dB gain
  2 = 42 dB gain
  1 = 48 dB gain
  0 = 54 dB gain
  
Default AGC and rx Chanel settings can be changed by keeping pressed K1 user button while reseting the board.
  A configuration menu appears over serial terminal connection.

When GPIO_PROFILING is defined P1_2 and P1_3 are used in order to profile execution time for AoA estimation.


aoa-matlab
----------

  Matlab workspace directory.

       aoa_sdk_process_1usec can run either with live data captured from 690 rfmon or
       with testvectors input (Enter a valid testvector_path in aoa_sdk_process script.)

sdk-10
------
  D2522_SDK_10.0.1.52 black-orca-sdk.
